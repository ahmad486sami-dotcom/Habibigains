// GPS run recording. Keeps recording with the screen locked (background location),
// filters out bad GPS fixes, and works out distance, moving time, pace, km splits and climb.
// This file must be imported once at app start (app/_layout.tsx) so the background task is registered.
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Location from 'expo-location';
import * as TaskManager from 'expo-task-manager';
import type { RunPoint, Split } from './data';

export const RUN_TASK = 'hg-run-location';
const KEY = 'hg.activeRun';

export type RunState = {
  status: 'idle' | 'running' | 'paused';
  startedAt: number | null;
  // Each segment is a stretch of running between pauses.
  segments: RunPoint[][];
  movingMs: number; // completed segments
  segmentStartedAt: number | null; // when the current segment started
  background: boolean; // recording with screen locked
};

const empty = (): RunState => ({ status: 'idle', startedAt: null, segments: [], movingMs: 0, segmentStartedAt: null, background: false });

let state: RunState = empty();
const listeners = new Set<(s: RunState) => void>();
let watcher: Location.LocationSubscription | null = null;
let saveTimer: ReturnType<typeof setTimeout> | null = null;

function emit() {
  for (const l of listeners) l(state);
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    AsyncStorage.setItem(KEY, JSON.stringify(state)).catch(() => {});
  }, 1500);
}

export function subscribe(fn: (s: RunState) => void) {
  listeners.add(fn);
  fn(state);
  return () => {
    listeners.delete(fn);
  };
}

export const getRunState = () => state;

// ── distance maths ──
const R = 6371000;
const rad = (d: number) => (d * Math.PI) / 180;
export function haversine(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const dLat = rad(b.lat - a.lat);
  const dLng = rad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

/** Accept a GPS fix only if it is accurate and physically plausible for a runner. */
function accept(loc: Location.LocationObject) {
  if (state.status !== 'running') return;
  const acc = loc.coords.accuracy ?? 99;
  if (acc > 35) return;
  const p: RunPoint = { lat: loc.coords.latitude, lng: loc.coords.longitude, t: loc.timestamp, alt: loc.coords.altitude };
  const seg = state.segments[state.segments.length - 1];
  if (!seg) return;
  const prev = seg[seg.length - 1];
  if (prev) {
    if (p.t <= prev.t) return;
    const d = haversine(prev, p);
    const speed = d / ((p.t - prev.t) / 1000);
    if (speed > 11) return; // faster than an elite sprinter: a GPS jump
    if (d < 2) return; // standing still / jitter
  }
  seg.push(p);
  emit();
}

TaskManager.defineTask(RUN_TASK, async ({ data, error }) => {
  if (error) return;
  const locs = (data as { locations?: Location.LocationObject[] } | undefined)?.locations ?? [];
  if (state.status === 'idle') {
    // The app was relaunched in the background: restore the run first.
    const saved = await AsyncStorage.getItem(KEY).catch(() => null);
    if (saved) state = JSON.parse(saved);
  }
  locs.forEach(accept);
});

export type PermissionResult = 'background' | 'foreground' | 'denied';

export async function requestRunPermission(): Promise<PermissionResult> {
  const fg = await Location.requestForegroundPermissionsAsync();
  if (fg.status !== 'granted') return 'denied';
  try {
    const bg = await Location.requestBackgroundPermissionsAsync();
    if (bg.status === 'granted') return 'background';
  } catch {
    // fall through to foreground-only
  }
  return 'foreground';
}

async function startUpdates(background: boolean) {
  if (background) {
    try {
      await Location.startLocationUpdatesAsync(RUN_TASK, {
        accuracy: Location.Accuracy.BestForNavigation,
        activityType: Location.ActivityType.Fitness,
        distanceInterval: 3,
        timeInterval: 1000,
        pausesUpdatesAutomatically: false,
        showsBackgroundLocationIndicator: true,
        foregroundService: { notificationTitle: 'Habibi Gains', notificationBody: 'Recording your run' },
      });
      state.background = true;
      return;
    } catch {
      // fall back to foreground tracking below
    }
  }
  watcher = await Location.watchPositionAsync(
    { accuracy: Location.Accuracy.BestForNavigation, distanceInterval: 3, timeInterval: 1000 },
    accept,
  );
  state.background = false;
}

async function stopUpdates() {
  watcher?.remove();
  watcher = null;
  if (await Location.hasStartedLocationUpdatesAsync(RUN_TASK).catch(() => false)) {
    await Location.stopLocationUpdatesAsync(RUN_TASK).catch(() => {});
  }
}

export async function startRun(background: boolean) {
  state = { ...empty(), status: 'running', startedAt: Date.now(), segments: [[]], segmentStartedAt: Date.now() };
  await startUpdates(background);
  emit();
}

export function pauseRun() {
  if (state.status !== 'running') return;
  state.movingMs += Date.now() - (state.segmentStartedAt ?? Date.now());
  state.segmentStartedAt = null;
  state.status = 'paused';
  emit();
}

export function resumeRun() {
  if (state.status !== 'paused') return;
  state.status = 'running';
  state.segmentStartedAt = Date.now();
  state.segments.push([]);
  emit();
}

/** Stop recording and return the finished state. */
export async function finishRun() {
  if (state.status === 'running') pauseRun();
  await stopUpdates();
  const done = state;
  state = empty();
  await AsyncStorage.removeItem(KEY).catch(() => {});
  emit();
  return done;
}

export async function discardRun() {
  await stopUpdates();
  state = empty();
  await AsyncStorage.removeItem(KEY).catch(() => {});
  emit();
}

/** If the app was closed mid-run, pick the run back up. */
export async function restoreRun() {
  if (state.status !== 'idle') return state;
  const saved = await AsyncStorage.getItem(KEY).catch(() => null);
  if (!saved) return state;
  const s: RunState = JSON.parse(saved);
  if (s.status === 'idle' || !s.startedAt || Date.now() - s.startedAt > 8 * 3_600_000) {
    await AsyncStorage.removeItem(KEY).catch(() => {});
    return state;
  }
  state = s;
  const running = await Location.hasStartedLocationUpdatesAsync(RUN_TASK).catch(() => false);
  if (!running && s.status === 'running') await startUpdates(s.background).catch(() => {});
  emit();
  return state;
}

// ── stats ──
export function movingMs(s: RunState, now = Date.now()) {
  return s.movingMs + (s.status === 'running' && s.segmentStartedAt ? now - s.segmentStartedAt : 0);
}

export function distanceM(segments: RunPoint[][]) {
  let d = 0;
  for (const seg of segments) for (let i = 1; i < seg.length; i++) d += haversine(seg[i - 1], seg[i]);
  return d;
}

/** Pace over the last ~25 seconds (seconds per km), or null when standing. */
export function currentPace(segments: RunPoint[][]) {
  const seg = segments[segments.length - 1] ?? [];
  if (seg.length < 2) return null;
  const end = seg[seg.length - 1];
  let i = seg.length - 1;
  while (i > 0 && end.t - seg[i - 1].t < 25_000) i--;
  let d = 0;
  for (let j = i + 1; j < seg.length; j++) d += haversine(seg[j - 1], seg[j]);
  const s = (end.t - seg[i].t) / 1000;
  if (d < 15 || s <= 0) return null;
  return (s / d) * 1000;
}

/** Time for each full kilometre (moving time, pauses excluded). */
export function splits(segments: RunPoint[][]): Split[] {
  const out: Split[] = [];
  let dist = 0;
  let time = 0;
  let lastKmTime = 0;
  for (const seg of segments) {
    for (let i = 1; i < seg.length; i++) {
      const d = haversine(seg[i - 1], seg[i]);
      const t = (seg[i].t - seg[i - 1].t) / 1000;
      while (dist + d >= (out.length + 1) * 1000 && d > 0) {
        const need = (out.length + 1) * 1000 - dist;
        const tAt = time + t * (need / d);
        out.push({ km: out.length + 1, s: Math.round(tAt - lastKmTime) });
        lastKmTime = tAt;
        if (out.length > 200) break;
      }
      dist += d;
      time += t;
    }
  }
  return out;
}

/** Total climb in metres, ignoring GPS altitude noise below 2 m. */
export function elevationGain(segments: RunPoint[][]) {
  let gain = 0;
  for (const seg of segments) {
    let ref: number | null = null;
    for (const p of seg) {
      if (p.alt === null || p.alt === undefined) continue;
      if (ref === null) ref = p.alt;
      else if (p.alt - ref >= 2) {
        gain += p.alt - ref;
        ref = p.alt;
      } else if (p.alt < ref) ref = p.alt;
    }
  }
  return Math.round(gain);
}

/** Simplify the route for storage and sharing (keeps the shape, drops near-duplicates). */
export function simplify(segments: RunPoint[][], maxPoints = 800): [number, number][] {
  const all = segments.flat();
  if (all.length <= maxPoints) return all.map((p) => [Math.round(p.lat * 1e6) / 1e6, Math.round(p.lng * 1e6) / 1e6]);
  const step = all.length / maxPoints;
  const out: [number, number][] = [];
  for (let i = 0; i < all.length; i += step) {
    const p = all[Math.floor(i)];
    out.push([Math.round(p.lat * 1e6) / 1e6, Math.round(p.lng * 1e6) / 1e6]);
  }
  const last = all[all.length - 1];
  out.push([last.lat, last.lng]);
  return out;
}

/** Running energy cost ≈ 1 kcal per kg per km (ACSM / Margaria). */
export const runKcal = (distanceM: number, weightKg: number) => Math.round((distanceM / 1000) * weightKg * 1.0);

export function formatDuration(ms: number) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}` : `${m}:${String(sec).padStart(2, '0')}`;
}

export function formatPace(secPerKm: number | null) {
  if (!secPerKm || !isFinite(secPerKm) || secPerKm > 3600) return '–:––';
  const m = Math.floor(secPerKm / 60);
  const s = Math.round(secPerKm % 60);
  return s === 60 ? `${m + 1}:00` : `${m}:${String(s).padStart(2, '0')}`;
}

export const formatKm = (m: number) => (m / 1000).toFixed(2);
