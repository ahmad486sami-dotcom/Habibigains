// Someone's profile: what they chose to show you, friend actions, and their food diary if they share it.
import { router, useLocalSearchParams } from 'expo-router';
import React, { useCallback, useEffect, useState } from 'react';
import { Alert, ScrollView, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { shiftDay, dayLabel, MEAL_LABEL } from '@/lib/day';
import { success } from '@/lib/haptics';
import { useSession } from '@/lib/session';
import { acceptRequest, friendDiary, getProfileCard, ProfileCard, removeFriend, sendRequest } from '@/lib/social';
import { todayISO } from '@/lib/supabase';
import { fmtWeight, unitsOf } from '@/lib/units';
import { useTheme } from '@/theme/theme';
import { Avatar, Stat } from '@/ui/Avatar';
import { Icon } from '@/ui/Icon';
import { Card, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function UserProfile() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { profile } = useSession();
  const units = unitsOf(profile);
  const [p, setP] = useState<ProfileCard | null>(null);
  const [day, setDay] = useState(todayISO());
  const [diary, setDiary] = useState<any[]>([]);

  const load = useCallback(() => {
    if (id) getProfileCard(id).then(setP).catch(() => {});
  }, [id]);
  useEffect(load, [load]);
  useEffect(() => {
    if (p?.diary && id) friendDiary(id, day).then(setDiary).catch(() => setDiary([]));
  }, [p?.diary, id, day]);

  if (!p) return <View style={{ flex: 1, backgroundColor: theme.bg }} />;
  const name = p.display_name ?? p.username ?? '';
  const total = diary.reduce((a, l) => a + Number(l.kcal), 0);
  const act = async (fn: () => Promise<void>) => { await fn().catch(() => {}); success(); load(); };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ padding: 20, gap: 14, paddingBottom: 60 }}>
      <Row style={{ justifyContent: 'flex-end' }}>
        <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
      </Row>
      <View style={{ alignItems: 'center', gap: 6 }}>
        <Avatar url={p.avatar_url} name={name} size={96} />
        <Txt v="h2">{name}</Txt>
        {p.username ? <Txt v="small" muted>{`@${p.username}`}</Txt> : null}
        {p.gym ? <Txt v="small" color={theme.accent}>{p.gym}</Txt> : null}
        {p.bio ? <Txt center>{p.bio}</Txt> : null}
      </View>
      <Card>
        <Row>
          <Stat value={p.streak != null ? String(p.streak) : '—'} label={L('day streak', 'يوم متتالي')} />
          <Stat value={p.kg_lost != null ? fmtWeight(Math.max(0, p.kg_lost), units) : '—'} label={L('lost', 'خسر')} />
          <Stat value={p.steps_today != null ? p.steps_today.toLocaleString('en-US') : '—'} label={L('steps today', 'خطوات اليوم')} />
        </Row>
      </Card>

      {p.relation === 'none' ? <Button title={L('Add friend', 'أضف صديق')} onPress={() => act(() => sendRequest(p.id))} /> : null}
      {p.relation === 'requested' ? <Button kind="secondary" title={L('Request sent · Cancel', 'تم الطلب · إلغاء')} onPress={() => act(() => removeFriend(p.id))} /> : null}
      {p.relation === 'incoming' ? <Button title={L('Accept friend request', 'قبول الطلب')} onPress={() => act(() => acceptRequest(p.id))} /> : null}

      {p.week ? (
        <Card>
          <Txt v="label" muted>{L('Last 7 days', 'آخر ٧ أيام')}</Txt>
          <Row style={{ justifyContent: 'space-between' }}>
            {Array.from({ length: 7 }, (_, i) => shiftDay(todayISO(), i - 6)).map((d) => {
              const k = p.week!.find((w) => w.day === d)?.kcal ?? 0;
              const over = p.calorie_target && k > p.calorie_target;
              return <View key={d} style={{ width: 26, height: 26, borderRadius: 13, backgroundColor: !k ? theme.cardHigh : over ? '#FF7A59' : theme.accent }} />;
            })}
          </Row>
        </Card>
      ) : null}

      {p.diary ? (
        <>
          <Row style={{ justifyContent: 'space-between', marginTop: 4 }}>
            <Press onPress={() => setDay(shiftDay(day, -1))} style={{ padding: 6 }}><Txt v="h3">‹</Txt></Press>
            <Txt v="bodyStrong">{`${L('Food diary', 'اليوميات')} · ${dayLabel(day, lang)}`}</Txt>
            <Press onPress={() => day < todayISO() && setDay(shiftDay(day, 1))} style={{ padding: 6 }}><Txt v="h3" color={day < todayISO() ? theme.text : theme.faint}>›</Txt></Press>
          </Row>
          <Card>
            {diary.length ? diary.map((l) => (
              <Row key={l.id} style={{ justifyContent: 'space-between' }}>
                <View style={{ flex: 1 }}>
                  <Txt>{l.name}</Txt>
                  <Txt v="small" faint>{L(MEAL_LABEL[l.meal as keyof typeof MEAL_LABEL]?.en ?? l.meal, MEAL_LABEL[l.meal as keyof typeof MEAL_LABEL]?.ar ?? l.meal)}</Txt>
                </View>
                <Txt v="bodyStrong">{Math.round(l.kcal)}</Txt>
              </Row>
            )) : <Txt muted>{L('Nothing logged this day.', 'ما سجل شي هاليوم.')}</Txt>}
            {diary.length ? <Txt v="small" muted>{`${L('Total', 'المجموع')}: ${Math.round(total)} kcal`}</Txt> : null}
          </Card>
        </>
      ) : p.relation === 'friend' ? (
        <Txt v="small" faint center>{L(`${name} keeps their food diary private.`, 'يومياته خاصة.')}</Txt>
      ) : null}

      {p.relation === 'friend' ? (
        <Button kind="ghost" title={L('Remove friend', 'إزالة الصديق')} onPress={() => Alert.alert(L('Remove friend?', 'إزالة؟'), '', [{ text: L('Cancel', 'إلغاء') }, { text: L('Remove', 'إزالة'), style: 'destructive', onPress: () => act(() => removeFriend(p.id)) }])} />
      ) : null}
    </ScrollView>
  );
}
