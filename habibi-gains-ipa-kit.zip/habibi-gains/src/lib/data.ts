// Data access used by the screens.
import { useCallback, useEffect, useState } from 'react';
import { supabase, todayISO } from './supabase';
import { demo, demoId, demoToday, IS_DEMO } from './demo';
import { buildTrend, TrendPoint } from './trend';

const wait = (ms = 250) => new Promise((r) => setTimeout(r, ms));

export type FoodLog = {
  id: string;
  name: string;
  meal: string;
  servings: number;
  kcal: number;
  protein_g: number;
  carbs_g: number;
  fat_g: number;
  logged_on: string;
  source: string;
};

export type Food = {
  id: string;
  name_en: string;
  name_ar: string | null;
  serving: string;
  kcal: number;
  protein_g: number;
  carbs_g: number;
  fat_g: number;
  is_local: boolean;
};

export type EventRow = {
  id: string;
  host_id: string;
  title: string;
  description: string | null;
  location_name: string;
  emirate: string;
  starts_at: string;
  badge_name: string;
  xp: number;
  checkin_code: string | null;
  women_only: boolean;
  going: number;
  i_am_going: boolean;
};

export type Quest = {
  id: string;
  title_en: string;
  title_ar: string | null;
  description: string | null;
  proof: 'photo' | 'steps' | 'checkin' | 'honor';
  target_steps: number | null;
  xp: number;
  ends_on: string;
};

export type MealPick = {
  id: string;
  title_en: string;
  title_ar: string | null;
  restaurant: string;
  kcal: number;
  protein_g: number;
  price_aed: number | null;
  deal_text: string | null;
  order_url: string | null;
  emirate: string;
};

/** Generic loader with refresh. */
export function useQuery<T>(fn: () => Promise<T>, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const run = useCallback(async () => {
    setLoading(true);
    try {
      setData(await fn());
      setError(null);
    } catch (e: any) {
      setError(e?.message ?? 'error');
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  useEffect(() => {
    run();
  }, [run]);
  return { data, loading, error, refresh: run };
}

export async function fetchDayLogs(day = todayISO()) {
  if (IS_DEMO) return (await wait(), demo.logs.filter((l) => l.logged_on === day));
  const { data, error } = await supabase.from('food_logs').select('*').eq('logged_on', day).order('created_at');
  if (error) throw error;
  return (data ?? []) as FoodLog[];
}

export async function fetchDailyTotals(days = 35) {
  if (IS_DEMO) return demo.dailyTotals;
  const since = todayISO(new Date(Date.now() - days * 86_400_000));
  const { data, error } = await supabase.from('food_logs').select('logged_on,kcal').gte('logged_on', since);
  if (error) throw error;
  const map = new Map<string, number>();
  (data ?? []).forEach((r: any) => map.set(r.logged_on, (map.get(r.logged_on) ?? 0) + Number(r.kcal)));
  return [...map.entries()].map(([day, kcal]) => ({ day, kcal }));
}

export async function fetchTrend(days = 365): Promise<TrendPoint[]> {
  if (IS_DEMO) return (await wait(), buildTrend(demo.weighIns));
  const since = todayISO(new Date(Date.now() - days * 86_400_000));
  const { data, error } = await supabase
    .from('weigh_ins')
    .select('measured_on,weight_kg')
    .gte('measured_on', since)
    .order('measured_on');
  if (error) throw error;
  return buildTrend((data ?? []) as any);
}

export async function logWeight(userId: string, kg: number, day = todayISO()) {
  if (IS_DEMO) {
    demo.weighIns = demo.weighIns.filter((w) => w.measured_on !== day).concat({ measured_on: day, weight_kg: kg });
    return;
  }
  const { error } = await supabase
    .from('weigh_ins')
    .upsert({ user_id: userId, weight_kg: kg, measured_on: day, source: 'manual' }, { onConflict: 'user_id,measured_on' });
  if (error) throw error;
}

export async function addFoodLog(userId: string, entry: Omit<FoodLog, 'id' | 'logged_on'> & { food_id?: string | null }) {
  if (IS_DEMO) {
    const { food_id: _f, ...rest } = entry;
    demo.logs.push({ ...rest, id: demoId(), logged_on: demoToday() });
    return;
  }
  const { error } = await supabase.from('food_logs').insert({ ...entry, user_id: userId, logged_on: todayISO() });
  if (error) throw error;
}

export async function deleteFoodLog(id: string) {
  if (IS_DEMO) {
    demo.logs = demo.logs.filter((l) => l.id !== id);
    return;
  }
  await supabase.from('food_logs').delete().eq('id', id);
}

export async function searchFoods(q: string): Promise<Food[]> {
  const term = q.trim();
  if (IS_DEMO) {
    const t = term.toLowerCase();
    return demo.foods.filter((f) => !t || f.name_en.toLowerCase().includes(t) || (f.name_ar ?? '').includes(term));
  }
  if (!term) {
    const { data } = await supabase.from('foods').select('*').eq('is_local', true).limit(20);
    return (data ?? []) as Food[];
  }
  const safe = term.replace(/[%,()]/g, ' ');
  const { data, error } = await supabase
    .from('foods')
    .select('*')
    .or(`name_en.ilike.%${safe}%,name_ar.ilike.%${safe}%`)
    .order('is_local', { ascending: false })
    .limit(30);
  if (error) throw error;
  return (data ?? []) as Food[];
}

/** Barcode → our database first, then Open Food Facts (free, open data). */
export async function lookupBarcode(code: string, userId: string): Promise<Food | null> {
  if (IS_DEMO) {
    await wait(600);
    return { id: 'scan', name_en: 'Al Ain protein yogurt', name_ar: 'زبادي بروتين', serving: '1 cup', kcal: 140, protein_g: 20, carbs_g: 9, fat_g: 2, is_local: true };
  }
  const { data: local } = await supabase.from('foods').select('*').eq('barcode', code).maybeSingle();
  if (local) return local as Food;
  try {
    const res = await fetch(`https://world.openfoodfacts.org/api/v2/product/${encodeURIComponent(code)}.json?fields=product_name,product_name_ar,nutriments,serving_size`, {
      headers: { 'User-Agent': 'HabibiGains/1.0 (contact@habibigains.app)' },
    });
    const json = await res.json();
    const p = json?.product;
    if (!p?.nutriments) return null;
    const n = p.nutriments;
    const per = n['energy-kcal_serving'] != null ? 'serving' : '100g';
    const pick = (k: string) => Number(n[`${k}_${per}`] ?? 0);
    const food = {
      name_en: p.product_name || 'Scanned product',
      name_ar: p.product_name_ar || null,
      serving: per === 'serving' ? p.serving_size || '1 serving' : '100 g',
      kcal: Math.round(pick('energy-kcal')),
      protein_g: Math.round(pick('proteins') * 10) / 10,
      carbs_g: Math.round(pick('carbohydrates') * 10) / 10,
      fat_g: Math.round(pick('fat') * 10) / 10,
      barcode: code,
      created_by: userId,
      verified: false,
    };
    const { data: inserted } = await supabase.from('foods').insert(food).select('*').single();
    return (inserted as Food) ?? ({ id: '', is_local: false, ...food } as Food);
  } catch {
    return null;
  }
}

export type CameraItem = { name_en: string; name_ar: string; portion?: string; kcal: number; protein_g: number; carbs_g: number; fat_g: number; tip_en?: string; tip_ar?: string };
export type CameraResult =
  | { kind: 'meal'; items: CameraItem[]; confidence: 'low' | 'medium' | 'high' }
  | { kind: 'menu'; picks: CameraItem[]; confidence: 'low' | 'medium' | 'high' }
  | { kind: 'none' }
  | { error: 'premium_required' | 'not_configured' | 'failed' };

/** Smart camera: one photo of a plate or a menu. */
export async function analyzePhoto(base64: string, remainingKcal: number, remainingProtein: number, demoKind: 'meal' | 'menu' = 'meal'): Promise<CameraResult> {
  if (IS_DEMO) {
    await wait(1800);
    if (demoKind === 'menu')
      return {
        kind: 'menu',
        confidence: 'high',
        picks: [
          { name_en: 'Shish tawook plate', name_ar: 'صحن شيش طاووق', kcal: 560, protein_g: 52, carbs_g: 40, fat_g: 18, tip_en: 'Ask for salad instead of fries', tip_ar: 'اطلب سلطة بدل البطاطس' },
          { name_en: 'Grilled hammour', name_ar: 'هامور مشوي', kcal: 430, protein_g: 40, carbs_g: 30, fat_g: 14, tip_en: 'Rice on the side, half portion', tip_ar: 'الرز على الجنب، نص كمية' },
          { name_en: 'Lentil soup + fattoush', name_ar: 'شوربة عدس + فتوش', kcal: 400, protein_g: 16, carbs_g: 54, fat_g: 13, tip_en: 'Dressing on the side', tip_ar: 'الصوص على الجنب' },
        ],
      };
    return {
      kind: 'meal',
      confidence: 'medium',
      items: [
        { name_en: 'Chicken shawarma plate', name_ar: 'صحن شاورما دجاج', portion: '1 plate', kcal: 720, protein_g: 44, carbs_g: 66, fat_g: 30 },
        { name_en: 'Garlic sauce', name_ar: 'ثومية', portion: '2 tbsp', kcal: 140, protein_g: 0, carbs_g: 1, fat_g: 15 },
      ],
    };
  }
  const { data, error } = await supabase.functions.invoke('food-photo', {
    body: { imageBase64: base64, mediaType: 'image/jpeg', remainingKcal, remainingProtein },
  });
  if (error) {
    const status = (error as any)?.context?.status;
    if (status === 402) return { error: 'premium_required' };
    if (status === 503) return { error: 'not_configured' };
    return { error: 'failed' };
  }
  return data as CameraResult;
}

export async function fetchEvents() {
  if (IS_DEMO) return (await wait(), demo.events);
  const { data, error } = await supabase
    .from('events_public')
    .select('*')
    .gte('starts_at', new Date(Date.now() - 4 * 3_600_000).toISOString())
    .order('starts_at')
    .limit(20);
  if (error) throw error;
  return (data ?? []) as EventRow[];
}

export async function rsvp(eventId: string, userId: string, going: boolean) {
  if (IS_DEMO) {
    const e = demo.events.find((x) => x.id === eventId);
    if (e && e.i_am_going !== going) {
      e.i_am_going = going;
      e.going += going ? 1 : -1;
    }
    return;
  }
  if (going) await supabase.from('event_rsvps').upsert({ event_id: eventId, user_id: userId });
  else await supabase.from('event_rsvps').delete().eq('event_id', eventId).eq('user_id', userId);
}

export async function fetchQuests() {
  if (IS_DEMO) return (await wait(), demo.quests);
  const today = todayISO();
  const [{ data: qs }, { data: done }] = await Promise.all([
    supabase.from('quests').select('*').lte('starts_on', today).gte('ends_on', today).order('ends_on'),
    supabase.from('quest_completions').select('quest_id'),
  ]);
  const doneSet = new Set((done ?? []).map((d: any) => d.quest_id));
  return ((qs ?? []) as Quest[]).map((q) => ({ ...q, done: doneSet.has(q.id) }));
}

export async function fetchBadges() {
  if (IS_DEMO) return demo.badges;
  const [{ data: all }, { data: mine }] = await Promise.all([
    supabase.from('badges').select('*').not('id', 'like', 'event-%'),
    supabase.from('user_badges').select('badge_id, earned_at, badges(name_en, name_ar)'),
  ]);
  const mineSet = new Set((mine ?? []).map((m: any) => m.badge_id));
  const eventBadges = (mine ?? [])
    .filter((m: any) => String(m.badge_id).startsWith('event-'))
    .map((m: any) => ({ id: m.badge_id, name_en: m.badges?.name_en ?? 'Run Club', name_ar: m.badges?.name_ar ?? null, icon: 'run', earned: true }));
  return [
    ...((all ?? []) as any[]).map((b) => ({ ...b, earned: mineSet.has(b.id) })),
    ...eventBadges,
  ] as { id: string; name_en: string; name_ar: string | null; icon: string; earned: boolean }[];
}

export async function awardBadge(id: string) {
  if (IS_DEMO) {
    const b = demo.badges.find((x) => x.id === id);
    if (!b || b.earned) return false;
    b.earned = true;
    return true;
  }
  const { data } = await supabase.rpc('award_badge', { p_badge: id });
  return data === true;
}

export async function fetchMealPicks(emirate: string, maxKcal: number) {
  if (IS_DEMO) return demo.picks.filter((p) => p.kcal <= Math.max(300, maxKcal));
  const { data } = await supabase
    .from('meal_picks')
    .select('*')
    .eq('active', true)
    .lte('kcal', Math.max(300, maxKcal))
    .order('protein_g', { ascending: false })
    .limit(10);
  const rows = (data ?? []) as MealPick[];
  return rows.sort((a, b) => Number(b.emirate === emirate) - Number(a.emirate === emirate));
}

export async function fetchPhotos() {
  if (IS_DEMO) return demo.photos;
  const { data } = await supabase.from('progress_photos').select('*').order('taken_on');
  return (data ?? []) as { id: string; storage_path: string; pose: string; taken_on: string }[];
}

export async function completeQuest(questId: string, proofPath: string | null) {
  if (IS_DEMO) {
    const q = demo.quests.find((x) => x.id === questId);
    if (q) q.done = true;
    return { ok: true, xp: q?.xp ?? 0 };
  }
  const { data, error } = await supabase.rpc('complete_quest', { p_quest: questId, p_proof: proofPath });
  if (error) throw error;
  return data as { ok: boolean; xp?: number; error?: string };
}

export async function checkIn(code: string) {
  if (IS_DEMO) {
    await wait(500);
    return { ok: true, event: 'Corniche Sunrise 5K', badge: 'Corniche Sunrise', xp: 100 };
  }
  const { data, error } = await supabase.rpc('check_in', { p_code: code });
  if (error) throw error;
  return data as { ok: boolean; event?: string; badge?: string; xp?: number; error?: string; already?: boolean };
}

export async function addProgressPhoto(userId: string, uri: string, upload: (uri: string) => Promise<string>) {
  if (IS_DEMO) {
    demo.photos.push({ id: demoId(), storage_path: uri, pose: 'front', taken_on: demoToday() });
    return;
  }
  const path = await upload(uri);
  const { error } = await supabase.from('progress_photos').insert({ user_id: userId, storage_path: path });
  if (error) throw error;
}
