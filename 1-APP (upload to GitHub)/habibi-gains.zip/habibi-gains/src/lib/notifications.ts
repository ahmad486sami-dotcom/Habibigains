// Smart local reminders. Nothing is sent from a server: the phone schedules them itself.
// Every time the app opens (and after any setting change) we rebuild the next 3 days of reminders,
// skipping ones that are no longer needed (e.g. a meal you already logged today).
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';
import { supabase, todayISO } from './supabase';
import { Emirate, fastingTimes } from './ramadan';
import type { Profile } from './session';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export type NotifPrefs = {
  enabled: boolean;
  weighIn: boolean;
  meals: boolean;
  water: boolean;
  streak: boolean;
  runClubs: boolean;
  ramadan: boolean;
};

const KEY = 'hg.notifPrefs';
export const DEFAULT_PREFS: NotifPrefs = { enabled: false, weighIn: true, meals: true, water: true, streak: true, runClubs: true, ramadan: true };

export async function getPrefs(): Promise<NotifPrefs> {
  try {
    const v = await AsyncStorage.getItem(KEY);
    return v ? { ...DEFAULT_PREFS, ...JSON.parse(v) } : DEFAULT_PREFS;
  } catch {
    return DEFAULT_PREFS;
  }
}

export async function savePrefs(p: NotifPrefs) {
  await AsyncStorage.setItem(KEY, JSON.stringify(p)).catch(() => {});
}

export async function askPermission() {
  const cur = await Notifications.getPermissionsAsync();
  if (cur.granted) return true;
  const { status } = await Notifications.requestPermissionsAsync();
  return status === 'granted';
}

const at = (base: Date, hhmm: string, addMin = 0) => {
  const [h, m] = hhmm.split(':').map(Number);
  const d = new Date(base);
  d.setHours(h, (m || 0) + addMin, 0, 0);
  return d;
};

type Item = { when: Date; title: string; body: string };

/** Rebuild all scheduled reminders. Safe to call often. */
export async function syncNotifications(profile: Profile | null, lang: 'en' | 'ar') {
  try {
    const prefs = await getPrefs();
    await Notifications.cancelAllScheduledNotificationsAsync();
    if (!prefs.enabled || !profile) return;
    const perm = await Notifications.getPermissionsAsync();
    if (!perm.granted) return;

    const ar = lang === 'ar';
    const now = new Date();
    const today = todayISO();
    const items: Item[] = [];

    // What has already happened today, so we don't nag for it.
    const [{ data: logs }, { data: weighed }] = await Promise.all([
      supabase.from('food_logs').select('meal').eq('logged_on', today),
      supabase.from('weigh_ins').select('id').eq('measured_on', today).limit(1),
    ]);
    const mealsToday = new Set((logs ?? []).map((l: any) => l.meal));
    const loggedToday = (logs ?? []).length > 0;
    const weighedToday = (weighed ?? []).length > 0;

    for (let dayOffset = 0; dayOffset < 3; dayOffset++) {
      const base = new Date(now);
      base.setDate(now.getDate() + dayOffset);
      const isToday = dayOffset === 0;
      const fasting = profile.ramadan_mode ? fastingTimes((profile.emirate ?? 'Abu Dhabi') as Emirate, base) : null;

      if (prefs.weighIn && !(isToday && weighedToday)) {
        items.push({
          when: at(base, profile.wake_time ?? '07:00', 15),
          title: ar ? 'وقت الوزن ⚖️' : 'Weigh-in time ⚖️',
          body: ar ? 'قبل الأكل وبعد الحمام، عشان الاتجاه يكون دقيق.' : 'Before food, after the bathroom: keeps your trend accurate.',
        });
      }

      if (prefs.meals) {
        const meals: [string, string, string, string][] = profile.ramadan_mode
          ? []
          : [
              ['breakfast', '09:30', 'Log breakfast?', 'سجّلت فطورك؟'],
              ['lunch', '13:45', 'Log lunch?', 'سجّلت غداك؟'],
              ['dinner', '20:15', 'Log dinner?', 'سجّلت عشاك؟'],
            ];
        for (const [meal, time, en, arT] of meals) {
          if (isToday && mealsToday.has(meal)) continue;
          items.push({ when: at(base, time), title: ar ? arT : en, body: ar ? 'ثانيتين وتخلص. كل شي محسوب.' : 'Takes 10 seconds. Search, tap, done.' });
        }
      }

      if (prefs.water && !fasting) {
        for (const time of ['11:00', '14:00', '17:00', '19:30']) {
          items.push({ when: at(base, time), title: ar ? 'اشرب ماي 💧' : 'Water break 💧', body: ar ? 'كوب واحد الحين. سجّله في اليوميات.' : 'One glass now. Tap the diary to log it.' });
        }
      }

      if (prefs.streak && !(isToday && loggedToday)) {
        items.push({
          when: at(base, '21:30'),
          title: ar ? `لا تكسر السلسلة 🔥` : `Don't break your streak 🔥`,
          body: ar ? 'ما سجلت أكل اليوم. حتى إضافة سريعة تكفي.' : 'Nothing logged today yet. Even a quick add keeps it alive.',
        });
      }

      if (prefs.ramadan && fasting) {
        items.push({
          when: new Date(+fasting.suhoorEnds - 45 * 60_000),
          title: ar ? 'وقت السحور 🌙' : 'Suhoor time 🌙',
          body: ar ? 'باقي ٤٥ دقيقة على الفجر. بروتين وماء.' : '45 minutes to Fajr. Protein and water first.',
        });
        items.push({
          when: fasting.iftar,
          title: ar ? 'إفطار هني 🌙' : 'Iftar time 🌙',
          body: ar ? 'ابدأ بتمر وماء. تقبل الله.' : 'Start with dates and water. Taqabbal Allah.',
        });
      }
    }

    if (prefs.runClubs) {
      const { data: rsvps } = await supabase
        .from('events_public')
        .select('title, starts_at, location_name')
        .eq('i_am_going', true)
        .gte('starts_at', now.toISOString())
        .limit(10);
      for (const e of rsvps ?? []) {
        items.push({
          when: new Date(+new Date(e.starts_at) - 60 * 60_000),
          title: ar ? `${e.title} بعد ساعة 🏃` : `${e.title} in 1 hour 🏃`,
          body: ar ? `${e.location_name}. لا تنسى تسجل حضورك بالكود.` : `${e.location_name}. Scan the host's code to check in and earn the badge.`,
        });
      }
    }

    // iOS keeps at most 64 pending notifications; soonest first.
    const future = items.filter((i) => +i.when > Date.now() + 60_000).sort((a, b) => +a.when - +b.when).slice(0, 60);
    for (const i of future) {
      await Notifications.scheduleNotificationAsync({
        content: { title: i.title, body: i.body, sound: 'default' },
        trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: i.when },
      });
    }
  } catch {
    // Reminders are best-effort; never block the app.
  }
}

export async function disableAll() {
  await Notifications.cancelAllScheduledNotificationsAsync().catch(() => {});
}
