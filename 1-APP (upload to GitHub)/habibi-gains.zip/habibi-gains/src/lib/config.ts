// Public links used inside the app.
export const LEGAL_URL = 'https://habibigains.store';
export const SUPPORT_EMAIL = 'hello@habibigains.store';
