import { router, useFocusEffect } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { Dimensions, View } from 'react-native';
import Animated, { FadeInDown, ZoomIn } from 'react-native-reanimated';
import { useI18n } from '@/i18n/i18n';
import { EventRow, fetchBadges, fetchEvents, fetchQuests, fetchRuns, Quest, rsvp, Run } from '@/lib/data';
import { formatDuration, formatKm, formatPace } from '@/lib/runTracker';
import { RouteShape } from '@/ui/RouteShape';
import { success } from '@/lib/haptics';
import { syncNotifications } from '@/lib/notifications';
import { useSession } from '@/lib/session';
import { useTheme } from '@/theme/theme';
import { Bar } from '@/ui/Graphics';
import { Icon, IconName } from '@/ui/Icon';
import { Card, Row, Screen, SectionTitle } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

const W = Dimensions.get('window').width;

function levelFromXp(xp: number) {
  // Each level needs a bit more XP than the last.
  let level = 1;
  let need = 200;
  let left = xp;
  while (left >= need) {
    left -= need;
    level += 1;
    need = Math.round(need * 1.25);
  }
  return { level, into: left, need };
}

export default function Train() {
  const { t, lang } = useI18n();
  const { theme } = useTheme();
  const { profile, session } = useSession();
  const [events, setEvents] = useState<EventRow[]>([]);
  const [quests, setQuests] = useState<(Quest & { done: boolean })[]>([]);
  const [runs, setRuns] = useState<Run[]>([]);
  const [badges, setBadges] = useState<{ id: string; name_en: string; name_ar: string | null; icon: string; earned: boolean }[]>([]);

  const load = useCallback(async () => {
    const [e, q, b, r] = await Promise.all([fetchEvents().catch(() => []), fetchQuests().catch(() => []), fetchBadges().catch(() => []), fetchRuns(30).catch(() => [] as Run[])]);
    setRuns(r);
    setEvents(e);
    setQuests(q);
    setBadges(b);
  }, []);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  const lv = levelFromXp(profile?.xp ?? 0);
  const weekStart = (() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); // Monday
    return +d;
  })();
  const weekRuns = runs.filter((r) => +new Date(r.started_at) >= weekStart);
  const weekM = weekRuns.reduce((s, r) => s + r.distance_m, 0);

  const toggle = async (e: EventRow) => {
    if (!session) return;
    const going = !e.i_am_going;
    setEvents((es) => es.map((x) => (x.id === e.id ? { ...x, i_am_going: going, going: x.going + (going ? 1 : -1) } : x)));
    if (going) success();
    await rsvp(e.id, session.user.id, going);
    syncNotifications(profile, lang);
  };

  const fmt = (iso: string) =>
    new Date(iso).toLocaleString(lang === 'ar' ? 'ar-AE' : 'en-GB', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

  return (
    <Screen>
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="h1">{t('train')}</Txt>
        {profile?.role === 'admin' || profile?.role === 'host' ? (
          <Press onPress={() => router.push('/admin')} style={{ backgroundColor: theme.card, borderRadius: 999, paddingHorizontal: 14, height: 38, justifyContent: 'center' }}>
            <Txt v="bodyStrong">{t('admin')}</Txt>
          </Press>
        ) : null}
      </Row>

      {/* GPS runs */}
      <Card index={0}>
        <Row style={{ justifyContent: 'space-between' }}>
          <View>
            <Txt v="label" muted>{lang === 'ar' ? 'هذا الأسبوع' : 'This week'}</Txt>
            <Txt v="number">{`${(weekM / 1000).toFixed(1)}`}<Txt v="h3" muted>{' km'}</Txt></Txt>
          </View>
          <View style={{ alignItems: 'flex-end' }}>
            <Txt v="bodyStrong">{`${weekRuns.length} ${lang === 'ar' ? 'جري' : weekRuns.length === 1 ? 'run' : 'runs'}`}</Txt>
            <Txt v="small" muted>{formatDuration(weekRuns.reduce((s, r) => s + r.moving_s, 0) * 1000)}</Txt>
          </View>
        </Row>
        <Button title={lang === 'ar' ? 'ابدأ الجري' : 'Start a run'} icon={<Icon name="run" color={theme.onAccent} size={20} />} onPress={() => router.push('/run')} />
      </Card>
      {runs.slice(0, 5).map((r, i) => (
        <Animated.View key={r.id} entering={FadeInDown.delay(i * 50).springify()}>
          <Press onPress={() => router.push({ pathname: '/run/[id]', params: { id: r.id } })} scaleTo={0.98} style={{ flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: theme.card, borderRadius: 22, padding: 14 }}>
            <View style={{ width: 54, height: 54, borderRadius: 14, backgroundColor: theme.cardHigh, alignItems: 'center', justifyContent: 'center' }}>
              <RouteShape route={r.route} size={44} color={theme.accent} stroke={2} />
            </View>
            <View style={{ flex: 1, gap: 2 }}>
              <Txt v="bodyStrong" numberOfLines={1}>{r.title || new Date(r.started_at).toLocaleDateString(lang === 'ar' ? 'ar-AE' : 'en-GB', { weekday: 'long', day: 'numeric', month: 'short' })}</Txt>
              <Txt v="small" muted>{`${formatKm(r.distance_m)} km · ${formatDuration(r.moving_s * 1000)} · ${formatPace(r.distance_m > 0 ? r.moving_s / (r.distance_m / 1000) : null)} /km`}</Txt>
            </View>
            <Icon name="chevron" size={18} color={theme.faint} />
          </Press>
        </Animated.View>
      ))}

      <Press onPress={() => router.push('/supplements')} scaleTo={0.98} style={{ flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: theme.card, borderRadius: 22, padding: 16 }}>
        <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: theme.cardHigh, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="pill" size={20} color={theme.accent} />
        </View>
        <View style={{ flex: 1 }}>
          <Txt v="bodyStrong">{lang === 'ar' ? 'المكملات: وش يشتغل فعلاً' : 'Supplements: what actually works'}</Txt>
          <Txt v="small" muted>{lang === 'ar' ? 'مبني على الأبحاث' : 'Evidence-graded, with doses and sources'}</Txt>
        </View>
        <Icon name="chevron" size={18} color={theme.faint} />
      </Press>

      <Card index={1}>
        <Row style={{ justifyContent: 'space-between' }}>
          <Txt v="h2">{t('level', { n: lv.level })}</Txt>
          <Txt v="small" muted>{`${profile?.xp ?? 0} XP`}</Txt>
        </Row>
        <Bar progress={lv.into / lv.need} height={8} />
        <Txt v="small" muted>{t('xpToNext', { xp: lv.need - lv.into, n: lv.level + 1 })}</Txt>
      </Card>

      <SectionTitle action={t('checkIn')} onAction={() => router.push('/scan')}>{t('runClubs')}</SectionTitle>
      {events.length === 0 ? <Txt muted>{t('noEvents')}</Txt> : null}
      {events.map((e, i) => (
        <Card key={e.id} index={i} onPress={() => router.push({ pathname: '/event/[id]', params: { id: e.id } })}>
          <Row style={{ justifyContent: 'space-between' }}>
            <Txt v="label" muted>{fmt(e.starts_at)}</Txt>
            {e.women_only ? (
              <View style={{ backgroundColor: theme.accentSoft, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 3 }}>
                <Txt v="label" color={theme.accent}>{t('womenOnly')}</Txt>
              </View>
            ) : null}
          </Row>
          <Txt v="h2">{e.title}</Txt>
          <Row gap={6}>
            <Icon name="pin" size={16} color={theme.muted} />
            <Txt v="small" muted style={{ flex: 1 }} numberOfLines={1}>{e.location_name}</Txt>
          </Row>
          <Row style={{ justifyContent: 'space-between', marginTop: 4 }}>
            <Txt v="small" muted>{t('going', { n: e.going })}</Txt>
            <Press
              onPress={() => toggle(e)}
              style={{ backgroundColor: e.i_am_going ? theme.cardHigh : theme.accent, borderRadius: 999, paddingHorizontal: 16, height: 38, justifyContent: 'center', flexDirection: 'row', alignItems: 'center', gap: 6 }}
            >
              {e.i_am_going ? <Icon name="check" size={16} /> : null}
              <Txt v="bodyStrong" color={e.i_am_going ? theme.text : theme.onAccent}>{e.i_am_going ? t('youreGoing') : t('imIn')}</Txt>
            </Press>
          </Row>
        </Card>
      ))}

      <SectionTitle>{t('quests')}</SectionTitle>
      {quests.map((q, i) => (
        <Animated.View key={q.id} entering={FadeInDown.delay(i * 60).springify()}>
          <Press
            onPress={() => !q.done && router.push({ pathname: '/quest/[id]', params: { id: q.id } })}
            scaleTo={0.98}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: theme.card, borderRadius: 22, padding: 16, opacity: q.done ? 0.55 : 1 }}
          >
            <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: q.done ? theme.accent : theme.cardHigh, alignItems: 'center', justifyContent: 'center' }}>
              <Icon name={q.done ? 'check' : q.proof === 'photo' ? 'camera' : q.proof === 'steps' ? 'run' : 'star'} size={18} color={q.done ? theme.onAccent : theme.text} />
            </View>
            <View style={{ flex: 1 }}>
              <Txt v="bodyStrong">{lang === 'ar' && q.title_ar ? q.title_ar : q.title_en}</Txt>
              <Txt v="small" faint>{`+${q.xp} XP`}</Txt>
            </View>
            {!q.done ? <Icon name="chevron" size={18} color={theme.faint} /> : null}
          </Press>
        </Animated.View>
      ))}

      <SectionTitle>{t('badges')}</SectionTitle>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        {badges.map((b, i) => (
          <Animated.View key={b.id} entering={ZoomIn.delay(i * 40).springify()} style={{ width: (W - 60) / 4, alignItems: 'center', gap: 6, opacity: b.earned ? 1 : 0.35 }}>
            <View style={{ width: 62, height: 62, borderRadius: 31, borderWidth: b.earned ? 3 : 2, borderStyle: b.earned ? 'solid' : 'dashed', borderColor: b.earned ? theme.accent : theme.faint, alignItems: 'center', justifyContent: 'center' }}>
              <Icon name={(['fork', 'scale', 'flame', 'camera', 'run', 'star', 'trend'].includes(b.icon) ? b.icon : 'medal') as IconName} size={26} color={b.earned ? theme.accent : theme.faint} />
            </View>
            <Txt v="small" center numberOfLines={2} style={{ fontSize: 11 }}>{lang === 'ar' && b.name_ar ? b.name_ar : b.name_en}</Txt>
          </Animated.View>
        ))}
      </View>

      <Button title={t('tutorials')} kind="secondary" icon={<Icon name="book" size={18} />} onPress={() => router.push('/tutorials')} style={{ marginTop: 8 }} />
    </Screen>
  );
}
