// The one camera. Point it at a plate, a menu, a barcode or a run-club QR code.
// Barcodes and QR codes are read live; tap the shutter for plates and menus.
import { CameraView, useCameraPermissions } from 'expo-camera';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import { router } from 'expo-router';
import React, { useEffect, useRef, useState } from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import Animated, {
  Easing,
  FadeIn,
  FadeInDown,
  SlideInDown,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useI18n } from '@/i18n/i18n';
import { toSmallJpegBase64 } from '@/lib/image';
import { addFoodLog, analyzePhoto, CameraItem, checkIn, fetchDayLogs, lookupBarcode } from '@/lib/data';
import { IS_DEMO } from '@/lib/demo';
import { press, success, warn } from '@/lib/haptics';
import { sumDay } from '@/lib/nutrition';
import { useSession } from '@/lib/session';
import { useTheme } from '@/theme/theme';
import { useCelebrate } from '@/ui/Celebrate';
import { Icon } from '@/ui/Icon';
import { Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

type Result =
  | { kind: 'meal'; items: (CameraItem & { on: boolean })[]; confidence: string }
  | { kind: 'menu'; picks: CameraItem[]; confidence: string };

function mealNow(ramadan: boolean) {
  const h = new Date().getHours();
  if (ramadan) return h >= 17 || h < 2 ? 'iftar' : 'suhoor';
  return h < 11 ? 'breakfast' : h < 16 ? 'lunch' : h < 21 ? 'dinner' : 'snack';
}

export default function Camera() {
  const { t, lang } = useI18n();
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const celebrate = useCelebrate();
  const { session, profile } = useSession();
  const [perm, requestPerm] = useCameraPermissions();
  const cam = useRef<CameraView>(null);
  const locked = useRef(false);
  const [photo, setPhoto] = useState<string | null>(null);
  const [state, setState] = useState<'live' | 'thinking' | 'result' | 'premium' | 'off' | 'none' | 'error'>('live');
  const [result, setResult] = useState<Result | null>(null);
  const [remaining, setRemaining] = useState({ kcal: 700, protein: 40 });

  useEffect(() => {
    fetchDayLogs()
      .then((logs) => {
        const s = sumDay(logs);
        setRemaining({
          kcal: Math.max(0, (profile?.calorie_target ?? 2000) - s.kcal),
          protein: Math.max(0, (profile?.protein_target_g ?? 140) - s.protein),
        });
      })
      .catch(() => {});
  }, [profile]);

  const sweep = useSharedValue(0);
  useEffect(() => {
    sweep.value = withRepeat(withTiming(1, { duration: 1800, easing: Easing.inOut(Easing.quad) }), -1, true);
  }, [sweep]);
  const sweepStyle = useAnimatedStyle(() => ({ transform: [{ translateY: sweep.value * 300 }] }));

  // ── live codes ──
  const onCode = async (data: string) => {
    if (locked.current || state !== 'live' || !session) return;
    locked.current = true;
    try {
      if (data.startsWith('habibigains://checkin/') || data.startsWith('HG-')) {
        const r = await checkIn(data.replace('habibigains://checkin/', ''));
        if (r.ok) {
          router.back();
          setTimeout(() => celebrate({ title: r.badge ?? 'Run Club', subtitle: t('checkInSuccess', { xp: r.xp ?? 0 }), icon: 'run' }), 300);
          return;
        }
        warn();
      } else if (/^\d{8,14}$/.test(data)) {
        const food = await lookupBarcode(data, session.user.id);
        if (food) {
          success();
          router.replace({ pathname: '/add-food', params: { foodJson: JSON.stringify(food) } });
          return;
        }
        warn();
      }
    } catch {
      warn();
    }
    setTimeout(() => (locked.current = false), 1500);
  };

  // ── plate or menu photo ──
  const analyze = async (uri: string, demoKind: 'meal' | 'menu' = 'meal') => {
    if (uri) setPhoto(uri);
    if (!profile?.is_premium) return setState('premium');
    setState('thinking');
    try {
      let base64 = '';
      if (!IS_DEMO) base64 = await toSmallJpegBase64(uri);
      const out = await analyzePhoto(base64, remaining.kcal, remaining.protein, demoKind);
      if ('error' in out) return setState(out.error === 'premium_required' ? 'premium' : out.error === 'not_configured' ? 'off' : 'error');
      if (out.kind === 'none') return setState('none');
      success();
      setResult(out.kind === 'meal' ? { ...out, items: out.items.map((i) => ({ ...i, on: true })) } : out);
      setState('result');
    } catch {
      warn();
      setState('error');
    }
  };

  const shoot = async () => {
    press();
    const pic = await cam.current?.takePictureAsync({ quality: 0.7 }).catch(() => null);
    if (pic?.uri) analyze(pic.uri);
  };

  const fromLibrary = async () => {
    const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.8 });
    if (!res.canceled && res.assets?.[0]) analyze(res.assets[0].uri);
  };

  const addItems = async (items: CameraItem[]) => {
    if (!session) return;
    for (const i of items) {
      await addFoodLog(session.user.id, {
        name: lang === 'ar' && i.name_ar ? i.name_ar : i.name_en,
        meal: mealNow(!!profile?.ramadan_mode),
        servings: 1,
        kcal: Math.round(i.kcal),
        protein_g: i.protein_g,
        carbs_g: i.carbs_g,
        fat_g: i.fat_g,
        source: 'photo',
      });
    }
    success();
    router.back();
  };

  const reset = () => {
    setPhoto(null);
    setResult(null);
    setState('live');
    locked.current = false;
  };

  if (!perm) return <View style={{ flex: 1, backgroundColor: '#000' }} />;
  if (!perm.granted)
    return (
      <View style={{ flex: 1, backgroundColor: theme.bg, padding: 24, justifyContent: 'center', gap: 16 }}>
        <Icon name="camera" size={40} />
        <Txt v="h1">{t('cameraTitle')}</Txt>
        <Txt muted>{t('cameraHint')}</Txt>
        <Button title={t('next')} onPress={requestPerm} />
        <Button title={t('close')} kind="ghost" onPress={() => router.back()} />
      </View>
    );

  return (
    <View style={{ flex: 1, backgroundColor: '#000' }}>
      {photo ? (
        <Image source={{ uri: photo }} style={StyleSheet.absoluteFill} contentFit="cover" />
      ) : (
        <CameraView
          ref={cam}
          style={StyleSheet.absoluteFill}
          facing="back"
          barcodeScannerSettings={{ barcodeTypes: ['qr', 'ean13', 'ean8', 'upc_a', 'upc_e'] }}
          onBarcodeScanned={state === 'live' ? ({ data }) => onCode(data) : undefined}
        />
      )}

      {/* frame + sweep */}
      {state === 'live' || state === 'thinking' ? (
        <View pointerEvents="none" style={{ ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' }}>
          <View style={{ width: 290, height: 320, borderRadius: 32, borderWidth: 2, borderColor: 'rgba(255,255,255,0.7)', overflow: 'hidden' }}>
            <Animated.View style={[{ height: 2, backgroundColor: theme.accent, marginTop: 8 }, sweepStyle]} />
          </View>
          {state === 'thinking' ? (
            <Animated.View entering={FadeIn} style={{ marginTop: 20, flexDirection: 'row', gap: 8, alignItems: 'center' }}>
              <Icon name="sparkle" color={theme.accent} />
              <Txt v="bodyStrong">{t('aiAnalyzing')}</Txt>
            </Animated.View>
          ) : (
            <Txt v="bodyStrong" center style={{ marginTop: 20, paddingHorizontal: 40 }}>{t('cameraHint')}</Txt>
          )}
        </View>
      ) : null}

      {/* close */}
      <Press
        onPress={() => router.back()}
        accessibilityLabel={t('close')}
        style={{ position: 'absolute', top: insets.top + 12, right: 18, width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(0,0,0,0.5)', alignItems: 'center', justifyContent: 'center' }}
      >
        <Icon name="close" />
      </Press>

      {/* bottom controls */}
      {state === 'live' ? (
        <View style={{ position: 'absolute', left: 0, right: 0, bottom: insets.bottom + 26, alignItems: 'center', gap: 16 }}>
          {IS_DEMO ? (
            <Row gap={8}>
              {[
                { l: 'Plate', f: () => analyze('', 'meal') },
                { l: 'Menu', f: () => analyze('', 'menu') },
                { l: 'Barcode', f: () => onCode('6291100000000') },
                { l: 'Run QR', f: () => onCode('HG-DEMO-1') },
              ].map((d) => (
                <Press key={d.l} onPress={d.f} style={{ backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: 999, paddingHorizontal: 12, paddingVertical: 8 }}>
                  <Txt v="small">{d.l}</Txt>
                </Press>
              ))}
            </Row>
          ) : null}
          <Row gap={44} style={{ alignItems: 'center' }}>
            <Press onPress={fromLibrary} accessibilityLabel={t('addPhoto')} style={{ width: 48, height: 48, borderRadius: 24, backgroundColor: 'rgba(0,0,0,0.5)', alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="search" />
            </Press>
            <Press onPress={shoot} haptic={false} scaleTo={0.88} accessibilityLabel={t('cameraTitle')} style={{ width: 80, height: 80, borderRadius: 40, borderWidth: 5, borderColor: '#fff', alignItems: 'center', justifyContent: 'center' }}>
              <View style={{ width: 62, height: 62, borderRadius: 31, backgroundColor: '#fff' }} />
            </Press>
            <View style={{ width: 48 }} />
          </Row>
        </View>
      ) : null}

      {/* result sheet */}
      {state !== 'live' && state !== 'thinking' ? (
        <Animated.View
          entering={SlideInDown.springify().damping(18)}
          style={{ position: 'absolute', left: 0, right: 0, bottom: 0, maxHeight: '75%', backgroundColor: theme.surface, borderTopLeftRadius: 30, borderTopRightRadius: 30, padding: 20, paddingBottom: insets.bottom + 16, gap: 12 }}
        >
          <ScrollView contentContainerStyle={{ gap: 10 }} showsVerticalScrollIndicator={false}>
            {state === 'premium' ? (
              <>
                <Txt v="h2">{t('premiumTitle')}</Txt>
                <Txt muted>{t('aiPremium')}</Txt>
                <Button title={t('premium')} onPress={() => router.replace('/premium')} />
              </>
            ) : null}
            {state === 'off' ? <Txt muted>{t('aiNotAvailable')}</Txt> : null}
            {state === 'none' ? <Txt muted>{t('cameraNone')}</Txt> : null}
            {state === 'error' ? <Txt muted>{t('error')}</Txt> : null}

            {state === 'result' && result?.kind === 'meal' ? (
              <>
                <Txt v="hero">{`${result.items.filter((i) => i.on).reduce((s, i) => s + i.kcal, 0)} ${t('kcal')}`}</Txt>
                {result.items.map((i, idx) => (
                  <Animated.View key={idx} entering={FadeInDown.delay(idx * 80).springify()}>
                    <Press
                      onPress={() => setResult({ ...result, items: result.items.map((x, j) => (j === idx ? { ...x, on: !x.on } : x)) })}
                      style={{ flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: theme.card, borderRadius: 18, padding: 14, opacity: i.on ? 1 : 0.4 }}
                    >
                      <View style={{ width: 26, height: 26, borderRadius: 13, backgroundColor: i.on ? theme.accent : theme.cardHigh, alignItems: 'center', justifyContent: 'center' }}>
                        {i.on ? <Icon name="check" size={16} color={theme.onAccent} stroke={2.6} /> : null}
                      </View>
                      <View style={{ flex: 1 }}>
                        <Txt v="bodyStrong">{lang === 'ar' ? i.name_ar : i.name_en}</Txt>
                        <Txt v="small" faint>{`${i.portion ?? ''} · ${Math.round(i.protein_g)}${t('g')} ${t('protein').toLowerCase()}`}</Txt>
                      </View>
                      <Txt v="bodyStrong">{Math.round(i.kcal)}</Txt>
                    </Press>
                  </Animated.View>
                ))}
                <Txt v="small" faint>{t('aiAccuracyNote')}</Txt>
                <Button title={t('add')} onPress={() => addItems(result.items.filter((i) => i.on))} />
              </>
            ) : null}

            {state === 'result' && result?.kind === 'menu' ? (
              <>
                <Txt v="label" muted>{t('menuBest', { kcal: remaining.kcal })}</Txt>
                {result.picks.map((p, idx) => (
                  <Animated.View key={idx} entering={FadeInDown.delay(idx * 90).springify()}>
                    <View style={{ backgroundColor: idx === 0 ? theme.accent : theme.card, borderRadius: 22, padding: 16, gap: 6 }}>
                      <Row style={{ justifyContent: 'space-between' }}>
                        <Txt v="h3" color={idx === 0 ? theme.onAccent : theme.text} style={{ flex: 1 }}>{lang === 'ar' ? p.name_ar : p.name_en}</Txt>
                        <Txt v="bodyStrong" color={idx === 0 ? theme.onAccent : theme.text}>{`${Math.round(p.kcal)} ${t('kcal')}`}</Txt>
                      </Row>
                      <Txt v="small" color={idx === 0 ? theme.onAccent : theme.muted}>{`${Math.round(p.protein_g)}${t('g')} ${t('protein').toLowerCase()} · ${lang === 'ar' ? p.tip_ar ?? '' : p.tip_en ?? ''}`}</Txt>
                      <Press onPress={() => addItems([p])} style={{ alignSelf: 'flex-start', marginTop: 4, backgroundColor: idx === 0 ? theme.onAccent : theme.cardHigh, borderRadius: 999, paddingHorizontal: 14, height: 34, justifyContent: 'center' }}>
                        <Txt v="bodyStrong" color={idx === 0 ? theme.accent : theme.text} style={{ fontSize: 13 }}>{t('iAteThis')}</Txt>
                      </Press>
                    </View>
                  </Animated.View>
                ))}
              </>
            ) : null}

            <Button title={t('tryAgain')} kind="ghost" onPress={reset} />
          </ScrollView>
        </Animated.View>
      ) : null}
    </View>
  );
}
