# Launch checklist

Work through this top to bottom. Tick each box before submitting to Apple.

## Brand & accounts
- [ ] Instagram, TikTok and X handle: `@habibigains.app`
- [ ] Domain `habibigains.app` (or `.com`) with a one-page site + waitlist
- [ ] Support email, e.g. `support@habibigains.app` (also set in `src/lib/config.ts`)
- [ ] Final app icon (1024×1024, no transparency) replaces `assets/icon.png`
- [ ] Splash image replaces `assets/splash.png`

## Legal (Apple requires these)
- [ ] Publish `docs/PRIVACY.md` at `https://habibigains.app/privacy`
- [ ] Publish `docs/TERMS.md` at `https://habibigains.app/terms`
- [ ] Check both with a lawyer before charging money (UAE PDPL applies to health data)
- [ ] In-app account deletion works (Settings → Delete account)
- [ ] Health disclaimer visible (onboarding plan screen, Timing coach, Why screen)

## Backend
- [ ] Supabase database created from the migration, seed loaded
- [ ] Email OTP, Apple and Google sign-in enabled and tested
- [ ] `food-photo`, `delete-account`, `revenuecat-webhook` deployed
- [ ] `ANTHROPIC_API_KEY` and `REVENUECAT_WEBHOOK_SECRET` set
- [ ] Your account is `admin`
- [ ] Supabase → Advisors shows no security warnings
- [ ] Upgrade to Supabase Pro before public launch (daily backups)

## Money
- [ ] Subscriptions created in App Store Connect and Play Console (AED 12 / AED 99)
- [ ] Paid Apps agreement + bank details completed in App Store Connect
- [ ] Small Business Program enrolled (15% instead of 30%)
- [ ] RevenueCat entitlement `premium`, offering with monthly + annual, webhook set
- [ ] Test purchase in TestFlight (sandbox) unlocks Premium and the smart camera

## Quality
- [ ] Test on a small iPhone (SE) and a big one (Pro Max)
- [ ] Test in Arabic: every screen reads right-to-left
- [ ] Test with no internet: app shows errors gracefully
- [ ] Test Ramadan mode with your emirate
- [ ] 20–50 friends on TestFlight for 2 weeks; fix what they report
- [ ] Add crash reporting (Sentry, free tier) before public launch

## App Store listing
- [ ] Copy from `docs/STORE_LISTING.md` (English + Arabic)
- [ ] 6.9" and 6.5" screenshots (record the showcase build, add headline text)
- [ ] App Privacy questionnaire: Health & Fitness, Contact Info (email), Photos, Purchases. Linked to user, not used for tracking
- [ ] Age rating: 12+ (health information)
- [ ] Review notes: give Apple a test email login and explain the smart camera needs Premium (provide a promo code)

## Launch week
- [ ] Post the 6 teaser stories over 6 days
- [ ] First free run club announced 2 weeks ahead (Corniche, Friday sunrise)
- [ ] Ask the first 50 users for App Store reviews after their first badge
