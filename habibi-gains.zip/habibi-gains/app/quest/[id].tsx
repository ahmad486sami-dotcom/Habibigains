import * as ImagePicker from 'expo-image-picker';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { awardBadge, completeQuest, fetchQuests, Quest } from '@/lib/data';
import { warn } from '@/lib/haptics';
import { useSession } from '@/lib/session';
import { uploadImage } from '@/lib/supabase';
import { useTheme } from '@/theme/theme';
import { useCelebrate } from '@/ui/Celebrate';
import { Bar } from '@/ui/Graphics';
import { Icon } from '@/ui/Icon';
import { Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function QuestDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { t, lang } = useI18n();
  const { theme } = useTheme();
  const celebrate = useCelebrate();
  const { session, refreshProfile } = useSession();
  const [q, setQ] = useState<(Quest & { done: boolean }) | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    fetchQuests().then((all) => setQ(all.find((x) => x.id === id) ?? null)).catch(() => {});
  }, [id]);

  if (!q) return <View style={{ flex: 1, backgroundColor: theme.bg }} />;
  const title = lang === 'ar' && q.title_ar ? q.title_ar : q.title_en;

  const finish = async () => {
    if (!session) return;
    setBusy(true);
    try {
      let proof: string | null = null;
      if (q.proof === 'photo') {
        const res = await ImagePicker.launchCameraAsync({ mediaTypes: ['images'], quality: 0.7 }).catch(() => null);
        const pick = res && !res.canceled ? res : await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.7 });
        if (!pick || pick.canceled || !pick.assets?.[0]) return;
        proof = await uploadImage('quests', session.user.id, pick.assets[0].uri);
      }
      const r = await completeQuest(q.id, proof);
      if (!r.ok) return warn();
      await awardBadge('first-quest');
      refreshProfile();
      router.back();
      setTimeout(() => celebrate({ title, subtitle: `+${q.xp} XP`, icon: 'star' }), 300);
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.bg, padding: 20, gap: 18 }}>
      <Row style={{ justifyContent: 'flex-end' }}>
        <Press onPress={() => router.back()} accessibilityLabel={t('close')} style={{ padding: 6 }}>
          <Icon name="close" />
        </Press>
      </Row>
      <View style={{ alignSelf: 'flex-start', borderWidth: 2, borderColor: theme.text, borderRadius: 999, paddingHorizontal: 14, paddingVertical: 6 }}>
        <Txt v="label">{t('sideQuest')}</Txt>
      </View>
      <Txt v="hero">{title}</Txt>
      {q.description ? <Txt muted>{q.description}</Txt> : null}
      <Txt v="h3" color={theme.accent}>{`+${q.xp} XP`}</Txt>
      <View style={{ flex: 1 }} />
      {q.done ? (
        <Button title={t('completed')} kind="secondary" disabled />
      ) : (
        <Button
          title={q.proof === 'photo' ? t('snapProof') : t('complete')}
          icon={q.proof === 'photo' ? <Icon name="camera" color={theme.onAccent} size={20} /> : undefined}
          loading={busy}
          onPress={finish}
        />
      )}
    </View>
  );
}
