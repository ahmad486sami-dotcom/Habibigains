# How to get the HG Showcase .ipa (free)

GitHub has free Mac computers that can build iPhone apps. You upload the project, press one button,
wait ~25 minutes, and download the .ipa. Then you sign it with ESign like any other .ipa.

No Mac, no Apple Developer account and no Supabase needed. The showcase runs fully offline with demo data.

---

## Fastest option: let Claude upload it
1. On github.com, tap **+ → New repository**, name it `habibi-gains`, choose **Private**, and tap **Create**.
   Leave it empty.
2. Send Claude the link (e.g. `github.com/yourname/habibi-gains`).
3. Claude pushes the whole project in one go. Skip to **Step 3** below.

---

## Do it yourself

### Step 1: Create the repository
1. Go to **github.com** and sign up or log in.
2. Tap **+ → New repository**.
3. Name: `habibi-gains`. Choose **Private**. Tap **Create repository**.

### Step 2: Upload the files (needs a laptop)
1. Unzip this file on your laptop. You get a folder called `habibi-gains`.
2. In your new repository, click **uploading an existing file**.
3. Open the `habibi-gains` folder, select **everything inside it**, and drag it onto the page.
4. Click **Commit changes**.

⚠️ **Important:** laptops often skip hidden folders, so the `.github` folder (the build robot) may not upload.
Check: if your repository has no `.github` folder, do this:
1. In the repository, click **Add file → Create new file**.
2. Name it exactly: `.github/workflows/showcase-ipa.yml`
3. Open `showcase-ipa.yml` from the zip (inside `.github/workflows/`) in any text editor, copy everything, and paste it in.
4. Click **Commit changes**.

### Step 3: Build the .ipa
1. In the repository, open the **Actions** tab. If asked, tap **I understand, enable workflows**.
2. On the left, choose **Showcase IPA**.
3. Tap **Run workflow → Run workflow**.
4. Wait ~20–30 minutes. A green tick means it's done. A red cross means something failed (see below).

### Step 4: Download and install
1. Open the finished run and scroll to **Artifacts**.
2. Download **HG-Showcase-ipa**. It downloads as a `.zip`, so unzip it to get `HG-Showcase.ipa`.
3. Open `HG-Showcase.ipa` in **ESign**, sign it, and install.
4. The app appears as **HG Showcase** with the dumbbell icon.

---

## If the build fails
Open the failed run, tap the step with the red cross, scroll to the bottom, copy the last ~30 lines
and send them to Claude. Small fixes are normal for a first build.

## Notes
- Private repositories get free Mac build minutes each month. Each build uses part of that.
  If you run out, make the repository **Public** (Settings → Danger zone → Change visibility),
  which has no minute limit.
- ESign certificates can be revoked by Apple at any time. If the app stops opening, just re-sign it.
- Apple Health and real payments don't work in the showcase. Everything shown is demo data.
- For the real App Store version, follow section C of `README.md`.
