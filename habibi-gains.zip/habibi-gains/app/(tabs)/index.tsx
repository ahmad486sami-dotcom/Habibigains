// Today: three things only. Weight trend, calories left, and one swipeable "For you" card.
import { router } from 'expo-router';
import React, { useEffect, useMemo, useState } from 'react';
import { Dimensions, FlatList, RefreshControl, View } from 'react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { useI18n } from '@/i18n/i18n';
import { fetchQuests, getWater, Quest } from '@/lib/data';
import { Emirate, fastingTimes, formatLeft, isRamadanNow, ramadanStatus } from '@/lib/ramadan';
import { useSession } from '@/lib/session';
import { buildTiming } from '@/lib/timing';
import { useToday } from '@/lib/useToday';
import { useTheme } from '@/theme/theme';
import { Bar, Ring, Ticker, TrendChart } from '@/ui/Graphics';
import { Icon, IconName } from '@/ui/Icon';
import { Card, Row, Screen } from '@/ui/Layout';
import { Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

const W = Dimensions.get('window').width;
const CARD_W = W - 40;

type ForYou = { key: string; icon: IconName; label: string; title: string; body?: string; dark?: boolean; cta?: string; onPress?: () => void; onCta?: () => void };

export default function Today() {
  const { t, lang } = useI18n();
  const { theme } = useTheme();
  const { profile, updateProfile } = useSession();
  const d = useToday(profile);
  const [quest, setQuest] = useState<(Quest & { done: boolean }) | null>(null);
  const [water, setWater] = useState(0);
  const [now, setNow] = useState(new Date());
  const [page, setPage] = useState(0);

  const target = profile?.calorie_target ?? 2000;
  const proteinTarget = profile?.protein_target_g ?? 140;
  const left = target - d.totals.kcal;
  const emirate = (profile?.emirate ?? 'Abu Dhabi') as Emirate;

  useEffect(() => {
    fetchQuests().then((q) => setQuest(q.find((x) => !x.done) ?? null)).catch(() => {});
    const i = setInterval(() => setNow(new Date()), 60_000);
    return () => clearInterval(i);
  }, []);
  useEffect(() => {
    getWater().then(setWater).catch(() => {});
  }, [d.totals.kcal]);

  const ramadan = profile?.ramadan_mode ? ramadanStatus(emirate, now) : null;
  const suggestRamadan = !profile?.ramadan_mode && isRamadanNow(now);

  const nextUp = useMemo(() => {
    if (!profile) return null;
    const items = buildTiming({
      weightKg: d.last?.trend ?? Number(profile.start_weight_kg ?? 75),
      wake: profile.wake_time,
      sleep: profile.sleep_time,
      training: profile.training_time,
      goal: profile.goal,
      proteinTargetG: proteinTarget,
      useCreatine: profile.use_creatine,
      useCaffeine: profile.use_caffeine,
      ramadan: profile.ramadan_mode ? fastingTimes(emirate, now) : null,
    });
    const mins = now.getHours() * 60 + now.getMinutes();
    return items.find((i) => {
      const [h, m] = i.time.split(':').map(Number);
      return h * 60 + m >= mins;
    }) ?? items[0];
  }, [profile, d.last, now, proteinTarget, emirate]);

  // Build the "For you" deck, most useful first.
  const cards: ForYou[] = [];
  if (suggestRamadan)
    cards.push({ key: 'ramadan', icon: 'moon', label: t('ramadanMode'), title: t('ramadanSuggest'), cta: t('turnOn'), onCta: () => updateProfile({ ramadan_mode: true }) });
  if (d.suggested && d.measured && Math.abs(d.suggested.kcal - target) >= 80)
    cards.push({
      key: 'tdee', icon: 'bolt', label: t('measuredTitle'), title: t('measuredBody', { tdee: d.measured.toLocaleString('en-US') }),
      body: t('measuredSuggest', { kcal: d.suggested.kcal.toLocaleString('en-US') }), cta: t('applyTarget'),
      onCta: () => updateProfile({ calorie_target: d.suggested!.kcal, protein_target_g: d.suggested!.protein }), onPress: () => router.push('/why'),
    });
  if (nextUp)
    cards.push({ key: 'next', icon: 'clock', label: `${t('nextUp')} · ${nextUp.time}`, title: t(`tm_${nextUp.titleKey}` as 'tm_lunch'), body: nextUp.detail[lang], onPress: () => router.push('/timing') });
  if (quest)
    cards.push({ key: 'quest', icon: 'star', dark: true, label: `${t('sideQuest')} · +${quest.xp} XP`, title: lang === 'ar' && quest.title_ar ? quest.title_ar : quest.title_en, onPress: () => router.push({ pathname: '/quest/[id]', params: { id: quest.id } }) });
  cards.push({ key: 'supps', icon: 'pill', label: lang === 'ar' ? 'دليل المكملات' : 'Supplement guide', title: lang === 'ar' ? 'وش يشتغل فعلاً ووش لا' : 'What works, and what is a waste of money', onPress: () => router.push('/supplements') });

  const change = d.last && d.startWeight ? d.last.trend - Number(d.startWeight) : 0;
  const paceText = { too_fast: t('paceTooFast'), stalled: t('paceStalled'), on_track: t('paceOnTrack'), drifting: t('paceDrifting'), unknown: t('paceUnknown') }[d.pace];

  return (
    <Screen refreshControl={<RefreshControl refreshing={false} onRefresh={d.reload} tintColor={theme.muted} />}>
      {/* Header */}
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="h1" numberOfLines={1} style={{ flex: 1 }}>{t('greeting', { name: profile?.display_name?.split(' ')[0] ?? 'habibi' })}</Txt>
        <Row gap={8}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: theme.card, borderRadius: 999, paddingHorizontal: 12, height: 38 }}>
            <Icon name="flame" size={16} color={theme.accent} />
            <Txt v="bodyStrong">{profile?.streak_days ?? 0}</Txt>
          </View>
          <Press onPress={() => router.push('/settings')} accessibilityLabel={t('settings')} style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: theme.card, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="settings" size={18} />
          </Press>
        </Row>
      </Row>

      {ramadan ? (
        <Animated.View entering={FadeInDown.springify()} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: theme.card, borderRadius: 999, paddingHorizontal: 16, height: 44 }}>
          <Icon name="moon" size={18} color={theme.accent} />
          <Txt v="bodyStrong">
            {ramadan.kind === 'iftar' ? t('ramadanBanner', { t: formatLeft(ramadan.msLeft) }) : t('suhoorBanner', { t: formatLeft(ramadan.msLeft) })}
          </Txt>
        </Animated.View>
      ) : null}

      {/* 1 · Weight trend */}
      <Card index={0} onPress={() => router.push('/(tabs)/progress')}>
        <Row style={{ justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <View>
            <Txt v="label" muted>{t('trendWeight')}</Txt>
            {d.last ? <Ticker value={d.last.trend} decimals={1} suffix={` ${t('kg')}`} /> : <Txt v="number">—</Txt>}
          </View>
          {d.last && d.startWeight ? <Txt v="h3" color={theme.accent}>{`${change > 0 ? '+' : ''}${change.toFixed(1)} ${t('kg')}`}</Txt> : null}
        </Row>
        {d.trend.length > 1 ? <TrendChart points={d.trend.slice(-45)} width={W - 76} height={84} /> : null}
        <Txt v="small" muted>
          {d.goalDate && profile?.goal_weight_kg
            ? t('onPace', { kg: profile.goal_weight_kg, date: d.goalDate.toLocaleDateString(lang === 'ar' ? 'ar-AE' : 'en-GB', { day: 'numeric', month: 'short' }) })
            : d.trend.length > 1 ? paceText : t('noTrendYet')}
        </Txt>
      </Card>

      {/* 2 · Calories + protein */}
      <Card index={1} onPress={() => router.push('/(tabs)/food')}>
        <Row gap={18}>
          <Ring size={124} stroke={12} progress={d.totals.kcal / target}>
            <Ticker value={Math.abs(left)} v="h2" />
            <Txt v="small" muted style={{ fontSize: 11 }}>{left >= 0 ? t('kcalLeft') : t('kcalOver')}</Txt>
          </Ring>
          <View style={{ flex: 1, gap: 14 }}>
            <View style={{ gap: 6 }}>
              <Row style={{ justifyContent: 'space-between' }}>
                <Txt v="small" muted>{t('protein')}</Txt>
                <Txt v="small">{`${Math.round(d.totals.protein)}/${proteinTarget}${t('g')}`}</Txt>
              </Row>
              <Bar progress={d.totals.protein / proteinTarget} />
            </View>
            <View style={{ gap: 6 }}>
              <Row style={{ justifyContent: 'space-between' }}>
                <Txt v="small" muted>{lang === 'ar' ? 'الماء' : 'Water'}</Txt>
                <Txt v="small">{`${(water / 1000).toFixed(1)}/${((profile?.water_goal_ml ?? 3000) / 1000).toFixed(1)} L`}</Txt>
              </Row>
              <Bar progress={water / (profile?.water_goal_ml ?? 3000)} />
            </View>
          </View>
        </Row>
      </Card>

      {/* 3 · For you */}
      {cards.length ? (
        <Animated.View entering={FadeInDown.delay(140).springify()} style={{ marginHorizontal: -20 }}>
          <FlatList
            data={cards}
            horizontal
            pagingEnabled={false}
            snapToInterval={CARD_W + 10}
            decelerationRate="fast"
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 20, gap: 10 }}
            keyExtractor={(c) => c.key}
            onMomentumScrollEnd={(e) => setPage(Math.round(e.nativeEvent.contentOffset.x / (CARD_W + 10)))}
            renderItem={({ item: c }) => {
              const fg = c.dark ? theme.bg : theme.text;
              const sub = c.dark ? theme.bg : theme.muted;
              return (
                <Press onPress={c.onPress} scaleTo={0.98} haptic={!!c.onPress} style={{ width: CARD_W, minHeight: 150, backgroundColor: c.dark ? theme.text : theme.card, borderRadius: 28, padding: 18, gap: 8 }}>
                  <Row style={{ justifyContent: 'space-between' }}>
                    <Txt v="label" color={sub}>{c.label}</Txt>
                    <Icon name={c.icon} size={18} color={c.dark ? theme.bg : theme.accent} />
                  </Row>
                  <Txt v="h2" color={fg}>{c.title}</Txt>
                  {c.body ? <Txt v="small" color={sub} numberOfLines={3}>{c.body}</Txt> : null}
                  {c.cta ? (
                    <Press onPress={c.onCta} style={{ alignSelf: 'flex-start', marginTop: 4, backgroundColor: theme.accent, borderRadius: 999, paddingHorizontal: 16, height: 38, justifyContent: 'center' }}>
                      <Txt v="bodyStrong" color={theme.onAccent} style={{ fontSize: 14 }}>{c.cta}</Txt>
                    </Press>
                  ) : null}
                </Press>
              );
            }}
          />
          {cards.length > 1 ? (
            <Row gap={6} style={{ alignSelf: 'center', marginTop: 10 }}>
              {cards.map((c, i) => (
                <View key={c.key} style={{ width: i === page ? 18 : 6, height: 6, borderRadius: 3, backgroundColor: i === page ? theme.text : theme.faint }} />
              ))}
            </Row>
          ) : null}
        </Animated.View>
      ) : null}
    </Screen>
  );
}
