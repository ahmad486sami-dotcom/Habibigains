// Instagram-ready story cards (1080 × 1920): your profile, or your week.
// Two looks: dark card, or a transparent sticker to drop on your own photo.
import { router } from 'expo-router';
import * as Sharing from 'expo-sharing';
import React, { useEffect, useRef, useState } from 'react';
import { Alert, Dimensions, ScrollView, View } from 'react-native';
import { captureRef } from 'react-native-view-shot';
import { useI18n } from '@/i18n/i18n';
import { fetchDailyTotals, fetchDayLogs, sumNutrients } from '@/lib/data';
import { success, warn } from '@/lib/haptics';
import { useSession } from '@/lib/session';
import { getProfileCard, ProfileCard } from '@/lib/social';
import { fmtWeight, unitsOf } from '@/lib/units';
import { buildWeek } from '@/lib/week';
import { useTheme } from '@/theme/theme';
import { Avatar } from '@/ui/Avatar';
import { Icon } from '@/ui/Icon';
import { Chips, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

const W = Math.min(Dimensions.get('window').width - 80, 320);
const H = (W * 16) / 9;

export default function ShareProfile() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { profile, session } = useSession();
  const units = unitsOf(profile);
  const ref = useRef<View>(null);
  const [kind, setKind] = useState<'profile' | 'week'>('profile');
  const [look, setLook] = useState<'dark' | 'sticker'>('dark');
  const [card, setCard] = useState<ProfileCard | null>(null);
  const [daily, setDaily] = useState<{ day: string; kcal: number }[]>([]);
  const [todayKcal, setTodayKcal] = useState(0);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (session) getProfileCard(session.user.id).then(setCard).catch(() => {});
    fetchDailyTotals(14).then(setDaily).catch(() => {});
    fetchDayLogs().then((l) => setTodayKcal(sumNutrients(l).kcal)).catch(() => {});
  }, [session]);

  const target = profile?.calorie_target ?? 2000;
  const week = buildWeek(daily, todayKcal, target, lang, profile?.week_start_day ?? 6);
  const sticker = look === 'sticker';
  const bg = sticker ? 'transparent' : '#0A0B0D';
  const fg = '#FFFFFF';
  const dim = 'rgba(255,255,255,0.6)';

  const share = async () => {
    if (!ref.current) return;
    setBusy(true);
    try {
      const uri = await captureRef(ref, { format: 'png', quality: 1, width: 1080, height: 1920 });
      success();
      await Sharing.shareAsync(uri, { mimeType: 'image/png', UTI: 'public.png' });
    } catch {
      warn();
      Alert.alert(L('Could not create the image', 'ما قدرنا نسوي الصورة'));
    } finally {
      setBusy(false);
    }
  };

  const big = (v: string, l: string) => (
    <View style={{ alignItems: 'center', flex: 1 }}>
      <Txt v="h2" color={fg}>{v}</Txt>
      <Txt v="small" color={dim} style={{ fontSize: 10, letterSpacing: 1 }}>{l.toUpperCase()}</Txt>
    </View>
  );

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ padding: 20, gap: 14, alignItems: 'center', paddingBottom: 60 }}>
      <Row style={{ justifyContent: 'space-between', alignSelf: 'stretch' }}>
        <Txt v="h2">{L('Share to your story', 'شارك في الستوري')}</Txt>
        <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
      </Row>
      <Chips value={kind} onChange={setKind} options={[{ value: 'profile', label: L('Profile', 'الحساب') }, { value: 'week', label: L('My week', 'أسبوعي') }]} />
      <Chips value={look} onChange={setLook} options={[{ value: 'dark', label: L('Dark card', 'بطاقة داكنة') }, { value: 'sticker', label: L('Sticker (no background)', 'ملصق شفاف') }]} />

      <View style={{ borderRadius: 24, overflow: 'hidden', borderWidth: 1, borderColor: theme.cardHigh, backgroundColor: sticker ? '#3A3D42' : bg }}>
        <View ref={ref} collapsable={false} style={{ width: W, height: H, backgroundColor: bg, padding: 24, justifyContent: 'space-between' }}>
          <Row style={{ justifyContent: 'space-between' }}>
            <Txt v="label" color={fg} style={{ letterSpacing: 2 }}>HABIBI GAINS</Txt>
            <Txt v="small" color={dim}>{new Date().toLocaleDateString(lang === 'ar' ? 'ar-AE' : 'en-GB', { day: 'numeric', month: 'short' })}</Txt>
          </Row>

          {kind === 'profile' ? (
            <View style={{ alignItems: 'center', gap: 10 }}>
              <Avatar url={profile?.avatar_url} name={profile?.display_name} size={W * 0.36} />
              <Txt v="h1" color={fg} center>{profile?.display_name ?? ''}</Txt>
              {profile?.username ? <Txt color={dim}>{`@${profile.username}`}</Txt> : null}
              {profile?.gym ? <Txt v="bodyStrong" color={theme.accent}>{profile.gym}</Txt> : null}
              <Row style={{ marginTop: 18, alignSelf: 'stretch' }}>
                {big(String(profile?.streak_days ?? 0), L('day streak', 'سلسلة'))}
                {card?.kg_lost != null ? big(fmtWeight(Math.max(0, card.kg_lost), units), L('lost', 'خسرت')) : null}
                {card?.steps_today != null ? big(card.steps_today.toLocaleString('en-US'), L('steps', 'خطوات')) : null}
              </Row>
            </View>
          ) : (
            <View style={{ gap: 18 }}>
              <Txt v="h1" color={fg}>{L('My week', 'أسبوعي')}</Txt>
              <Row style={{ justifyContent: 'space-between' }}>
                {week.days.map((d) => (
                  <View key={d.day} style={{ alignItems: 'center', gap: 6 }}>
                    <Txt v="small" color={dim} style={{ fontSize: 10 }}>{d.label}</Txt>
                    <View style={{ width: W / 10, height: W / 10, borderRadius: W / 20, backgroundColor: d.status === 'under' ? theme.accent : d.status === 'over' ? '#FF7A59' : 'rgba(255,255,255,0.15)' }} />
                  </View>
                ))}
              </Row>
              <Row>
                {big(Math.round(week.eaten).toLocaleString('en-US'), L('eaten', 'أكلت'))}
                {big(Math.round(week.budget).toLocaleString('en-US'), L('budget', 'الميزانية'))}
                {big(Math.abs(Math.round(week.left)).toLocaleString('en-US'), week.left >= 0 ? L('left', 'متبقي') : L('over', 'زيادة'))}
              </Row>
              <Txt v="small" color={dim} center>{L(`${week.logged} of 7 days logged`, `${week.logged} من ٧ أيام`)}</Txt>
            </View>
          )}

          <Txt v="small" color={dim} center>{profile?.username ? `@${profile.username} · habibigains.store` : 'habibigains.store'}</Txt>
        </View>
      </View>
      <Button title={L('Share', 'مشاركة')} icon={<Icon name="share" size={18} color={theme.onAccent} />} loading={busy} onPress={share} style={{ alignSelf: 'stretch' }} />
      <Txt v="small" faint center>{L('Opens Instagram, WhatsApp, Snapchat, Save Image and more.', 'يفتح انستغرام وواتساب وسناب وحفظ الصورة.')}</Txt>
    </ScrollView>
  );
}
