// Evidence-based targets. Every number here has a source in SOURCES below,
// and the app shows them on the "Why this number?" screen.
//
// 1. Starting energy estimate: Mifflin-St Jeor equation × activity factor.        [MSJ]
// 2. Rate of change, not a fixed deficit:
//      fat loss   0.5–1.0 % body weight / week (default 0.7 %)                     [HELMS]
//      lean gain  0.25–0.5 % body weight / week (default 0.35 %)                   [IRAKI]
//    using ~7,700 kcal per kg of body-weight change.                               [HALL]
// 3. Protein: 1.6 g/kg/day is where extra protein stops adding muscle on average;
//    up to ~2.2 g/kg while dieting to protect muscle.                              [MORTON][HELMS]
//    For BMI > 30, protein is based on the weight at BMI 25 so it isn't inflated.
// 4. Adaptive expenditure: after 14+ days, real TDEE = average intake − (trend
//    change in kg/day × 7,700). This replaces formula guesses with your own data. [HALL]
// 5. Floors: never below 1,500 kcal (men) / 1,200 kcal (women) without a doctor.

export type Sex = 'male' | 'female';
export type Goal = 'lose' | 'maintain' | 'gain';
export type Activity = 'low' | 'light' | 'moderate' | 'high';

const ACTIVITY: Record<Activity, number> = { low: 1.2, light: 1.375, moderate: 1.55, high: 1.725 };
export const KCAL_PER_KG = 7700;
export const RATE = { lose: 0.007, gain: 0.0035 }; // fraction of body weight per week

export function proteinReferenceKg(weightKg: number, heightCm: number) {
  const h = heightCm / 100;
  const bmi = weightKg / (h * h);
  return bmi > 30 ? 25 * h * h : weightKg;
}

export function formulaTDEE(i: { sex: Sex; birthYear: number; heightCm: number; weightKg: number; activity: Activity }) {
  const age = new Date().getFullYear() - i.birthYear;
  const bmr = 10 * i.weightKg + 6.25 * i.heightCm - 5 * age + (i.sex === 'male' ? 5 : -161);
  return bmr * ACTIVITY[i.activity];
}

export function calcTargets(input: {
  sex: Sex;
  birthYear: number;
  heightCm: number;
  weightKg: number;
  goal: Goal;
  activity: Activity;
  measuredTDEE?: number | null;
}) {
  const tdee = input.measuredTDEE ?? formulaTDEE(input);

  let kcal = tdee;
  if (input.goal === 'lose') {
    const deficit = (input.weightKg * RATE.lose * KCAL_PER_KG) / 7;
    kcal = tdee - Math.min(deficit, tdee * 0.25);
  }
  if (input.goal === 'gain') {
    kcal = tdee + (input.weightKg * RATE.gain * KCAL_PER_KG) / 7;
  }
  const floor = input.sex === 'male' ? 1500 : 1200;
  kcal = Math.max(floor, Math.round(kcal / 10) * 10);

  const ref = proteinReferenceKg(input.weightKg, input.heightCm);
  const perKg = input.goal === 'lose' ? 2.0 : 1.6;
  const protein = Math.round(ref * perKg);

  const weeklyChangeKg =
    input.goal === 'lose' ? -input.weightKg * RATE.lose : input.goal === 'gain' ? input.weightKg * RATE.gain : 0;

  return {
    kcal,
    protein,
    tdee: Math.round(tdee),
    weeklyChangeKg: Math.round(weeklyChangeKg * 100) / 100,
    source: input.measuredTDEE ? ('measured' as const) : ('formula' as const),
  };
}

/**
 * Measured TDEE from the user's own data.
 * days: one entry per calendar day with total logged kcal (only days with real logging).
 * trendChangeKgPerDay: slope of the smoothed weight trend over the same window.
 */
export function measuredTDEE(days: { kcal: number }[], trendChangeKgPerDay: number | null) {
  const logged = days.filter((d) => d.kcal >= 800); // ignore days that were clearly not fully logged
  if (logged.length < 14 || trendChangeKgPerDay === null) return null;
  const avgIntake = logged.reduce((s, d) => s + d.kcal, 0) / logged.length;
  const tdee = avgIntake - trendChangeKgPerDay * KCAL_PER_KG;
  return tdee > 1000 && tdee < 6000 ? Math.round(tdee) : null;
}

/** Honest feedback on pace. */
export function paceCheck(goal: Goal, weeklyRatePct: number | null) {
  if (weeklyRatePct === null) return 'unknown' as const;
  if (goal === 'lose') {
    if (weeklyRatePct < -1.0) return 'too_fast' as const;
    if (weeklyRatePct > -0.15) return 'stalled' as const;
    return 'on_track' as const;
  }
  if (goal === 'gain') {
    if (weeklyRatePct > 0.6) return 'too_fast' as const;
    if (weeklyRatePct < 0.1) return 'stalled' as const;
    return 'on_track' as const;
  }
  return Math.abs(weeklyRatePct) > 0.3 ? ('drifting' as const) : ('on_track' as const);
}

export function sumDay(logs: { kcal: number; protein_g: number; carbs_g: number; fat_g: number }[]) {
  return logs.reduce(
    (a, l) => ({
      kcal: a.kcal + Number(l.kcal || 0),
      protein: a.protein + Number(l.protein_g || 0),
      carbs: a.carbs + Number(l.carbs_g || 0),
      fat: a.fat + Number(l.fat_g || 0),
    }),
    { kcal: 0, protein: 0, carbs: 0, fat: 0 },
  );
}

export const SOURCES = {
  MSJ: 'Mifflin MD, St Jeor ST et al. A new predictive equation for resting energy expenditure in healthy individuals. Am J Clin Nutr. 1990.',
  HELMS: 'Helms ER, Aragon AA, Fitschen PJ. Evidence-based recommendations for natural bodybuilding contest preparation: nutrition and supplementation. J Int Soc Sports Nutr. 2014.',
  IRAKI: 'Iraki J, Fitschen P, Espinar S, Helms E. Nutrition recommendations for bodybuilders in the off-season: a narrative review. Sports. 2019.',
  MORTON: 'Morton RW et al. A systematic review, meta-analysis and meta-regression of the effect of protein supplementation on resistance training-induced gains in muscle mass and strength. Br J Sports Med. 2018.',
  HALL: 'Hall KD. What is the required energy deficit per unit weight loss? Int J Obes. 2008.',
};
