// Add friends: search by @username, or find people from your phone contacts.
import * as Contacts from 'expo-contacts';
import { router } from 'expo-router';
import React, { useEffect, useRef, useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { success } from '@/lib/haptics';
import { matchContacts, Person, searchPeople, sendRequest } from '@/lib/social';
import { useTheme } from '@/theme/theme';
import { Avatar } from '@/ui/Avatar';
import { Icon } from '@/ui/Icon';
import { Card, Field, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function FriendsAdd() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const [q, setQ] = useState('');
  const [results, setResults] = useState<Person[]>([]);
  const [fromContacts, setFromContacts] = useState<Person[] | null>(null);
  const [sent, setSent] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const seq = useRef(0);

  useEffect(() => {
    const id = ++seq.current;
    const h = setTimeout(() => searchPeople(q).then((r) => id === seq.current && setResults(r)).catch(() => {}), 250);
    return () => clearTimeout(h);
  }, [q]);

  const add = async (p: Person) => {
    try {
      await sendRequest(p.id);
      setSent((s) => [...s, p.id]);
      success();
    } catch {
      setSent((s) => [...s, p.id]); // already requested or already friends
    }
  };

  const scanContacts = async () => {
    setBusy(true);
    try {
      const { status } = await Contacts.requestPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert(L('Contacts not allowed', 'لم يتم السماح'), L('You can still add friends by @username.', 'تقدر تضيف أصحابك باسم المستخدم.'));
        return;
      }
      const { data } = await Contacts.getContactsAsync({ fields: [Contacts.Fields.PhoneNumbers] });
      const numbers = data.flatMap((c) => (c.phoneNumbers ?? []).map((n) => n.number ?? '')).filter(Boolean);
      setFromContacts(await matchContacts(numbers));
    } catch {
      setFromContacts([]);
    } finally {
      setBusy(false);
    }
  };

  const row = (p: Person) => (
    <Row key={p.id} style={{ justifyContent: 'space-between', paddingVertical: 4 }}>
      <Press onPress={() => router.push({ pathname: '/user/[id]', params: { id: p.id } })} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 }}>
        <Avatar url={p.avatar_url} name={p.display_name ?? p.username} size={40} />
        <View style={{ flex: 1 }}>
          <Txt v="bodyStrong">{p.display_name ?? p.username}</Txt>
          {p.username ? <Txt v="small" faint>{`@${p.username}`}</Txt> : null}
        </View>
      </Press>
      <Press onPress={() => add(p)} disabled={sent.includes(p.id)} style={{ paddingHorizontal: 14, height: 34, borderRadius: 17, backgroundColor: sent.includes(p.id) ? theme.cardHigh : theme.accent, justifyContent: 'center' }}>
        <Txt v="bodyStrong" color={sent.includes(p.id) ? theme.muted : theme.onAccent} style={{ fontSize: 13 }}>{sent.includes(p.id) ? L('Sent', 'تم') : L('Add', 'أضف')}</Txt>
      </Press>
    </Row>
  );

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: theme.bg }}>
      <ScrollView contentContainerStyle={{ padding: 20, gap: 14, paddingBottom: 60 }} keyboardShouldPersistTaps="handled">
        <Row style={{ justifyContent: 'space-between' }}>
          <Txt v="h2">{L('Add friends', 'أضف أصحاب')}</Txt>
          <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
        </Row>
        <Field label={L('Search @username', 'ابحث باسم المستخدم')} value={q} onChangeText={setQ} autoCapitalize="none" autoCorrect={false} placeholder="@ahmad" autoFocus />
        {results.length ? <Card>{results.map(row)}</Card> : q.trim().length >= 2 ? <Txt muted>{L('No one with that username yet.', 'ما في أحد بهالاسم.')}</Txt> : null}

        <Txt v="label" muted style={{ marginTop: 8 }}>{L('From your contacts', 'من جهات الاتصال')}</Txt>
        {fromContacts === null ? (
          <Button kind="secondary" title={L('Find friends from contacts', 'ابحث في جهات الاتصال')} loading={busy} onPress={scanContacts} />
        ) : fromContacts.length ? (
          <Card>{fromContacts.map(row)}</Card>
        ) : (
          <Txt muted>{L('None of your contacts are on Habibi Gains yet (or they turned off "find me from contacts").', 'ما لقينا أحد من جهات اتصالك بعد.')}</Txt>
        )}
        <Txt v="small" faint>{L('Numbers are scrambled on your phone before matching; your contacts are never uploaded or saved.', 'الأرقام تُشفّر على جهازك ولا تُرفع أو تُحفظ.')}</Txt>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
