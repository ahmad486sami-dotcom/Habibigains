import { Redirect } from 'expo-router';
import React from 'react';
import { View } from 'react-native';
import { needsOnboarding, useSession } from '@/lib/session';

export default function Index() {
  const { session, profile, loading } = useSession();
  if (loading) return <View style={{ flex: 1, backgroundColor: '#000' }} />;
  if (!session) return <Redirect href="/(auth)/welcome" />;
  if (!profile) return <View style={{ flex: 1, backgroundColor: '#000' }} />;
  if (needsOnboarding(profile)) return <Redirect href="/onboarding" />;
  return <Redirect href="/(tabs)" />;
}
