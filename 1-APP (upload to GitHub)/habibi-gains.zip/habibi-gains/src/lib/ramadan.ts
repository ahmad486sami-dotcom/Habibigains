// Approximate suhoor (Fajr) and iftar (Maghrib) times for UAE cities, calculated on the phone.
// Uses the NOAA solar position formulas. Fajr uses the sun 18.2° below the horizon
// (close to the UAE's official method); Maghrib is sunset. Times can differ from the
// official calendar by a few minutes, so the app shows them as a guide.

export const EMIRATES = {
  'Abu Dhabi': { lat: 24.4539, lng: 54.3773 },
  Dubai: { lat: 25.2048, lng: 55.2708 },
  Sharjah: { lat: 25.3463, lng: 55.4209 },
  Ajman: { lat: 25.4052, lng: 55.5136 },
  'Umm Al Quwain': { lat: 25.5647, lng: 55.5552 },
  'Ras Al Khaimah': { lat: 25.8007, lng: 55.9762 },
  Fujairah: { lat: 25.1288, lng: 56.3265 },
  'Al Ain': { lat: 24.2075, lng: 55.7447 },
} as const;
export type Emirate = keyof typeof EMIRATES;

const TZ_HOURS = 4; // Gulf Standard Time, no daylight saving
const rad = (d: number) => (d * Math.PI) / 180;
const deg = (r: number) => (r * 180) / Math.PI;

function solar(date: Date) {
  const start = Date.UTC(date.getUTCFullYear(), 0, 0);
  const dayOfYear = Math.floor((Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()) - start) / 86_400_000);
  const g = ((2 * Math.PI) / 365) * (dayOfYear - 1);
  const eqTime =
    229.18 * (0.000075 + 0.001868 * Math.cos(g) - 0.032077 * Math.sin(g) - 0.014615 * Math.cos(2 * g) - 0.040849 * Math.sin(2 * g));
  const decl =
    0.006918 - 0.399912 * Math.cos(g) + 0.070257 * Math.sin(g) - 0.006758 * Math.cos(2 * g) + 0.000907 * Math.sin(2 * g) -
    0.002697 * Math.cos(3 * g) + 0.00148 * Math.sin(3 * g);
  return { eqTime, decl };
}

/** Minutes after local midnight when the sun reaches `altitude` (morning or evening). */
function timeAtAltitude(date: Date, lat: number, lng: number, altitude: number, morning: boolean) {
  const { eqTime, decl } = solar(date);
  const cosH = (Math.sin(rad(altitude)) - Math.sin(rad(lat)) * Math.sin(decl)) / (Math.cos(rad(lat)) * Math.cos(decl));
  if (cosH < -1 || cosH > 1) return null;
  const H = deg(Math.acos(cosH));
  const noon = 720 - 4 * lng - eqTime + TZ_HOURS * 60;
  return morning ? noon - 4 * H : noon + 4 * H;
}

function atMinutes(day: Date, minutes: number) {
  // Build the instant for "minutes after midnight, Gulf time" on `day`.
  const utcMidnight = Date.UTC(day.getUTCFullYear(), day.getUTCMonth(), day.getUTCDate()) - TZ_HOURS * 3_600_000;
  return new Date(utcMidnight + minutes * 60_000);
}

export function fastingTimes(emirate: Emirate, now = new Date()) {
  const { lat, lng } = EMIRATES[emirate] ?? EMIRATES['Abu Dhabi'];
  // Work in Gulf calendar day.
  const gulf = new Date(now.getTime() + TZ_HOURS * 3_600_000);
  const day = new Date(Date.UTC(gulf.getUTCFullYear(), gulf.getUTCMonth(), gulf.getUTCDate()));
  const fajrMin = timeAtAltitude(day, lat, lng, -18.2, true);
  const sunsetMin = timeAtAltitude(day, lat, lng, -0.833, false);
  if (fajrMin === null || sunsetMin === null) return null;
  const suhoorEnds = atMinutes(day, fajrMin);
  const iftar = atMinutes(day, sunsetMin + 3); // short precaution after sunset
  return { suhoorEnds, iftar };
}

/** What to show in the Ramadan banner right now. */
export function ramadanStatus(emirate: Emirate, now = new Date()) {
  const t = fastingTimes(emirate, now);
  if (!t) return null;
  if (now < t.suhoorEnds) return { kind: 'suhoor' as const, at: t.suhoorEnds, msLeft: +t.suhoorEnds - +now };
  if (now < t.iftar) return { kind: 'iftar' as const, at: t.iftar, msLeft: +t.iftar - +now };
  const tomorrow = fastingTimes(emirate, new Date(+now + 86_400_000));
  if (!tomorrow) return null;
  return { kind: 'suhoor' as const, at: tomorrow.suhoorEnds, msLeft: +tomorrow.suhoorEnds - +now };
}

export function formatLeft(ms: number) {
  const m = Math.max(0, Math.round(ms / 60_000));
  const h = Math.floor(m / 60);
  return h > 0 ? `${h}h ${m % 60}m` : `${m}m`;
}

// Approximate Ramadan dates (Umm al-Qura based). The real start depends on the moon sighting,
// so the app only uses these to *suggest* Ramadan mode; the user decides.
const RAMADAN: [string, string][] = [
  ['2027-02-07', '2027-03-09'],
  ['2028-01-27', '2028-02-26'],
  ['2029-01-15', '2029-02-14'],
  ['2030-01-05', '2030-02-04'],
  ['2030-12-25', '2031-01-24'],
];

export function isRamadanNow(now = new Date()) {
  try {
    const month = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura', { month: 'numeric' }).format(now);
    if (/^\d+$/.test(month)) return Number(month) === 9;
  } catch {
    // Intl calendars not available on this device; use the table.
  }
  const d = now.toISOString().slice(0, 10);
  return RAMADAN.some(([a, b]) => d >= a && d <= b);
}
