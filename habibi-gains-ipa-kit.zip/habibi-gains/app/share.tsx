// Share card studio: pick a style, swipe through, share straight to Instagram stories.
import { router } from 'expo-router';
import * as Sharing from 'expo-sharing';
import React, { useEffect, useRef, useState } from 'react';
import { Dimensions, ScrollView, View } from 'react-native';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import { captureRef } from 'react-native-view-shot';
import { useI18n } from '@/i18n/i18n';
import { fetchTrend } from '@/lib/data';
import { success } from '@/lib/haptics';
import { useSession } from '@/lib/session';
import { TrendPoint } from '@/lib/trend';
import { useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Chips, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { ShareCard, ShareData } from '@/ui/ShareCard';
import { Txt } from '@/ui/Txt';

const CARD_W = Math.min(300, Dimensions.get('window').width - 80);

export default function Share() {
  const { t } = useI18n();
  const { theme } = useTheme();
  const { profile } = useSession();
  const ref = useRef<View>(null);
  const [trend, setTrend] = useState<TrendPoint[]>([]);
  const [style, setStyle] = useState<ShareData['style']>('bold');
  const [hideKg, setHideKg] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    fetchTrend(365).then(setTrend).catch(() => {});
  }, []);

  const first = trend[0];
  const last = trend.at(-1);
  const days = first && last ? Math.max(1, Math.round((+new Date(last.date) - +new Date(first.date)) / 86_400_000)) : 0;
  const diff = first && last ? last.trend - first.trend : 0;
  const pct = first && last ? (diff / first.trend) * 100 : 0;

  const data: ShareData = {
    headline: hideKg ? `${pct > 0 ? '+' : ''}${pct.toFixed(1)}%` : `${diff > 0 ? '+' : ''}${diff.toFixed(1)} kg`,
    label: t('daysTransformation', { n: days }),
    stats: [
      { label: t('streak', { n: '' }).trim(), value: String(profile?.streak_days ?? 0) },
      { label: 'XP', value: (profile?.xp ?? 0).toLocaleString('en-US') },
      { label: t('steps'), value: '—' },
    ].slice(0, 2),
    points: trend.slice(-60),
    style,
  };

  const share = async () => {
    if (!ref.current) return;
    setBusy(true);
    try {
      const uri = await captureRef(ref, { format: 'png', quality: 1, width: 1080, height: 1920 });
      success();
      await Sharing.shareAsync(uri, { mimeType: 'image/png', dialogTitle: t('shareTitle') });
    } finally {
      setBusy(false);
    }
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ padding: 20, gap: 18, alignItems: 'center', paddingBottom: 50 }}>
      <Row style={{ justifyContent: 'space-between', alignSelf: 'stretch' }}>
        <Txt v="h2">{t('shareTitle')}</Txt>
        <Press onPress={() => router.back()} accessibilityLabel={t('close')} style={{ padding: 6 }}>
          <Icon name="close" />
        </Press>
      </Row>

      <Animated.View key={style + String(hideKg)} entering={FadeIn.duration(300)} style={{ shadowColor: theme.accent, shadowOpacity: 0.25, shadowRadius: 30 }}>
        <ShareCard ref={ref} data={data} width={CARD_W} />
      </Animated.View>

      <Animated.View entering={FadeInDown.delay(150)} style={{ alignSelf: 'stretch', gap: 14 }}>
        <Chips
          value={style}
          onChange={setStyle}
          options={[
            { value: 'bold', label: 'Bold' },
            { value: 'minimal', label: 'Minimal' },
            { value: 'accent', label: 'Colour' },
          ]}
        />
        <Press onPress={() => setHideKg(!hideKg)} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <View style={{ width: 24, height: 24, borderRadius: 7, backgroundColor: hideKg ? theme.accent : theme.cardHigh, alignItems: 'center', justifyContent: 'center' }}>
            {hideKg ? <Icon name="check" size={15} color={theme.onAccent} stroke={2.6} /> : null}
          </View>
          <Txt>{t('hideKg')}</Txt>
        </Press>
        <Button title={t('shareNow')} loading={busy} disabled={trend.length < 2} icon={<Icon name="share" color={theme.onAccent} size={20} />} onPress={share} />
      </Animated.View>
    </ScrollView>
  );
}
