import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import { router, useFocusEffect } from 'expo-router';
import React, { useCallback, useEffect, useState } from 'react';
import { Alert, Dimensions, View } from 'react-native';
import Animated, { FadeIn } from 'react-native-reanimated';
import { useI18n } from '@/i18n/i18n';
import { addProgressPhoto, awardBadge, fetchPhotos } from '@/lib/data';
import { success } from '@/lib/haptics';
import { useSession } from '@/lib/session';
import { signedUrl, uploadImage } from '@/lib/supabase';
import { useToday } from '@/lib/useToday';
import { useTheme } from '@/theme/theme';
import { BeforeAfter } from '@/ui/BeforeAfter';
import { useCelebrate } from '@/ui/Celebrate';
import { Ticker, TrendChart } from '@/ui/Graphics';
import { Icon } from '@/ui/Icon';
import { Card, Chips, Row, Screen, SectionTitle } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

const W = Dimensions.get('window').width;
type Range = '30' | '90' | 'all';

export default function Progress() {
  const { t, lang } = useI18n();
  const { theme } = useTheme();
  const celebrate = useCelebrate();
  const { profile, session } = useSession();
  const d = useToday(profile);
  const [range, setRange] = useState<Range>('90');
  const [photos, setPhotos] = useState<{ id: string; url: string; taken_on: string }[]>([]);

  const loadPhotos = useCallback(async () => {
    const rows = await fetchPhotos().catch(() => []);
    const withUrls = await Promise.all(rows.map(async (r) => ({ id: r.id, taken_on: r.taken_on, url: (await signedUrl('progress', r.storage_path)) ?? '' })));
    setPhotos(withUrls.filter((p) => p.url));
  }, []);
  useFocusEffect(useCallback(() => { loadPhotos(); }, [loadPhotos]));

  const shown = range === 'all' ? d.trend : d.trend.slice(-Number(range));
  const start = Number(d.startWeight ?? 0);
  const now = d.last?.trend ?? 0;
  const goal = Number(profile?.goal_weight_kg ?? 0);
  const done = start && goal && start !== goal ? Math.min(1, Math.max(0, (start - now) / (start - goal))) : 0;

  useEffect(() => {
    if (start && now && start - now >= 5 && profile?.goal === 'lose') {
      awardBadge('down-5').then((won) => won && celebrate({ title: lang === 'ar' ? 'خمسة أقل' : 'Five Down', icon: 'trend' }));
    }
  }, [start, now, profile?.goal, lang, celebrate]);

  const savePhoto = async (camera: boolean) => {
    if (!session) return;
    const opts: ImagePicker.ImagePickerOptions = { mediaTypes: ['images'], quality: 0.8 };
    const res = camera
      ? await ImagePicker.launchCameraAsync({ ...opts, cameraType: ImagePicker.CameraType.front }).catch(() => null)
      : await ImagePicker.launchImageLibraryAsync(opts);
    if (!res || res.canceled || !res.assets?.[0]) return;
    await addProgressPhoto(session.user.id, res.assets[0].uri, (uri) => uploadImage('progress', session.user.id, uri));
    success();
    if (await awardBadge('first-photo')) celebrate({ title: lang === 'ar' ? 'اليوم الأول' : 'Day One', icon: 'camera' });
    loadPhotos();
  };

  const addPhoto = () =>
    Alert.alert(t('addPhoto'), t('photoTip'), [
      { text: t('takePhoto'), onPress: () => savePhoto(true) },
      { text: t('fromLibrary'), onPress: () => savePhoto(false) },
      { text: t('cancel'), style: 'cancel' },
    ]);

  return (
    <Screen>
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="h1">{t('progress')}</Txt>
        <Press onPress={() => router.push('/share')} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: theme.accent, borderRadius: 999, paddingHorizontal: 16, height: 40 }}>
          <Icon name="share" size={18} color={theme.onAccent} />
          <Txt v="bodyStrong" color={theme.onAccent}>{t('shareProgress')}</Txt>
        </Press>
      </Row>

      <Card index={0}>
        <Txt v="label" muted>{t('trendWeight')}</Txt>
        {d.last ? <Ticker value={now} decimals={1} v="hero" suffix={` ${t('kg')}`} /> : <Txt v="hero">—</Txt>}
        <TrendChart points={shown} width={W - 76} height={170} />
        <Chips
          value={range}
          onChange={setRange}
          options={[
            { value: '30', label: t('last30') },
            { value: '90', label: t('last90') },
            { value: 'all', label: t('all') },
          ]}
        />
      </Card>

      <Row gap={10}>
        {[
          { l: t('start'), v: start ? start.toFixed(1) : '—' },
          { l: t('current'), v: now ? now.toFixed(1) : '—' },
          { l: t('goal'), v: goal ? goal.toFixed(1) : '—' },
        ].map((s, i) => (
          <Card key={s.l} index={i + 1} style={{ flex: 1, width: (W - 60) / 3, gap: 2 }}>
            <Txt v="h2">{s.v}</Txt>
            <Txt v="small" muted>{s.l}</Txt>
          </Card>
        ))}
      </Row>

      {goal ? (
        <Card index={4}>
          <Row style={{ justifyContent: 'space-between' }}>
            <Txt v="bodyStrong">{`${Math.round(done * 100)}%`}</Txt>
            <Txt v="small" muted>{`${Math.abs(now - goal).toFixed(1)} ${t('kg')} → ${t('goal').toLowerCase()}`}</Txt>
          </Row>
          <View style={{ height: 10, borderRadius: 5, backgroundColor: theme.cardHigh, overflow: 'hidden' }}>
            <Animated.View entering={FadeIn.delay(300)} style={{ width: `${done * 100}%`, height: 10, backgroundColor: theme.accent, borderRadius: 5 }} />
          </View>
          {d.rate !== null ? (
            <Txt v="small" muted>{`${d.rate > 0 ? '+' : ''}${d.rate.toFixed(2)}% / week · ${{ too_fast: t('paceTooFast'), stalled: t('paceStalled'), on_track: t('paceOnTrack'), drifting: t('paceDrifting'), unknown: '' }[d.pace]}`}</Txt>
          ) : null}
          <Press onPress={() => router.push('/why')}>
            <Txt v="small" color={theme.accent}>{t('whyNumbers')}</Txt>
          </Press>
        </Card>
      ) : null}

      <SectionTitle action={t('addPhoto')} onAction={addPhoto}>{t('photos')}</SectionTitle>
      {photos.length >= 2 ? (
        <BeforeAfter before={photos[0].url} after={photos[photos.length - 1].url} labels={[photos[0].taken_on, photos[photos.length - 1].taken_on]} />
      ) : null}
      {photos.length ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {photos.map((p) => (
            <Image key={p.id} source={{ uri: p.url }} style={{ width: (W - 56) / 3, height: ((W - 56) / 3) * 1.33, borderRadius: 16 }} contentFit="cover" transition={200} />
          ))}
        </View>
      ) : (
        <Card>
          <Icon name="camera" size={32} color={theme.faint} />
          <Txt muted>{t('photosEmpty')}</Txt>
          <Button title={t('addPhoto')} kind="secondary" onPress={addPhoto} />
        </Card>
      )}
    </Screen>
  );
}
