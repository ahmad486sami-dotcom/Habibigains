import { Inter_400Regular, Inter_500Medium, Inter_600SemiBold } from '@expo-google-fonts/inter';
import { SpaceGrotesk_500Medium, SpaceGrotesk_700Bold } from '@expo-google-fonts/space-grotesk';
import { useFonts } from 'expo-font';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect } from 'react';
import { AppState } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { I18nProvider, useI18n } from '@/i18n/i18n';
import { syncNotifications } from '@/lib/notifications';
import '@/lib/runTracker'; // registers the background location task
import { SessionProvider, useSession } from '@/lib/session';
import { ThemeProvider, useTheme } from '@/theme/theme';
import { CelebrateProvider } from '@/ui/Celebrate';

SplashScreen.preventAutoHideAsync().catch(() => {});

function Root() {
  const { theme } = useTheme();
  const { loading, profile } = useSession();
  const { lang } = useI18n();

  // Rebuild reminders when the app opens or comes back to the front.
  useEffect(() => {
    if (!profile) return;
    syncNotifications(profile, lang);
    const sub = AppState.addEventListener('change', (st) => {
      if (st === 'active') syncNotifications(profile, lang);
    });
    return () => sub.remove();
  }, [profile?.id, profile?.ramadan_mode, profile?.wake_time, profile?.emirate, lang]);

  useEffect(() => {
    if (!loading) SplashScreen.hideAsync().catch(() => {});
  }, [loading]);

  return (
    <>
      <StatusBar style="light" />
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: theme.bg },
          animation: 'fade_from_bottom',
        }}
      >
        <Stack.Screen name="index" options={{ animation: 'none' }} />
        <Stack.Screen name="(auth)" options={{ animation: 'fade' }} />
        <Stack.Screen name="onboarding" options={{ animation: 'fade' }} />
        <Stack.Screen name="(tabs)" options={{ animation: 'fade' }} />
        {['add-food', 'weigh-in', 'share', 'timing', 'why', 'settings', 'admin', 'tutorials', 'supplements', 'food/[id]', 'food/quick', 'food/create', 'food/recipe', 'food/nutrition', 'run/[id]'].map((n) => (
          <Stack.Screen key={n} name={n} options={{ presentation: 'modal', animation: 'slide_from_bottom' }} />
        ))}
        <Stack.Screen name="scan" options={{ presentation: 'fullScreenModal', animation: 'fade' }} />
        <Stack.Screen name="run/index" options={{ presentation: 'fullScreenModal', animation: 'slide_from_bottom', gestureEnabled: false }} />
        <Stack.Screen name="event/[id]" options={{ presentation: 'modal' }} />
        <Stack.Screen name="quest/[id]" options={{ presentation: 'modal' }} />
      </Stack>
    </>
  );
}

export default function Layout() {
  const [fontsLoaded] = useFonts({
    SpaceGrotesk_700Bold,
    SpaceGrotesk_500Medium,
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
  });
  if (!fontsLoaded) return null;
  return (
    <GestureHandlerRootView style={{ flex: 1, backgroundColor: '#000' }}>
      <SafeAreaProvider>
        <ThemeProvider>
          <I18nProvider>
            <SessionProvider>
              <CelebrateProvider>
                <Root />
              </CelebrateProvider>
            </SessionProvider>
          </I18nProvider>
        </ThemeProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
