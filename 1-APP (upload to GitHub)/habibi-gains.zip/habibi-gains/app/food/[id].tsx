// One food: choose serving and amount, see full nutrition facts, then log it (or update a logged entry,
// or add it to a recipe). Recipes can be shared as a PDF from here.
import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, KeyboardAvoidingView, Platform, ScrollView, TextInput, View } from 'react-native';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useI18n } from '@/i18n/i18n';
import {
  addFoodLog,
  awardBadge,
  deleteCustomFood,
  deleteFoodLog,
  Food,
  FoodLog,
  foodName,
  getFood,
  getFoodLog,
  isFavorite,
  logFromFood,
  Meal,
  nutrientsFor,
  Nutrients,
  NUTRIENT_KEYS,
  Serving,
  servingOptions,
  setFavorite,
  updateFoodLog,
} from '@/lib/data';
import { defaultMeal, MEAL_LABEL, mealsFor, NUTRIENT_LABEL } from '@/lib/day';
import { select, success, warn } from '@/lib/haptics';
import { putIngredient } from '@/lib/picker';
import { shareRecipePdf } from '@/lib/recipePdf';
import { useSession } from '@/lib/session';
import { todayISO } from '@/lib/supabase';
import { fonts, useTheme } from '@/theme/theme';
import { useCelebrate } from '@/ui/Celebrate';
import { Ring } from '@/ui/Graphics';
import { Icon } from '@/ui/Icon';
import { Chips, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';


export default function FoodDetail() {
  const { lang, isRTL } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const celebrate = useCelebrate();
  const { profile } = useSession();
  const p = useLocalSearchParams<{ id: string; logId?: string; meal?: Meal; day?: string; mode?: 'recipe'; from?: string }>();
  const recipeMode = p.mode === 'recipe';

  const [food, setFood] = useState<Food | null>(null);
  const [log, setLog] = useState<FoodLog | null>(null);
  const [loading, setLoading] = useState(true);
  const [serving, setServing] = useState<Serving | null>(null);
  const [qty, setQty] = useState('1');
  const [meal, setMeal] = useState<Meal>(p.meal ?? defaultMeal(!!profile?.ramadan_mode));
  const [fav, setFav] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const l = p.logId ? await getFoodLog(p.logId) : null;
        const f = p.id && p.id !== 'log' ? await getFood(p.id).catch(() => null) : null;
        setLog(l);
        setFood(f);
        if (l) {
          setMeal(l.meal);
          setQty(String(l.quantity));
        }
        if (f) {
          const opts = servingOptions(f);
          const match = l ? opts.find((o) => o.label === l.serving_label && (l.serving_g == null || Math.abs(o.g - l.serving_g) < 0.01)) : null;
          setServing(match ?? (l?.serving_g ? { label: l.serving_label, g: l.serving_g } : opts[0]));
          isFavorite(f.id).then(setFav).catch(() => {});
        }
      } finally {
        setLoading(false);
      }
    })();
  }, [p.id, p.logId]);

  const quantity = Math.max(0, Number(qty.replace(',', '.')) || 0);
  const options = food ? servingOptions(food) : [];

  // Nutrients for what is on screen.
  const n: Nutrients | null = useMemo(() => {
    if (food && serving) return nutrientsFor(food, serving.g * quantity);
    if (log) {
      const k = quantity / (log.quantity || 1);
      const o = {} as Nutrients;
      for (const key of NUTRIENT_KEYS) {
        const v = log[key];
        (o as any)[key] = v === null || v === undefined ? null : key === 'kcal' ? Math.round(Number(v) * k) : Math.round(Number(v) * k * 10) / 10;
      }
      return o;
    }
    return null;
  }, [food, serving, log, quantity]);

  const title = food ? foodName(food, lang) : log?.name ?? '';
  const day = p.day ?? log?.logged_on ?? todayISO();

  const save = async () => {
    if (!n || quantity <= 0) return;
    setBusy(true);
    try {
      if (recipeMode && food && serving) {
        putIngredient({ food_id: food.id, name: foodName(food, 'en'), serving_label: serving.label, serving_g: serving.g, quantity, grams: Math.round(serving.g * quantity * 10) / 10, ...n });
        success();
        router.dismissTo('/food/recipe');
        return;
      }
      if (log) {
        await updateFoodLog(log.id, {
          meal,
          quantity,
          ...(food && serving ? { serving_label: serving.label, serving_g: serving.g } : {}),
          ...n,
        });
        success();
        router.back();
        return;
      }
      if (food && serving) {
        await addFoodLog(logFromFood(food, serving, quantity, meal, lang, food.source === 'recipe' ? 'recipe' : food.source === 'user' ? 'custom' : 'search'), day);
        success();
        const first = await awardBadge('first-log').catch(() => false);
        // Back to the diary (skip the search screen), like MyFitnessPal.
        if (p.from === 'add' && router.canDismiss()) router.dismiss(2);
        else router.back();
        if (first) setTimeout(() => celebrate({ title: L('First Bite', 'أول لقمة'), icon: 'fork' }), 350);
      }
    } catch {
      warn();
      Alert.alert(L('Could not save', 'ما قدرنا نحفظ'), L('Check your connection and try again.', 'تأكد من الاتصال وحاول مرة ثانية.'));
    } finally {
      setBusy(false);
    }
  };

  const removeLog = () =>
    log &&
    Alert.alert(log.name, L('Remove from your diary?', 'تحذفه من اليوميات؟'), [
      { text: L('Cancel', 'إلغاء'), style: 'cancel' },
      { text: L('Remove', 'حذف'), style: 'destructive', onPress: async () => { await deleteFoodLog(log.id).catch(() => {}); warn(); router.back(); } },
    ]);

  const removeFood = () =>
    food &&
    Alert.alert(foodName(food, lang), L('Delete this from your foods? Past diary entries stay.', 'تحذفه من أكلاتك؟ السجلات القديمة تبقى.'), [
      { text: L('Cancel', 'إلغاء'), style: 'cancel' },
      { text: L('Delete', 'حذف'), style: 'destructive', onPress: async () => { await deleteCustomFood(food.id).catch(() => {}); warn(); router.back(); } },
    ]);

  const toggleFav = async () => {
    if (!food) return;
    select();
    setFav(!fav);
    await setFavorite(food.id, !fav).catch(() => setFav(fav));
  };

  if (loading)
    return (
      <View style={{ flex: 1, backgroundColor: theme.bg, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={theme.muted} />
      </View>
    );

  if (!food && !log)
    return (
      <View style={{ flex: 1, backgroundColor: theme.bg, padding: 24, justifyContent: 'center', gap: 16 }}>
        <Txt v="h2">{L('Food not found', 'ما لقينا الأكل')}</Txt>
        <Button title={L('Back', 'رجوع')} kind="secondary" onPress={() => router.back()} />
      </View>
    );

  const kcal = n?.kcal ?? 0;
  const pct = (g: number, per: number) => (kcal > 0 ? Math.round(((g * per) / kcal) * 100) : 0);
  const mine = food && (food.source === 'user' || food.source === 'recipe') && food.created_by === profile?.id;

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: theme.bg }}>
      <ScrollView contentContainerStyle={{ padding: 20, gap: 16, paddingBottom: insets.bottom + 120 }} keyboardShouldPersistTaps="handled">
        <Row style={{ justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <View style={{ flex: 1, gap: 4 }}>
            <Txt v="h2">{title}</Txt>
            {food?.brand || log?.brand ? <Txt muted>{food?.brand ?? log?.brand}</Txt> : null}
            {food?.source === 'uae' ? <Txt v="small" faint>{L('UAE dish · Habibi Gains estimate from standard recipes', 'طبق إماراتي · تقدير حبيبي جينز')}</Txt> : null}
            {food?.source === 'usda' ? <Txt v="small" faint>USDA FoodData Central</Txt> : null}
            {food?.source === 'off' ? <Txt v="small" faint>Open Food Facts</Txt> : null}
          </View>
          <Row gap={4}>
            {food ? (
              <Press onPress={toggleFav} accessibilityLabel={L('Favourite', 'المفضلة')} style={{ padding: 8 }}>
                <Icon name="star" color={fav ? theme.accent : theme.muted} />
              </Press>
            ) : null}
            <Press onPress={() => router.back()} accessibilityLabel={L('Close', 'إغلاق')} style={{ padding: 8 }}>
              <Icon name="close" />
            </Press>
          </Row>
        </Row>

        {/* calories + macro split */}
        <Animated.View entering={FadeInDown.springify()} style={{ backgroundColor: theme.card, borderRadius: 24, padding: 18 }}>
          <Row gap={18}>
            <Ring size={108} stroke={10} progress={profile?.calorie_target ? kcal / profile.calorie_target : 0}>
              <Txt v="h2">{kcal}</Txt>
              <Txt v="small" muted style={{ fontSize: 11 }}>kcal</Txt>
            </Ring>
            <View style={{ flex: 1, gap: 10 }}>
              {[
                [L('Protein', 'بروتين'), n?.protein_g ?? 0, 4],
                [L('Carbs', 'كارب'), n?.carbs_g ?? 0, 4],
                [L('Fat', 'دهون'), n?.fat_g ?? 0, 9],
              ].map(([label, g, per]) => (
                <Row key={label as string} style={{ justifyContent: 'space-between' }}>
                  <Txt muted>{label as string}</Txt>
                  <Txt v="bodyStrong">{`${Math.round((g as number) * 10) / 10} g · ${pct(g as number, per as number)}%`}</Txt>
                </Row>
              ))}
            </View>
          </Row>
        </Animated.View>

        {/* amount */}
        <View style={{ gap: 10 }}>
          <Txt v="label" muted>{L('Serving size', 'حجم الحصة')}</Txt>
          {food ? (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
              {options.map((o) => {
                const on = serving?.label === o.label && serving?.g === o.g;
                return (
                  <Press
                    key={`${o.label}-${o.g}`}
                    haptic={false}
                    onPress={() => {
                      select();
                      setServing(o);
                      if (o.label === 'g') setQty(String(Math.round((serving?.g ?? 100) * quantity) || 100));
                      else if (serving?.label === 'g') setQty('1');
                    }}
                    style={{ paddingHorizontal: 16, height: 42, borderRadius: 21, justifyContent: 'center', backgroundColor: on ? theme.accent : theme.card }}
                  >
                    <Txt v="bodyStrong" color={on ? theme.onAccent : theme.text} style={{ fontSize: 14 }}>
                      {o.label === 'g' ? L('grams', 'جرام') : o.label}
                      {o.label !== 'g' && o.label !== '100 g' ? <Txt v="small" color={on ? theme.onAccent : theme.faint}>{`  ${Math.round(o.g)} g`}</Txt> : null}
                    </Txt>
                  </Press>
                );
              })}
            </ScrollView>
          ) : (
            <Txt>{log?.serving_label}</Txt>
          )}

          <Row gap={10}>
            <Press onPress={() => setQty(String(Math.max(0.25, Math.round((quantity - (serving?.label === 'g' ? 10 : 0.5)) * 100) / 100)))} style={stepper(theme)}>
              <Txt v="h2">−</Txt>
            </Press>
            <TextInput
              value={qty}
              onChangeText={(v) => setQty(v.replace(/[^0-9.,]/g, '').slice(0, 7))}
              keyboardType="decimal-pad"
              selectTextOnFocus
              style={{ flex: 1, height: 52, borderRadius: 18, backgroundColor: theme.card, color: theme.text, textAlign: 'center', fontSize: 22, fontFamily: isRTL ? undefined : fonts.display }}
            />
            <Press onPress={() => setQty(String(Math.round((quantity + (serving?.label === 'g' ? 10 : 0.5)) * 100) / 100))} style={stepper(theme)}>
              <Txt v="h2">+</Txt>
            </Press>
          </Row>
          <Txt v="small" faint center>
            {serving?.label === 'g'
              ? L(`${quantity} grams`, `${quantity} جرام`)
              : serving
                ? L(`${quantity} × ${serving.label} = ${Math.round(serving.g * quantity)} g`, `${quantity} × ${serving.label} = ${Math.round(serving.g * quantity)} جم`)
                : ''}
          </Txt>
        </View>

        {!recipeMode ? (
          <View style={{ gap: 10 }}>
            <Txt v="label" muted>{L('Meal', 'الوجبة')}</Txt>
            <Chips value={meal} onChange={setMeal} options={mealsFor(!!profile?.ramadan_mode).map((m) => ({ value: m, label: L(MEAL_LABEL[m].en, MEAL_LABEL[m].ar) }))} />
          </View>
        ) : null}

        {/* nutrition facts */}
        {n ? (
          <Animated.View entering={FadeIn.delay(120)} style={{ backgroundColor: theme.card, borderRadius: 24, padding: 18, gap: 2 }}>
            <Txt v="h3" style={{ marginBottom: 6 }}>{L('Nutrition facts', 'القيم الغذائية')}</Txt>
            {NUTRIENT_KEYS.map((k) => (
              <Row key={k} style={{ justifyContent: 'space-between', paddingVertical: 7, borderBottomWidth: 1, borderColor: theme.border }}>
                <Txt muted={k !== 'kcal'}>{L(NUTRIENT_LABEL[k].en, NUTRIENT_LABEL[k].ar)}</Txt>
                <Txt v="bodyStrong">{n[k] === null || n[k] === undefined ? '–' : `${n[k]} ${NUTRIENT_LABEL[k].unit}`}</Txt>
              </Row>
            ))}
            <Txt v="small" faint style={{ marginTop: 8 }}>{L('"–" means the source has no value for this nutrient.', '"–" يعني المصدر ما فيه قيمة لهذا العنصر.')}</Txt>
          </Animated.View>
        ) : null}

        {/* recipe extras */}
        {food?.source === 'recipe' && food.ingredients?.length ? (
          <View style={{ backgroundColor: theme.card, borderRadius: 24, padding: 18, gap: 8 }}>
            <Txt v="h3">{L(`Ingredients · makes ${food.recipe_servings ?? 1}`, `المكونات · تكفي ${food.recipe_servings ?? 1}`)}</Txt>
            {food.ingredients.map((i, idx) => (
              <Row key={idx} style={{ justifyContent: 'space-between' }}>
                <Txt style={{ flex: 1 }} numberOfLines={1}>{i.name}</Txt>
                <Txt muted>{`${Math.round(i.grams)} g · ${Math.round(i.kcal)}`}</Txt>
              </Row>
            ))}
            <Row gap={10} style={{ marginTop: 6 }}>
              <Button style={{ flex: 1 }} kind="secondary" title={L('Share PDF', 'مشاركة PDF')} icon={<Icon name="share" size={18} />} onPress={() => shareRecipePdf(food, profile?.display_name).catch(() => warn())} />
              {mine ? <Button style={{ flex: 1 }} kind="secondary" title={L('Edit', 'تعديل')} onPress={() => router.push({ pathname: '/food/recipe', params: { id: food.id } })} /> : null}
            </Row>
          </View>
        ) : null}

        {mine && food?.source === 'user' ? (
          <Button kind="secondary" title={L('Edit food', 'تعديل الأكل')} onPress={() => router.push({ pathname: '/food/create', params: { id: food.id } })} />
        ) : null}
        {mine ? <Button kind="danger" title={food?.source === 'recipe' ? L('Delete recipe', 'حذف الوصفة') : L('Delete food', 'حذف الأكل')} onPress={removeFood} /> : null}
        {log ? <Button kind="danger" title={L('Remove from diary', 'حذف من اليوميات')} onPress={removeLog} /> : null}
      </ScrollView>

      <View style={{ position: 'absolute', left: 0, right: 0, bottom: 0, padding: 20, paddingBottom: insets.bottom + 14, backgroundColor: theme.bg, borderTopWidth: 1, borderColor: theme.border }}>
        <Button
          title={recipeMode ? L('Add to recipe', 'أضف للوصفة') : log ? L('Save changes', 'حفظ التعديل') : L(`Add to ${MEAL_LABEL[meal].en}`, `أضف إلى ${MEAL_LABEL[meal].ar}`)}
          loading={busy}
          disabled={!n || quantity <= 0 || (recipeMode && !food)}
          onPress={save}
        />
      </View>
    </KeyboardAvoidingView>
  );
}

const stepper = (theme: { card: string }) => ({
  width: 52,
  height: 52,
  borderRadius: 26,
  backgroundColor: theme.card,
  alignItems: 'center' as const,
  justifyContent: 'center' as const,
});
