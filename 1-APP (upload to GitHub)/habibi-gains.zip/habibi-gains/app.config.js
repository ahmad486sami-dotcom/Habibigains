// App config. Supabase URL and publishable key are built in (see src/lib/supabase.ts),
// so the app works without any environment variables.
const base = require('./base-config.json');

module.exports = () => JSON.parse(JSON.stringify(base));
