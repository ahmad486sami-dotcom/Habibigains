// Drag the handle to reveal before vs after.
import { Image } from 'expo-image';
import React, { useState } from 'react';
import { View } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import { useTheme } from '@/theme/theme';
import { Txt } from './Txt';

export function BeforeAfter({ before, after, height = 420, labels }: { before: string; after: string; height?: number; labels: [string, string] }) {
  const { theme } = useTheme();
  const [w, setW] = useState(0);
  const pos = useSharedValue(0.5);
  const start = useSharedValue(0.5);

  const pan = Gesture.Pan()
    .onBegin(() => {
      start.value = pos.value;
    })
    .onUpdate((e) => {
      if (w > 0) pos.value = Math.min(0.97, Math.max(0.03, start.value + e.translationX / w));
    })
    .onEnd(() => {
      pos.value = withSpring(pos.value, { damping: 20 });
    });

  const clip = useAnimatedStyle(() => ({ width: w * pos.value }));
  const handle = useAnimatedStyle(() => ({ transform: [{ translateX: w * pos.value - 22 }] }));

  return (
    <GestureDetector gesture={pan}>
      <View
        onLayout={(e) => setW(e.nativeEvent.layout.width)}
        style={{ height, borderRadius: theme.radius.lg, overflow: 'hidden', backgroundColor: theme.card, direction: 'ltr' }}
      >
        <Image source={{ uri: after }} style={{ position: 'absolute', width: '100%', height: '100%' }} contentFit="cover" />
        <Animated.View style={[{ position: 'absolute', top: 0, bottom: 0, left: 0, overflow: 'hidden' }, clip]}>
          <Image source={{ uri: before }} style={{ width: w, height }} contentFit="cover" />
        </Animated.View>
        <Animated.View style={[{ position: 'absolute', top: 0, bottom: 0, width: 44, alignItems: 'center' }, handle]}>
          <View style={{ flex: 1, width: 3, backgroundColor: theme.text }} />
          <View
            style={{
              position: 'absolute',
              top: height / 2 - 22,
              width: 44,
              height: 44,
              borderRadius: 22,
              backgroundColor: theme.text,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Txt v="bodyStrong" color={theme.bg}>{'‹ ›'}</Txt>
          </View>
        </Animated.View>
        <View style={{ position: 'absolute', top: 14, left: 14, backgroundColor: 'rgba(0,0,0,0.6)', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999 }}>
          <Txt v="label">{labels[0]}</Txt>
        </View>
        <View style={{ position: 'absolute', top: 14, right: 14, backgroundColor: 'rgba(0,0,0,0.6)', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999 }}>
          <Txt v="label">{labels[1]}</Txt>
        </View>
      </View>
    </GestureDetector>
  );
}
