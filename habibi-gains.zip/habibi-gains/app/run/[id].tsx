// A finished run: map, stats, km splits, rename, share as a story, delete.
import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useRef, useState } from 'react';
import { Alert, Dimensions, ScrollView, TextInput, View } from 'react-native';
import MapView, { Marker, Polyline } from 'react-native-maps';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { useI18n } from '@/i18n/i18n';
import { deleteRun, getRun, renameRun, Run } from '@/lib/data';
import { warn } from '@/lib/haptics';
import { formatDuration, formatKm, formatPace } from '@/lib/runTracker';
import { fonts, useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

const W = Dimensions.get('window').width;

export default function RunDetail() {
  const { lang, isRTL } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { id } = useLocalSearchParams<{ id: string }>();
  const map = useRef<MapView>(null);
  const [run, setRun] = useState<Run | null>(null);
  const [title, setTitle] = useState('');

  useEffect(() => {
    getRun(id)
      .then((r) => {
        setRun(r);
        setTitle(r.title ?? '');
      })
      .catch(() => {});
  }, [id]);

  if (!run) return <View style={{ flex: 1, backgroundColor: theme.bg }} />;

  const coords = run.route.map(([lat, lng]) => ({ latitude: lat, longitude: lng }));
  const avg = run.distance_m > 0 ? run.moving_s / (run.distance_m / 1000) : null;
  const fastest = run.splits.length ? Math.min(...run.splits.map((s) => s.s)) : 0;
  const slowest = run.splits.length ? Math.max(...run.splits.map((s) => s.s)) : 0;
  const defaultTitle = (() => {
    const h = new Date(run.started_at).getHours();
    const part = h < 11 ? L('Morning run', 'جري الصبح') : h < 16 ? L('Afternoon run', 'جري الظهر') : h < 20 ? L('Evening run', 'جري المغرب') : L('Night run', 'جري الليل');
    return part;
  })();

  const saveTitle = () => renameRun(run.id, title).catch(() => warn());

  const remove = () =>
    Alert.alert(L('Delete this run?', 'تحذف الجري؟'), undefined, [
      { text: L('Cancel', 'إلغاء'), style: 'cancel' },
      { text: L('Delete', 'حذف'), style: 'destructive', onPress: async () => { await deleteRun(run.id).catch(() => {}); router.back(); } },
    ]);

  const stat = (label: string, value: string) => (
    <View style={{ width: (W - 40 - 12) / 2, backgroundColor: theme.card, borderRadius: 20, padding: 16, gap: 4 }}>
      <Txt v="label" muted>{label}</Txt>
      <Txt v="h1">{value}</Txt>
    </View>
  );

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ paddingBottom: 60 }}>
      <View style={{ height: 300 }}>
        {coords.length > 1 ? (
          <MapView
            ref={map}
            style={{ flex: 1 }}
            userInterfaceStyle="dark"
            scrollEnabled={false}
            zoomEnabled={false}
            pitchEnabled={false}
            rotateEnabled={false}
            onMapReady={() => map.current?.fitToCoordinates(coords, { edgePadding: { top: 50, right: 40, bottom: 40, left: 40 }, animated: false })}
          >
            <Polyline coordinates={coords} strokeColor={theme.accent} strokeWidth={5} lineCap="round" lineJoin="round" />
            <Marker coordinate={coords[0]} pinColor="green" />
            <Marker coordinate={coords[coords.length - 1]} pinColor="red" />
          </MapView>
        ) : (
          <View style={{ flex: 1, backgroundColor: theme.card }} />
        )}
        <Press onPress={() => router.back()} style={{ position: 'absolute', top: 14, right: 14, width: 40, height: 40, borderRadius: 20, backgroundColor: theme.surface, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="close" size={18} />
        </Press>
      </View>

      <View style={{ padding: 20, gap: 16 }}>
        <View style={{ gap: 4 }}>
          <Txt v="label" muted>
            {new Date(run.started_at).toLocaleString(lang === 'ar' ? 'ar-AE' : 'en-GB', { weekday: 'long', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })}
          </Txt>
          <TextInput
            value={title}
            onChangeText={setTitle}
            onEndEditing={saveTitle}
            placeholder={defaultTitle}
            placeholderTextColor={theme.text}
            maxLength={80}
            style={{ color: theme.text, fontSize: 30, fontFamily: isRTL ? undefined : fonts.display, letterSpacing: -1, textAlign: isRTL ? 'right' : 'left', paddingVertical: 4 }}
          />
          <Txt v="small" faint>{L('Tap the title to rename', 'اضغط على العنوان لتغييره')}</Txt>
        </View>

        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12 }}>
          {stat(L('Distance', 'المسافة'), `${formatKm(run.distance_m)} km`)}
          {stat(L('Moving time', 'وقت الحركة'), formatDuration(run.moving_s * 1000))}
          {stat(L('Avg pace', 'معدل السرعة'), `${formatPace(avg)} /km`)}
          {stat(L('Calories', 'السعرات'), `${run.kcal}`)}
          {run.elev_gain_m ? stat(L('Climb', 'الصعود'), `${Math.round(run.elev_gain_m)} m`) : null}
          {run.elapsed_s - run.moving_s > 30 ? stat(L('Elapsed', 'الوقت الكلي'), formatDuration(run.elapsed_s * 1000)) : null}
        </View>

        {run.splits.length ? (
          <View style={{ backgroundColor: theme.card, borderRadius: 24, padding: 18, gap: 10 }}>
            <Txt v="h3">{L('Splits', 'الكيلومترات')}</Txt>
            {run.splits.map((sp, i) => (
              <Animated.View key={sp.km} entering={FadeInDown.delay(i * 40)}>
                <Row gap={12}>
                  <Txt v="bodyStrong" style={{ width: 28 }}>{sp.km}</Txt>
                  <View style={{ flex: 1, height: 10, backgroundColor: theme.cardHigh, borderRadius: 5, overflow: 'hidden' }}>
                    <View style={{ height: 10, borderRadius: 5, width: `${slowest ? Math.max(15, (fastest / sp.s) * 100) : 0}%`, backgroundColor: sp.s === fastest ? theme.accent : theme.muted }} />
                  </View>
                  <Txt v="bodyStrong" style={{ width: 54, textAlign: 'right' }}>{formatPace(sp.s)}</Txt>
                </Row>
              </Animated.View>
            ))}
          </View>
        ) : null}

        <Button title={L('Share as story', 'شارك كستوري')} icon={<Icon name="share" color={theme.onAccent} size={20} />} onPress={() => router.push({ pathname: '/share', params: { kind: 'run', runId: run.id } })} />
        <Button title={L('Delete run', 'حذف الجري')} kind="danger" onPress={remove} />
        <Txt v="small" faint>{L('Calories estimated at ~1 kcal per kg per km (ACSM running energy cost).', 'السعرات تقديرية: حوالي ١ سعرة لكل كجم لكل كم.')}</Txt>
      </View>
    </ScrollView>
  );
}
