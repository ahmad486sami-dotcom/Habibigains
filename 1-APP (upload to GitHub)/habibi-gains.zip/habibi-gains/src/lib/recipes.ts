// Habibi Gains recipe library: 37 original recipes from everyday UAE supermarket staples.
// Macros are per serving and approximate. Grams are raw weight unless marked cooked.
export type LibRecipe = {
  id: string;
  name: string;
  cat: 'Meal prep & mains' | 'Breakfast' | 'Snacks & shakes' | 'UAE favourites' | 'Takeaway at home' | 'No cooking' | 'Vegetarian' | 'Desserts';
  style: string;
  makes: number;
  ingredients: string;
  kcal: number;
  p: number;
  c: number;
  f: number;
};

const r = (id: string, cat: LibRecipe['cat'], name: string, style: string, makes: number, ingredients: string, kcal: number, p: number, c: number, f: number): LibRecipe =>
  ({ id, cat, name, style, makes, ingredients, kcal, p, c, f });

export const RECIPES: LibRecipe[] = [
  r('burritos', 'Meal prep & mains', 'Chicken and bean freezer burritos', 'High protein', 5, '1 kg chicken breast, 250 g cooked rice, 1 tin kidney beans (240 g drained), 150 g salsa, 5 large wraps, 100 g light mozzarella', 575, 61, 54, 11),
  r('beef-potato', 'Meal prep & mains', 'Beef and potato boxes', 'Balanced', 4, '600 g 5% beef mince, 800 g potatoes, 300 g onion and peppers, 10 g olive oil, paprika, cumin', 385, 36, 39, 10),
  r('pasta-bake', 'Meal prep & mains', 'Chicken pasta bake', 'High carb', 4, '320 g dry pasta, 600 g chicken breast, 500 g passata, 300 g frozen veg, 120 g light mozzarella', 600, 56, 71, 8),
  r('tawook', 'Meal prep & mains', 'Shish tawook rice bowl', 'High protein', 1, '200 g chicken breast, 50 g 0% yoghurt marinade, 5 g olive oil, 150 g cooked basmati, 100 g salad, 30 g garlic yoghurt', 530, 59, 50, 8),
  r('shawarma', 'Meal prep & mains', 'Chicken shawarma plate', 'High protein', 1, '180 g chicken breast, 30 g yoghurt and shawarma spice, 1 small Arabic bread (50 g), 50 g garlic yoghurt, pickles and salad', 415, 55, 37, 4),
  r('kofta', 'Meal prep & mains', 'Beef kofta with tahini yoghurt', 'Low carb', 4, '800 g 5% beef mince, onion and parsley, 400 g salad, 200 g 0% yoghurt + 20 g tahini sauce', 345, 49, 10, 13),
  r('lentil-soup', 'Meal prep & mains', 'Red lentil and chicken soup', 'Balanced', 4, '300 g red lentils, 400 g chicken breast, 300 g onion and carrot, 10 g oil, cumin, lemon', 420, 43, 51, 5),
  r('fish-tray', 'Meal prep & mains', 'Lemon fish and potato tray', 'High carb', 1, '200 g basa fillet, 250 g potato, 150 g veg, 5 g olive oil, lemon, garlic', 505, 40, 58, 12),
  r('shakshuka', 'Meal prep & mains', 'Chickpea shakshuka', 'Balanced, vegetarian', 1, '3 eggs, 250 g passata and peppers, 120 g chickpeas, 1 small Arabic bread', 615, 36, 68, 19),
  r('labneh-wraps', 'Breakfast', 'Egg and labneh freezer wraps', 'Balanced', 4, "8 eggs, 4 wraps, 100 g light labneh, 100 g spinach, za'atar", 360, 20, 33, 16),
  r('karak-oats', 'Breakfast', 'Overnight karak oats', 'Balanced', 1, '50 g oats, 30 g vanilla whey, 150 g 0% yoghurt, 100 ml skimmed milk, 5 g honey, cardamom, saffron', 455, 49, 53, 6),
  r('pancakes', 'Breakfast', 'Oat protein pancakes', 'High protein', 1, '40 g oats, 30 g whey, 1 egg, 100 g egg whites, 60 g banana, baking powder', 450, 47, 45, 10),
  r('omelette', 'Breakfast', 'Loaded egg-white omelette', 'Keto, low carb', 1, '3 eggs, 150 g egg whites, 100 g peppers and spinach, 20 g light mozzarella', 365, 42, 7, 18),
  r('tuna-cakes', 'Snacks & shakes', 'Tuna rice cakes', 'High protein', 1, '1 tin light tuna (120 g drained), 2 rice cakes, 50 g low-fat cottage cheese, chilli flakes', 235, 37, 17, 2),
  r('choc-bowl', 'Snacks & shakes', 'Chocolate protein yoghurt bowl', 'High protein', 1, '200 g 0% yoghurt, 15 g chocolate whey, 5 g cocoa, 100 g frozen berries', 245, 34, 23, 2),
  r('date-froyo', 'Snacks & shakes', 'Date and tahini frozen yoghurt', 'Dessert', 1, '150 g 0% yoghurt, 15 g vanilla whey, 1 Medjool date, 8 g tahini', 270, 29, 29, 6),
  r('pb-shake', 'Snacks & shakes', 'Banana peanut butter shake', 'High carb, gaining', 1, '300 ml skimmed milk, 30 g whey, 120 g banana, 40 g oats, 15 g peanut butter', 575, 45, 75, 13),
  r('machboos', 'UAE favourites', 'Chicken machboos', 'Balanced', 4, '600 g chicken breast, 300 g dry basmati, 300 g onion and tomato, 10 g oil, machboos spice, dried lime', 470, 40, 62, 7),
  r('harees', 'UAE favourites', 'Light harees', 'High protein', 4, '200 g harees wheat, 600 g chicken breast, 10 g ghee, cinnamon', 375, 40, 38, 7),
  r('mandi', 'UAE favourites', 'Mandi-style chicken tray', 'Balanced', 4, '800 g skinless chicken legs (on the bone), 300 g dry basmati, 10 g ghee, onion, mandi spice', 455, 33, 61, 9),
  r('fattoush', 'UAE favourites', 'Fattoush with grilled chicken', 'High protein', 1, '180 g chicken breast, 200 g salad veg, 25 g toasted Arabic bread, 10 g olive oil, 10 g pomegranate molasses, sumac', 435, 44, 29, 16),
  r('hammour', 'UAE favourites', 'Grilled hammour with rice', 'High protein', 1, '200 g hammour fillet, 150 g cooked basmati, 100 g salad, 5 g olive oil, lemon', 410, 42, 45, 7),
  r('foul', 'UAE favourites', 'Foul medames bowl', 'Vegetarian', 1, '250 g fava beans (drained), 1 egg, 1 small Arabic bread, 100 g tomato and parsley, 5 g olive oil, cumin', 510, 30, 71, 12),
  r('burger', 'Takeaway at home', 'Lighter chicken burger', 'High protein', 1, '150 g chicken breast mince, 1 light bun (60 g), 1 light cheese slice, 15 g light mayo, lettuce, tomato', 410, 44, 32, 12),
  r('butter-chicken', 'Takeaway at home', 'Butter chicken with rice', 'Balanced', 4, '700 g chicken breast, 400 g passata, 200 g 0% yoghurt, 60 ml light cream, 10 g butter, spices, 600 g cooked basmati', 490, 50, 52, 9),
  r('burrito-bowl', 'Takeaway at home', 'Beef burrito bowl', 'Balanced', 4, '500 g 5% beef mince, 600 g cooked rice, 240 g black beans (drained), 200 g corn, 200 g salsa, 80 g light cheese', 535, 42, 69, 10),
  r('sushi-bowl', 'Takeaway at home', 'Salmon sushi bowl', 'Balanced', 1, '120 g salmon, 150 g cooked sushi rice, 80 g cucumber and edamame, 10 g soy sauce, 5 g sesame, nori', 530, 34, 51, 21),
  r('fried-rice', 'Takeaway at home', 'Chicken fried rice', 'High carb', 2, '300 g chicken breast, 300 g cooked rice, 2 eggs, 200 g mixed veg, 10 g oil, 20 g soy sauce', 530, 47, 52, 15),
  r('turkey-wrap', 'No cooking', 'Turkey and hummus wrap', 'High protein', 1, '1 large wrap, 100 g sliced turkey, 40 g hummus, 50 g salad', 400, 28, 45, 12),
  r('cottage-bowl', 'No cooking', 'Cottage cheese berry bowl', 'High protein', 1, '200 g low-fat cottage cheese, 100 g berries, 10 g honey, 15 g almonds', 320, 27, 30, 10),
  r('tuna-pasta', 'No cooking', 'Cold tuna pasta salad', 'High carb', 2, '160 g dry pasta, 240 g tuna (drained), 150 g sweetcorn, 100 g 0% yoghurt + 20 g light mayo, cucumber', 535, 47, 75, 5),
  r('halloumi-salad', 'Vegetarian', 'Lentil and halloumi salad', 'Vegetarian', 1, '150 g cooked green lentils, 50 g light halloumi, 100 g roasted peppers and courgette, 50 g rocket, 5 g olive oil', 390, 27, 39, 14),
  r('paneer', 'Vegetarian', 'Paneer tikka bowl', 'Vegetarian, high protein', 1, '120 g light paneer, 100 g 0% yoghurt marinade, 150 g peppers and onion, 150 g cooked basmati', 525, 42, 60, 13),
  r('falafel', 'Vegetarian', 'Baked falafel pita', 'Vegetarian', 2, '240 g chickpeas (drained), herbs and onion, 10 g oil, 2 small Arabic breads, 90 g 0% yoghurt + 10 g tahini, salad', 405, 20, 54, 12),
  r('kunafa', 'Desserts', 'Kunafa-style protein cups', 'Dessert', 4, '100 g kataifi dough, 300 g light ricotta, 60 g vanilla whey, 15 g butter, sugar-free syrup, 10 g pistachio', 260, 22, 20, 10),
  r('luqaimat', 'Desserts', 'Luqaimat-style baked bites', 'Dessert', 4, '120 g self-raising flour, 30 g vanilla whey, 1 egg, 150 g 0% yoghurt, 30 g date syrup, 10 g sesame, cardamom', 205, 15, 30, 3),
  r('umm-ali', 'Desserts', 'Lighter Umm Ali', 'Dessert', 4, '120 g wholemeal bread, 600 ml skimmed milk, 30 g vanilla whey, 20 g raisins, 20 g mixed nuts, 20 g honey, cinnamon', 210, 15, 29, 4),
];

export const CATEGORIES = [...new Set(RECIPES.map((x) => x.cat))];
