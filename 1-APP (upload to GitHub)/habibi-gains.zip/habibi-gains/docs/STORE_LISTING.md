# App Store / Google Play listing

## English

**Name:** Habibi Gains: Fitness & Food
**Subtitle (30):** Calories, trend & run clubs
**Keywords (100):** calorie,counter,diet,weight,loss,tracker,macro,protein,ramadan,arabic,uae,dubai,abu dhabi,run,gym

**Promotional text (170):**
Your transformation, made local. Shawarma to machboos already in. Snap your plate or a menu. Free run clubs across the UAE with badges you can't buy.

**Description:**
Habibi Gains is the fitness app built for the UAE.

TRACK THE REAL TREND
Daily weight jumps are water. Your smoothed trend line shows real progress and predicts your goal date.

TARGETS THAT LEARN YOU
Starts with a research-based plan, then measures your real metabolism from your own logs and adjusts your calories automatically. Every number has a "Why this number?" with the science behind it.

FOOD THAT KNOWS HERE
Shawarma, karak, machboos, harees, luqaimat and more. Scan barcodes. Snap your plate, or snap a menu and get the best dish for what you have left today.

TIMING COACH
When to eat protein and carbs around your training, and how to use creatine and caffeine properly, based on sports-nutrition research. Ramadan mode plans suhoor and iftar for your emirate.

RUN TOGETHER
Free run clubs across the UAE, women-only runs, side quests and badges you can only earn by showing up.

SHARE YOUR GAINS
Beautiful story cards for Instagram in one tap, with the option to show % instead of kg.

Full Arabic and English. Free core features. Premium adds the smart camera, menu scanner and more.

Habibi Gains gives general guidance, not medical advice.

---

## العربية

**الاسم:** حبيبي جينز: لياقة وأكل
**العنوان الفرعي:** سعرات، اتجاه الوزن، نوادي جري

**الوصف:**
حبيبي جينز هو تطبيق اللياقة المصمم للإمارات.

تابع الاتجاه الحقيقي
تقلبات الوزن اليومية ماء. خط الاتجاه يبين تقدمك الحقيقي ويتوقع موعد وصولك لهدفك.

أهداف تتعلم منك
نبدأ بخطة مبنية على الأبحاث، ثم نقيس معدل حرقك الحقيقي من سجلاتك ونعدّل سعراتك تلقائياً. كل رقم معه "ليش هالرقم؟" مع العلم ورا.

أكل يعرف بلدك
شاورما، كرك، مجبوس، هريس، لقيمات وغيرها. امسح الباركود، صوّر صحنك، أو صوّر المنيو واعرف أفضل طبق يناسب اللي باقي لك اليوم.

مدرب التوقيت
متى تاكل البروتين والكربوهيدرات حول تمرينك، وكيف تستخدم الكرياتين والكافيين صح، مبني على أبحاث التغذية الرياضية. ووضع رمضان يرتب السحور والإفطار حسب إمارتك.

اجروا مع بعض
نوادي جري مجانية في الإمارات، جري للنساء فقط، مهمات جانبية، وشارات ما تحصلها إلا إذا حضرت.

شارك إنجازك
بطاقات ستوري أنيقة لإنستغرام بضغطة وحدة، مع خيار عرض النسبة بدل الكيلو.

عربي وإنجليزي بالكامل. الأساسيات مجانية، وبريميوم يضيف الكاميرا الذكية وماسح المنيو وأكثر.

حبيبي جينز يقدم إرشادات عامة وليست نصيحة طبية.

---

## Screenshot headlines (one per screenshot)
1. **Your real trend. Not water weight.** (Today)
2. **Snap a plate. Or a menu.** (Camera result)
3. **Targets that learn your metabolism.** (Why this number)
4. **Built for Ramadan.** (Ramadan banner + Timing coach)
5. **Run together. Earn what you can't buy.** (Train)
6. **Flex it.** (Share card)
