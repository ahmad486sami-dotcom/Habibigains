// Admin & host tools. Hosts can create runs and quests; admins can also add meal picks and make hosts.
import { router } from 'expo-router';
import React, { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, Switch, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { demo, demoId, IS_DEMO } from '@/lib/demo';
import { success } from '@/lib/haptics';
import { EMIRATES } from '@/lib/ramadan';
import { useSession } from '@/lib/session';
import { supabase } from '@/lib/supabase';
import { useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Chips, Field, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

type Tab = 'event' | 'quest' | 'pick' | 'host';

function parseWhen(s: string) {
  const m = s.trim().match(/^(\d{4})-(\d{2})-(\d{2})\s+(\d{1,2}):(\d{2})$/);
  if (!m) return null;
  // Interpreted as UAE time (UTC+4).
  return new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4] - 4, +m[5])).toISOString();
}

export default function Admin() {
  const { t } = useI18n();
  const { theme } = useTheme();
  const { profile, session } = useSession();
  const isAdmin = profile?.role === 'admin';
  const [tab, setTab] = useState<Tab>('event');
  const [busy, setBusy] = useState(false);
  const [f, setF] = useState<Record<string, string>>({ emirate: 'Abu Dhabi', proof: 'photo', xp: '100', days: '7' });
  const [womenOnly, setWomenOnly] = useState(false);
  const set = (k: string) => (v: string) => setF((x) => ({ ...x, [k]: v }));

  if (!profile || profile.role === 'member') return null;

  const done = () => {
    success();
    Alert.alert(t('created'));
    setF({ emirate: f.emirate, proof: 'photo', xp: '100', days: '7' });
    setWomenOnly(false);
  };

  const submit = async () => {
    if (!session) return;
    setBusy(true);
    try {
      if (tab === 'event') {
        const starts = parseWhen(f.when ?? '');
        if (!f.title || !f.location || !starts) return Alert.alert(t('error'), t('when'));
        if (IS_DEMO) {
          demo.events.push({ id: demoId(), host_id: session.user.id, title: f.title, description: f.description ?? null, location_name: f.location, emirate: f.emirate, starts_at: starts, badge_name: f.badge || f.title, xp: Number(f.xp) || 100, women_only: womenOnly, checkin_code: 'HG-DEMO-1', going: 0, i_am_going: false });
        } else {
          const { error } = await supabase.from('events').insert({
            host_id: session.user.id, title: f.title, description: f.description || null, location_name: f.location,
            emirate: f.emirate, starts_at: starts, badge_name: f.badge || f.title, xp: Number(f.xp) || 100, women_only: womenOnly,
          });
          if (error) throw error;
        }
      }
      if (tab === 'quest') {
        if (!f.title) return;
        const ends = new Date(Date.now() + (Number(f.days) || 7) * 86_400_000).toISOString().slice(0, 10);
        if (IS_DEMO) {
          demo.quests.push({ id: demoId(), title_en: f.title, title_ar: f.title_ar || null, description: f.description || null, proof: f.proof as any, target_steps: Number(f.steps) || null, xp: Number(f.xp) || 50, ends_on: ends, done: false });
        } else {
          const { error } = await supabase.from('quests').insert({
            created_by: session.user.id, title_en: f.title, title_ar: f.title_ar || null, description: f.description || null,
            proof: f.proof, target_steps: Number(f.steps) || null, xp: Number(f.xp) || 50, ends_on: ends,
          });
          if (error) throw error;
        }
      }
      if (tab === 'pick') {
        if (!f.title || !f.restaurant || !f.kcal) return;
        const row = {
          title_en: f.title, title_ar: f.title_ar || null, restaurant: f.restaurant, kcal: Number(f.kcal), protein_g: Number(f.protein) || 0,
          price_aed: Number(f.price) || null, deal_text: f.deal || null, order_url: f.link || null, emirate: f.emirate,
        };
        if (IS_DEMO) demo.picks.push({ id: demoId(), ...row });
        else {
          const { error } = await supabase.from('meal_picks').insert(row);
          if (error) throw error;
        }
      }
      if (tab === 'host') {
        if (!f.userId) return;
        if (!IS_DEMO) {
          const { error } = await supabase.from('profiles').update({ role: 'host' }).eq('id', f.userId.trim());
          if (error) throw error;
        }
      }
      done();
    } catch (e: any) {
      Alert.alert(t('error'), e?.message ?? '');
    } finally {
      setBusy(false);
    }
  };

  const tabs: { value: Tab; label: string }[] = [
    { value: 'event', label: t('newEvent') },
    { value: 'quest', label: t('newQuest') },
    ...(isAdmin ? [{ value: 'pick' as Tab, label: t('newPick') }, { value: 'host' as Tab, label: t('makeHost') }] : []),
  ];
  const emirates = Object.keys(EMIRATES).map((e) => ({ value: e, label: e }));

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: theme.bg }}>
      <ScrollView contentContainerStyle={{ padding: 20, gap: 14, paddingBottom: 60 }} keyboardShouldPersistTaps="handled">
        <Row style={{ justifyContent: 'space-between' }}>
          <Txt v="h1">{t('admin')}</Txt>
          <Press onPress={() => router.back()} accessibilityLabel={t('close')} style={{ padding: 6 }}>
            <Icon name="close" />
          </Press>
        </Row>
        <Chips value={tab} onChange={setTab} options={tabs} />

        {tab === 'event' && (
          <>
            <Field label={t('title')} value={f.title ?? ''} onChangeText={set('title')} placeholder="Corniche Sunrise 5K" />
            <Field label={t('location')} value={f.location ?? ''} onChangeText={set('location')} placeholder="Corniche, by the flag" />
            <Field label={t('when')} value={f.when ?? ''} onChangeText={set('when')} placeholder="2026-11-07 06:00" autoCapitalize="none" />
            <Chips value={f.emirate} onChange={set('emirate')} options={emirates} />
            <Field label="Badge name" value={f.badge ?? ''} onChangeText={set('badge')} placeholder="Corniche Sunrise" />
            <Field label="Description" value={f.description ?? ''} onChangeText={set('description')} multiline style={{ height: 90, paddingTop: 14 }} />
            <Row style={{ justifyContent: 'space-between', backgroundColor: theme.card, borderRadius: 18, padding: 14 }}>
              <Txt>{t('womenOnly')}</Txt>
              <Switch value={womenOnly} onValueChange={setWomenOnly} trackColor={{ true: theme.accent }} />
            </Row>
          </>
        )}

        {tab === 'quest' && (
          <>
            <Field label={`${t('title')} (EN)`} value={f.title ?? ''} onChangeText={set('title')} placeholder="Spot a cat on your run" />
            <Field label={`${t('title')} (AR)`} value={f.title_ar ?? ''} onChangeText={set('title_ar')} placeholder="اعثر على قطة أثناء الجري" />
            <Chips value={f.proof} onChange={set('proof')} options={[{ value: 'photo', label: 'Photo' }, { value: 'steps', label: 'Steps' }, { value: 'honor', label: 'Honour' }]} />
            {f.proof === 'steps' ? <Field label="Target steps" keyboardType="number-pad" value={f.steps ?? ''} onChangeText={set('steps')} placeholder="10000" /> : null}
            <Row gap={10}>
              <View style={{ flex: 1 }}><Field label="XP" keyboardType="number-pad" value={f.xp} onChangeText={set('xp')} /></View>
              <View style={{ flex: 1 }}><Field label="Days active" keyboardType="number-pad" value={f.days} onChangeText={set('days')} /></View>
            </Row>
          </>
        )}

        {tab === 'pick' && (
          <>
            <Field label={`${t('title')} (EN)`} value={f.title ?? ''} onChangeText={set('title')} />
            <Field label={`${t('title')} (AR)`} value={f.title_ar ?? ''} onChangeText={set('title_ar')} />
            <Field label={t('restaurant')} value={f.restaurant ?? ''} onChangeText={set('restaurant')} />
            <Row gap={10}>
              <View style={{ flex: 1 }}><Field label={t('calories')} keyboardType="number-pad" value={f.kcal ?? ''} onChangeText={set('kcal')} /></View>
              <View style={{ flex: 1 }}><Field label={`${t('protein')} (g)`} keyboardType="number-pad" value={f.protein ?? ''} onChangeText={set('protein')} /></View>
            </Row>
            <Field label={t('price')} keyboardType="decimal-pad" value={f.price ?? ''} onChangeText={set('price')} />
            <Field label={t('deal')} value={f.deal ?? ''} onChangeText={set('deal')} />
            <Field label={t('link')} value={f.link ?? ''} onChangeText={set('link')} autoCapitalize="none" placeholder="https://" />
            <Chips value={f.emirate} onChange={set('emirate')} options={emirates} />
          </>
        )}

        {tab === 'host' && (
          <>
            <Txt muted>{t('hostHelp')}</Txt>
            <Field label={t('hostEmailOrId')} value={f.userId ?? ''} onChangeText={set('userId')} autoCapitalize="none" />
          </>
        )}

        <Button title={t('save')} loading={busy} onPress={submit} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
