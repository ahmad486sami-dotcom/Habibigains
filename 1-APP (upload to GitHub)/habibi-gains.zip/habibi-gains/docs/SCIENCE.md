# The science behind Habibi Gains

Every number in the app comes from here. Code: `src/lib/nutrition.ts`, `src/lib/trend.ts`, `src/lib/timing.ts`.

| Feature | What the app does | Evidence |
|---|---|---|
| Starting calories | Mifflin-St Jeor resting energy × activity factor (1.2–1.725) | Mifflin et al., *Am J Clin Nutr* 1990 |
| Fat-loss pace | 0.7% of body weight per week (range 0.5–1.0%); warns above 1%/week | Helms et al., *JISSN* 2014 |
| Muscle-gain pace | 0.35% per week (range 0.25–0.5%) | Iraki et al., *Sports* 2019 |
| Energy per kg | ~7,700 kcal per kg of body-weight change | Hall, *Int J Obes* 2008 |
| Measured metabolism | After 14+ logged days: real TDEE = average intake − (trend slope × 7,700) | Energy-balance method (Hall 2008) |
| Protein | 1.6 g/kg (gain/maintain), 2.0 g/kg (fat loss); BMI > 30 uses weight at BMI 25 | Morton et al., *Br J Sports Med* 2018; Helms 2014 |
| Calorie floor | Never below 1,500 (men) / 1,200 (women) | Common clinical safety floor |
| Trend line | Exponentially smoothed average (α = 0.1), gap-aware | Hacker's Diet method |
| Protein per meal | ~0.4 g/kg per meal over 3–5 meals | Schoenfeld & Aragon, *JISSN* 2018 |
| Carbs & training | Carb meal 1–4 h before; carbs + protein within ~2 h after | Kerksick et al., ISSN nutrient timing, 2017 |
| Pre-sleep protein | 25–40 g slow protein if the day's protein falls short | Jäger et al., ISSN protein, 2017 |
| Creatine | 3–5 g/day, any time, consistency matters most | Kreider et al., ISSN creatine, 2017 |
| Caffeine | ~3 mg/kg, 30–60 min pre-training; skip within ~6 h of bed; ≤400 mg/day | Guest et al., ISSN caffeine, 2021 |
| Ramadan times | NOAA solar formulas; Fajr at −18.2°, Maghrib = sunset + 3 min, per emirate | Matches Abu Dhabi calendar within a few minutes |

## Honesty rules in the app
- Daily weight swings of 1–2 kg are explained as water, salt and food, never as fat.
- A plateau is only called after the trend is flat for ~2 weeks of consistent logging.
- Photo calorie estimates show a ±20–30% accuracy note.
- Every plan screen shows: *a guide, not medical advice*.
