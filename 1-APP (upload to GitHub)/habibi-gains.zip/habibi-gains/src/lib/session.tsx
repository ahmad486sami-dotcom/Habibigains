import type { Session } from '@supabase/supabase-js';
import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { supabase } from './supabase';

export type Profile = {
  id: string;
  display_name: string | null;
  role: 'member' | 'host' | 'admin';
  sex: 'male' | 'female' | null;
  birth_year: number | null;
  height_cm: number | null;
  start_weight_kg: number | null;
  goal_weight_kg: number | null;
  goal: 'lose' | 'maintain' | 'gain';
  activity: 'low' | 'light' | 'moderate' | 'high';
  calorie_target: number | null;
  protein_target_g: number | null;
  ramadan_mode: boolean;
  emirate: string;
  wake_time: string;
  sleep_time: string;
  training_time: string | null;
  use_creatine: boolean;
  use_caffeine: boolean;
  language: 'en' | 'ar';
  accent: string;
  xp: number;
  streak_days: number;
  week_start_day?: number | null;
  is_premium: boolean;
  water_goal_ml: number;
  created_at: string;
};

type Ctx = {
  session: Session | null;
  profile: Profile | null;
  loading: boolean;
  refreshProfile: () => Promise<void>;
  updateProfile: (patch: Partial<Profile>) => Promise<void>;
  signOut: () => Promise<void>;
};

const SessionCtx = createContext<Ctx | null>(null);

export function SessionProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const loadProfile = useCallback(async (uid: string | undefined) => {
    if (!uid) {
      setProfile(null);
      return;
    }
    const { data } = await supabase.from('profiles').select('*').eq('id', uid).maybeSingle();
    setProfile((data as Profile) ?? null);
    // Count today as active for the streak.
    supabase.rpc('touch_streak').then(({ data: s }) => {
      if (typeof s === 'number') setProfile((p) => (p ? { ...p, streak_days: s } : p));
    });
  }, []);

  useEffect(() => {
    supabase.auth.getSession().then(async ({ data }) => {
      setSession(data.session);
      await loadProfile(data.session?.user.id);
      setLoading(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => {
      setSession(s);
      loadProfile(s?.user.id);
    });
    return () => sub.subscription.unsubscribe();
  }, [loadProfile]);

  const refreshProfile = useCallback(async () => {
    await loadProfile(session?.user.id);
  }, [loadProfile, session]);

  const updateProfile = useCallback(
    async (patch: Partial<Profile>) => {
      if (!session) return;
      setProfile((p) => (p ? { ...p, ...patch } : p));
      const { error } = await supabase.from('profiles').update(patch).eq('id', session.user.id);
      if (error) await loadProfile(session.user.id);
    },
    [session, loadProfile],
  );

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setProfile(null);
  }, []);

  return (
    <SessionCtx.Provider value={{ session, profile, loading, refreshProfile, updateProfile, signOut }}>
      {children}
    </SessionCtx.Provider>
  );
}

export function useSession() {
  const ctx = useContext(SessionCtx);
  if (!ctx) throw new Error('useSession outside SessionProvider');
  return ctx;
}

/** Onboarding is done once the plan numbers exist. */
export function needsOnboarding(p: Profile | null) {
  return !p || !p.calorie_target || !p.height_cm || !p.start_weight_kg;
}
