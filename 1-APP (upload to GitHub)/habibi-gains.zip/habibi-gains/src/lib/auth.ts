// Email + password accounts.
// New accounts are created by the `signup` edge function already confirmed,
// so people are in straight away without waiting for a confirmation email.
import { supabase, SUPABASE_KEY, SUPABASE_URL } from './supabase';

export class AuthError extends Error {
  constructor(public code: 'email_taken' | 'invalid_email' | 'weak_password' | 'wrong_password' | 'network' | 'failed') {
    super(code);
  }
}

const clean = (email: string) => email.trim().toLowerCase();

export async function signInWithPassword(email: string, password: string) {
  const { error } = await supabase.auth.signInWithPassword({ email: clean(email), password });
  if (error) {
    const m = error.message.toLowerCase();
    if (m.includes('invalid') || m.includes('credentials')) throw new AuthError('wrong_password');
    if (m.includes('network') || m.includes('fetch')) throw new AuthError('network');
    throw new AuthError('failed');
  }
}

export async function signUpWithPassword(name: string, email: string, password: string) {
  let res: Response;
  try {
    res = await fetch(`${SUPABASE_URL}/functions/v1/signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', apikey: SUPABASE_KEY },
      body: JSON.stringify({ name: name.trim(), email: clean(email), password }),
    });
  } catch {
    throw new AuthError('network');
  }
  if (!res.ok) {
    const body = (await res.json().catch(() => ({}))) as { error?: string };
    if (body.error === 'email_taken') throw new AuthError('email_taken');
    if (body.error === 'invalid_email') throw new AuthError('invalid_email');
    if (body.error === 'weak_password') throw new AuthError('weak_password');
    throw new AuthError('failed');
  }
  await signInWithPassword(email, password);
}

export async function changePassword(password: string) {
  const { error } = await supabase.auth.updateUser({ password });
  if (error) throw error;
}

export async function deleteAccount() {
  const { error } = await supabase.functions.invoke('delete-account', { method: 'POST' });
  if (error) throw error;
  await supabase.auth.signOut();
}
