import * as Notifications from 'expo-notifications';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});

export async function enableReminders(lang: 'en' | 'ar') {
  const { status } = await Notifications.requestPermissionsAsync();
  if (status !== 'granted') return false;
  await Notifications.cancelAllScheduledNotificationsAsync();

  const msgs =
    lang === 'ar'
      ? [
          { hour: 8, minute: 0, title: 'صباح الخير يا حبيبي', body: 'سجّل وزنك قبل الفطور عشان الاتجاه يكون دقيق.' },
          { hour: 20, minute: 30, title: 'لا تكسر السلسلة', body: 'سجّل أكلك اليوم وحافظ على أيامك المتواصلة.' },
        ]
      : [
          { hour: 8, minute: 0, title: 'Morning, habibi', body: 'Weigh in before breakfast to keep your trend accurate.' },
          { hour: 20, minute: 30, title: 'Don’t break the streak', body: 'Log today’s food and keep your streak alive.' },
        ];

  for (const m of msgs) {
    await Notifications.scheduleNotificationAsync({
      content: { title: m.title, body: m.body },
      trigger: { type: Notifications.SchedulableTriggerInputTypes.DAILY, hour: m.hour, minute: m.minute },
    });
  }
  return true;
}

export async function disableReminders() {
  await Notifications.cancelAllScheduledNotificationsAsync();
}
