import { router, useFocusEffect } from 'expo-router';
import * as WebBrowser from 'expo-web-browser';
import React, { useCallback, useState } from 'react';
import { Alert, View } from 'react-native';
import Animated, { FadeInDown, LinearTransition, ZoomOut } from 'react-native-reanimated';
import { useI18n } from '@/i18n/i18n';
import { addFoodLog, deleteFoodLog, fetchDayLogs, fetchMealPicks, FoodLog, MealPick } from '@/lib/data';
import { success, warn } from '@/lib/haptics';
import { sumDay } from '@/lib/nutrition';
import { useSession } from '@/lib/session';
import { useTheme } from '@/theme/theme';
import { Bar, Ticker } from '@/ui/Graphics';
import { Icon } from '@/ui/Icon';
import { Card, Row, Screen, SectionTitle } from '@/ui/Layout';
import { Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function Food() {
  const { t, lang } = useI18n();
  const { theme } = useTheme();
  const { profile, session } = useSession();
  const [logs, setLogs] = useState<FoodLog[]>([]);
  const [picks, setPicks] = useState<MealPick[]>([]);

  const target = profile?.calorie_target ?? 2000;
  const totals = sumDay(logs);

  const load = useCallback(async () => {
    const l = await fetchDayLogs().catch(() => [] as FoodLog[]);
    setLogs(l);
    if (profile) setPicks(await fetchMealPicks(profile.emirate, Math.max(400, target - sumDay(l).kcal)).catch(() => []));
  }, [profile, target]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const meals = profile?.ramadan_mode ? (['iftar', 'dinner', 'snack', 'suhoor'] as const) : (['breakfast', 'lunch', 'dinner', 'snack'] as const);

  const remove = (log: FoodLog) =>
    Alert.alert(log.name, undefined, [
      { text: t('cancel'), style: 'cancel' },
      {
        text: t('delete'),
        style: 'destructive',
        onPress: async () => {
          warn();
          setLogs((ls) => ls.filter((x) => x.id !== log.id));
          await deleteFoodLog(log.id);
        },
      },
    ]);

  const addPick = async (p: MealPick) => {
    if (!session) return;
    await addFoodLog(session.user.id, {
      name: lang === 'ar' && p.title_ar ? p.title_ar : p.title_en,
      meal: profile?.ramadan_mode ? 'iftar' : 'dinner',
      servings: 1,
      kcal: p.kcal,
      protein_g: p.protein_g,
      carbs_g: 0,
      fat_g: 0,
      source: 'pick',
    });
    success();
    load();
  };

  return (
    <Screen>
      <Txt v="h1">{t('todaysFood')}</Txt>

      <Card index={0}>
        <Row style={{ justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <View>
            <Ticker value={totals.kcal} v="hero" />
            <Txt v="small" muted>{`/ ${target.toLocaleString('en-US')} ${t('kcal')}`}</Txt>
          </View>
          <View style={{ alignItems: 'flex-end', gap: 2 }}>
            <Txt v="small" muted>{`${t('protein')} ${Math.round(totals.protein)}${t('g')}`}</Txt>
            <Txt v="small" muted>{`${t('carbs')} ${Math.round(totals.carbs)}${t('g')} · ${t('fat')} ${Math.round(totals.fat)}${t('g')}`}</Txt>
          </View>
        </Row>
        <Bar progress={totals.kcal / target} height={8} color={totals.kcal > target ? theme.danger : undefined} />
      </Card>

      <Row gap={10}>
        <Press onPress={() => router.push('/add-food')} style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: theme.card, borderRadius: 999, height: 54, paddingHorizontal: 18 }}>
          <Icon name="search" color={theme.muted} size={20} />
          <Txt muted numberOfLines={1} style={{ flex: 1 }}>{t('searchFood')}</Txt>
        </Press>
        <Press onPress={() => router.push('/camera')} accessibilityLabel={t('cameraTitle')} style={{ width: 54, height: 54, borderRadius: 27, backgroundColor: theme.accent, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="camera" color={theme.onAccent} />
        </Press>
      </Row>

      {meals.map((meal, mi) => {
        const items = logs.filter((l) => l.meal === meal);
        const kcal = items.reduce((s, l) => s + l.kcal, 0);
        return (
          <Animated.View key={meal} entering={FadeInDown.delay(mi * 60).springify()} layout={LinearTransition.springify()}>
            <View style={{ backgroundColor: theme.card, borderRadius: 24, padding: 16, gap: 6 }}>
              <Row style={{ justifyContent: 'space-between' }}>
                <Txt v="h3">{t(meal)}</Txt>
                <Row gap={10}>
                  {kcal > 0 ? <Txt v="small" muted>{`${kcal} ${t('kcal')}`}</Txt> : null}
                  <Press
                    onPress={() => router.push({ pathname: '/add-food', params: { meal } })}
                    accessibilityLabel={`${t('add')} ${t(meal)}`}
                    style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: theme.cardHigh, alignItems: 'center', justifyContent: 'center' }}
                  >
                    <Icon name="plus" size={16} />
                  </Press>
                </Row>
              </Row>
              {items.map((l) => (
                <Animated.View key={l.id} exiting={ZoomOut.duration(180)} layout={LinearTransition}>
                  <Press onLongPress={() => remove(l)} haptic={false} scaleTo={0.98} style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8 }}>
                    <View style={{ flex: 1, paddingEnd: 12 }}>
                      <Txt numberOfLines={1}>{l.name}</Txt>
                      <Txt v="small" faint>{`${l.servings !== 1 ? `${l.servings} × · ` : ''}${Math.round(l.protein_g)}${t('g')} ${t('protein').toLowerCase()}`}</Txt>
                    </View>
                    <Txt v="bodyStrong">{l.kcal}</Txt>
                  </Press>
                </Animated.View>
              ))}
            </View>
          </Animated.View>
        );
      })}

      {picks.length ? (
        <>
          <SectionTitle>{t('picksTitle')}</SectionTitle>
          {picks.slice(0, 4).map((p, i) => (
            <Card key={p.id} index={i}>
              <Row style={{ justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <View style={{ flex: 1, gap: 4 }}>
                  <Txt v="h3">{lang === 'ar' && p.title_ar ? p.title_ar : p.title_en}</Txt>
                  <Txt v="small" muted>{`${p.restaurant}${p.price_aed ? ` · AED ${p.price_aed}` : ''}`}</Txt>
                  <Txt v="small" muted>{`${p.kcal} ${t('kcal')} · ${p.protein_g}${t('g')} ${t('protein').toLowerCase()}`}</Txt>
                  {p.deal_text ? <Txt v="small" color={theme.accent}>{p.deal_text}</Txt> : null}
                </View>
                <View style={{ gap: 8 }}>
                  <Press onPress={() => addPick(p)} style={{ backgroundColor: theme.cardHigh, borderRadius: 999, paddingHorizontal: 14, height: 36, justifyContent: 'center' }}>
                    <Txt v="bodyStrong" style={{ fontSize: 13 }}>{t('add')}</Txt>
                  </Press>
                  {p.order_url ? (
                    <Press onPress={() => WebBrowser.openBrowserAsync(p.order_url!)} style={{ backgroundColor: theme.accent, borderRadius: 999, paddingHorizontal: 14, height: 36, justifyContent: 'center' }}>
                      <Txt v="bodyStrong" color={theme.onAccent} style={{ fontSize: 13 }}>{t('order')}</Txt>
                    </Press>
                  ) : null}
                </View>
              </Row>
            </Card>
          ))}
        </>
      ) : null}
    </Screen>
  );
}
