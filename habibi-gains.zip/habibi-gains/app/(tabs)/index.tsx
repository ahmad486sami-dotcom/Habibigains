// Today: three things only. Weight trend, calories left, and one swipeable "For you" card.
import { router, useFocusEffect } from 'expo-router';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Dimensions, FlatList, RefreshControl, View } from 'react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { useI18n } from '@/i18n/i18n';
import { deleteExercise, ExerciseLog, fetchExercise, fetchExerciseTotals, fetchQuests, getWater, Meal, Quest, setWater as saveWater } from '@/lib/data';
import { MEAL_LABEL, macroTargets, mealsFor } from '@/lib/day';
import { Emirate, fastingTimes, formatLeft, isRamadanNow, ramadanStatus } from '@/lib/ramadan';
import { useSession } from '@/lib/session';
import { buildTiming } from '@/lib/timing';
import { useToday } from '@/lib/useToday';
import { buildWeek } from '@/lib/week';
import { Pedometer } from 'expo-sensors';
import { saveSteps } from '@/lib/social';
import { fmtWater, unitsOf, waterStepLabel, waterSteps } from '@/lib/units';
import { useTheme } from '@/theme/theme';
import { WeekStrip } from '@/ui/WeekStrip';
import { Bar, Ring, Ticker, TrendChart } from '@/ui/Graphics';
import { Icon, IconName } from '@/ui/Icon';
import { Card, Row, Screen } from '@/ui/Layout';
import { Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

const W = Dimensions.get('window').width;
const CARD_W = W - 40;

type ForYou = { key: string; icon: IconName; label: string; title: string; body?: string; dark?: boolean; cta?: string; onPress?: () => void; onCta?: () => void };

export default function Today() {
  const { t, lang } = useI18n();
  const { theme } = useTheme();
  const { profile, updateProfile } = useSession();
  const d = useToday(profile);
  const [quest, setQuest] = useState<(Quest & { done: boolean }) | null>(null);
  const [water, setWater] = useState(0);
  const [now, setNow] = useState(new Date());
  const [page, setPage] = useState(0);

  const target = profile?.calorie_target ?? 2000;
  const proteinTarget = profile?.protein_target_g ?? 140;
  const [workouts, setWorkouts] = useState<ExerciseLog[]>([]);
  const [exTotals, setExTotals] = useState<{ day: string; kcal: number }[]>([]);
  useFocusEffect(
    useCallback(() => {
      fetchExercise().then(setWorkouts).catch(() => {});
      fetchExerciseTotals(14).then(setExTotals).catch(() => {});
    }, []),
  );
  const exKcal = workouts.reduce((a, w) => a + w.kcal, 0);
  const units = unitsOf(profile);
  // Steps from the phone's motion chip (same source as Apple Health's iPhone steps).
  const [steps, setSteps] = useState<number | null>(null);
  useFocusEffect(
    useCallback(() => {
      (async () => {
        try {
          if (!(await Pedometer.isAvailableAsync())) return;
          const perm = await Pedometer.requestPermissionsAsync();
          if (!perm.granted) return;
          const start = new Date(); start.setHours(0, 0, 0, 0);
          const r = await Pedometer.getStepCountAsync(start, new Date());
          setSteps(r.steps);
          saveSteps(r.steps).catch(() => {});
        } catch {}
      })();
    }, []),
  );
  const left = target + exKcal - d.totals.kcal;
  const macros = macroTargets(target, proteinTarget);
  const ar = lang === 'ar';
  const meals = mealsFor(!!profile?.ramadan_mode);
  const mealKcal = (m: Meal) => Math.round(d.logs.filter((l) => l.meal === m).reduce((a, l) => a + l.kcal, 0));
  const addWater = async (ml: number) => {
    const next = Math.max(0, water + ml);
    setWater(next);
    saveWater(next).catch(() => {});
  };
  const week = useMemo(() => buildWeek(d.daily, d.totals.kcal, target, lang, profile?.week_start_day ?? 6, new Date(), exTotals), [d.daily, d.totals.kcal, target, lang, profile?.week_start_day, exTotals]);
  const emirate = (profile?.emirate ?? 'Abu Dhabi') as Emirate;

  useEffect(() => {
    const i = setInterval(() => setNow(new Date()), 60_000);
    return () => clearInterval(i);
  }, []);
  useEffect(() => {
    getWater().then(setWater).catch(() => {});
  }, [d.totals.kcal]);

  const ramadan = profile?.ramadan_mode ? ramadanStatus(emirate, now) : null;
  const suggestRamadan = !profile?.ramadan_mode && isRamadanNow(now);

  const nextUp = useMemo(() => {
    if (!profile) return null;
    const items = buildTiming({
      weightKg: d.last?.trend ?? Number(profile.start_weight_kg ?? 75),
      wake: profile.wake_time,
      sleep: profile.sleep_time,
      training: profile.training_time,
      goal: profile.goal,
      proteinTargetG: proteinTarget,
      useCreatine: profile.use_creatine,
      useCaffeine: profile.use_caffeine,
      ramadan: profile.ramadan_mode ? fastingTimes(emirate, now) : null,
    });
    const mins = now.getHours() * 60 + now.getMinutes();
    return items.find((i) => {
      const [h, m] = i.time.split(':').map(Number);
      return h * 60 + m >= mins;
    }) ?? items[0];
  }, [profile, d.last, now, proteinTarget, emirate]);

  // Build the "For you" deck, most useful first.
  const cards: ForYou[] = [];
  if (suggestRamadan)
    cards.push({ key: 'ramadan', icon: 'moon', label: t('ramadanMode'), title: t('ramadanSuggest'), cta: t('turnOn'), onCta: () => updateProfile({ ramadan_mode: true }) });
  if (d.suggested && d.measured && Math.abs(d.suggested.kcal - target) >= 80)
    cards.push({
      key: 'tdee', icon: 'bolt', label: t('measuredTitle'), title: t('measuredBody', { tdee: d.measured.toLocaleString('en-US') }),
      body: t('measuredSuggest', { kcal: d.suggested.kcal.toLocaleString('en-US') }), cta: t('applyTarget'),
      onCta: () => updateProfile({ calorie_target: d.suggested!.kcal, protein_target_g: d.suggested!.protein }), onPress: () => router.push('/why'),
    });
  if (nextUp)
    cards.push({ key: 'next', icon: 'clock', label: `${t('nextUp')} · ${nextUp.time}`, title: t(`tm_${nextUp.titleKey}` as 'tm_lunch'), body: nextUp.detail[lang], onPress: () => router.push('/timing') });
  cards.push({ key: 'supps', icon: 'pill', label: lang === 'ar' ? 'دليل المكملات' : 'Supplement guide', title: lang === 'ar' ? 'وش يشتغل فعلاً ووش لا' : 'What works, and what is a waste of money', onPress: () => router.push('/supplements') });

  const change = d.last && d.startWeight ? d.last.trend - Number(d.startWeight) : 0;
  const paceText = { too_fast: t('paceTooFast'), stalled: t('paceStalled'), on_track: t('paceOnTrack'), drifting: t('paceDrifting'), unknown: t('paceUnknown') }[d.pace];

  return (
    <Screen refreshControl={<RefreshControl refreshing={false} onRefresh={d.reload} tintColor={theme.muted} />}>
      {/* Header */}
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="h1" numberOfLines={1} style={{ flex: 1 }}>{t('greeting', { name: profile?.display_name?.split(' ')[0] ?? 'habibi' })}</Txt>
        <Row gap={8}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: theme.card, borderRadius: 999, paddingHorizontal: 12, height: 38 }}>
            <Icon name="flame" size={16} color={theme.accent} />
            <Txt v="bodyStrong">{profile?.streak_days ?? 0}</Txt>
          </View>
          <Press onPress={() => router.push('/settings')} accessibilityLabel={t('settings')} style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: theme.card, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="settings" size={18} />
          </Press>
        </Row>
      </Row>

      {ramadan ? (
        <Animated.View entering={FadeInDown.springify()} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: theme.card, borderRadius: 999, paddingHorizontal: 16, height: 44 }}>
          <Icon name="moon" size={18} color={theme.accent} />
          <Txt v="bodyStrong">
            {ramadan.kind === 'iftar' ? t('ramadanBanner', { t: formatLeft(ramadan.msLeft) }) : t('suhoorBanner', { t: formatLeft(ramadan.msLeft) })}
          </Txt>
        </Animated.View>
      ) : null}


      {/* 2 · Calories + protein */}
      <Card index={1} onPress={() => router.push('/(tabs)/food')}>
        <Row gap={18}>
          <Ring size={124} stroke={12} progress={d.totals.kcal / (target + exKcal)}>
            <Ticker value={Math.abs(left)} v="h2" />
            <Txt v="small" muted style={{ fontSize: 11 }}>{left >= 0 ? t('kcalLeft') : t('kcalOver')}</Txt>
          </Ring>
          <View style={{ flex: 1, gap: 14 }}>
            <View style={{ gap: 6 }}>
              <Row style={{ justifyContent: 'space-between' }}>
                <Txt v="small" muted>{t('protein')}</Txt>
                <Txt v="small">{`${Math.round(d.totals.protein)}/${proteinTarget}${t('g')}`}</Txt>
              </Row>
              <Bar progress={d.totals.protein / proteinTarget} />
            </View>
            <View style={{ gap: 6 }}>
              <Row style={{ justifyContent: 'space-between' }}>
                <Txt v="small" muted>{ar ? 'كارب' : 'Carbs'}</Txt>
                <Txt v="small">{`${Math.round(d.totals.carbs)}/${macros.carbs}${t('g')}`}</Txt>
              </Row>
              <Bar progress={d.totals.carbs / Math.max(1, macros.carbs)} />
            </View>
            <View style={{ gap: 6 }}>
              <Row style={{ justifyContent: 'space-between' }}>
                <Txt v="small" muted>{ar ? 'دهون' : 'Fat'}</Txt>
                <Txt v="small">{`${Math.round(d.totals.fat)}/${macros.fat}${t('g')}`}</Txt>
              </Row>
              <Bar progress={d.totals.fat / Math.max(1, macros.fat)} />
            </View>
          </View>
        </Row>
        <Txt v="small" muted>
          {ar ? `الهدف ${target} − الأكل ${Math.round(d.totals.kcal)} + التمرين ${exKcal} = ${left} متبقي` : `Goal ${target} − Food ${Math.round(d.totals.kcal)} + Exercise ${exKcal} = ${left} left`}
        </Txt>
      </Card>

      {/* 2b · Week strip: the weekly calorie bank under the day */}
      <WeekStrip week={week} lang={lang} index={2} onPress={() => router.push('/(tabs)/progress')} />

      {/* Meals: log straight from Today */}
      <Txt v="label" muted style={{ marginTop: 4 }}>{ar ? 'الوجبات' : 'Meals'}</Txt>
      <Card index={3}>
        {meals.map((m, i) => (
          <Row key={m} style={{ justifyContent: 'space-between', paddingVertical: 4, borderTopWidth: i ? 1 : 0, borderTopColor: theme.cardHigh, paddingTop: i ? 10 : 4 }}>
            <View style={{ flex: 1 }}>
              <Txt v="bodyStrong">{ar ? MEAL_LABEL[m].ar : MEAL_LABEL[m].en}</Txt>
              <Txt v="small" faint>{mealKcal(m) ? `${mealKcal(m)} kcal` : (ar ? 'لم تسجل بعد' : 'Nothing logged yet')}</Txt>
            </View>
            <Press onPress={() => router.push({ pathname: '/add-food', params: { meal: m } })} style={{ paddingHorizontal: 18, height: 36, borderRadius: 18, backgroundColor: theme.cardHigh, justifyContent: 'center' }}>
              <Txt v="bodyStrong" color={theme.accent} style={{ fontSize: 14 }}>{ar ? 'سجّل' : 'Log'}</Txt>
            </Press>
          </Row>
        ))}
      </Card>

      {/* Exercise: workout calories go back into today's budget */}
      <Card index={4}>
        <Row style={{ justifyContent: 'space-between' }}>
          <View style={{ flex: 1 }}>
            <Txt v="bodyStrong">{ar ? 'التمرين' : 'Exercise'}</Txt>
            <Txt v="small" faint>{exKcal ? (ar ? `+${exKcal} سعرة أضيفت لميزانية اليوم` : `+${exKcal} kcal added to today's budget`) : (ar ? 'لا تمارين اليوم' : 'No workouts today')}</Txt>
          </View>
          <Press onPress={() => router.push({ pathname: '/exercise', params: { weight: String(Math.round(d.last?.trend ?? Number(profile?.start_weight_kg ?? 75))) } })} style={{ paddingHorizontal: 18, height: 36, borderRadius: 18, backgroundColor: theme.cardHigh, justifyContent: 'center' }}>
            <Txt v="bodyStrong" color={theme.accent} style={{ fontSize: 14 }}>{ar ? 'أضف' : 'Add'}</Txt>
          </Press>
        </Row>
        {workouts.map((w) => (
          <Row key={w.id} style={{ justifyContent: 'space-between' }}>
            <Txt v="small">{`${w.name} · ${w.minutes} min`}</Txt>
            <Row gap={10}>
              <Txt v="small">{`${w.kcal} kcal`}</Txt>
              <Press onPress={() => { setWorkouts((x) => x.filter((y) => y.id !== w.id)); deleteExercise(w.id).catch(() => {}); }} style={{ padding: 4 }}>
                <Icon name="trash" size={14} color={theme.faint} />
              </Press>
            </Row>
          </Row>
        ))}
      </Card>

      {/* Steps */}
      {steps != null ? (
        <Card index={4}>
          <Row style={{ justifyContent: 'space-between' }}>
            <Txt v="bodyStrong">{ar ? 'الخطوات' : 'Steps'}</Txt>
            <Txt v="bodyStrong">{steps.toLocaleString('en-US')}</Txt>
          </Row>
          <Bar progress={steps / 10000} />
          <Txt v="small" faint>{ar ? 'من حساس الحركة في جوالك' : 'From your iPhone, updates when you open the app'}</Txt>
        </Card>
      ) : null}

      {/* Water */}
      <Card index={4}>
        <Row style={{ justifyContent: 'space-between' }}>
          <View style={{ flex: 1, gap: 6 }}>
            <Row style={{ justifyContent: 'space-between' }}>
              <Txt v="bodyStrong">{ar ? 'الماء' : 'Water'}</Txt>
              <Txt v="small">{`${fmtWater(water, units)} / ${fmtWater(profile?.water_goal_ml ?? 3000, units)}`}</Txt>
            </Row>
            <Bar progress={water / (profile?.water_goal_ml ?? 3000)} />
          </View>
          <Row gap={6} style={{ marginLeft: 12 }}>
            {waterSteps(units).map((ml) => (
              <Press key={ml} onPress={() => addWater(ml)} style={{ paddingHorizontal: 10, height: 36, borderRadius: 18, backgroundColor: theme.cardHigh, justifyContent: 'center' }}>
                <Txt v="bodyStrong" color={ml < 0 ? theme.muted : theme.accent} style={{ fontSize: 13 }}>{waterStepLabel(ml, units)}</Txt>
              </Press>
            ))}
          </Row>
        </Row>
      </Card>

      {/* Fasting shortcut */}
      <Press onPress={() => router.push('/fasting')} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 16, borderRadius: 18, backgroundColor: theme.card }}>
        <Icon name="clock" size={18} color={theme.accent} />
        <Txt v="bodyStrong" style={{ flex: 1 }}>{lang === 'ar' ? 'مؤقت الصيام' : 'Fasting timer'}</Txt>
        <Icon name="chevron" size={16} color={theme.faint} />
      </Press>

      {/* 1 · Weight trend */}
      <Card index={5} onPress={() => router.push('/(tabs)/progress')}>
        <Row style={{ justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <View>
            <Txt v="label" muted>{t('trendWeight')}</Txt>
            {d.last ? <Ticker value={d.last.trend} decimals={1} suffix={` ${t('kg')}`} /> : <Txt v="number">—</Txt>}
          </View>
          {d.last && d.startWeight ? <Txt v="h3" color={theme.accent}>{`${change > 0 ? '+' : ''}${change.toFixed(1)} ${t('kg')}`}</Txt> : null}
        </Row>
        {d.trend.length > 1 ? <TrendChart points={d.trend.slice(-45)} width={W - 76} height={84} /> : null}
        <Txt v="small" muted>
          {d.goalDate && profile?.goal_weight_kg
            ? t('onPace', { kg: profile.goal_weight_kg, date: d.goalDate.toLocaleDateString(lang === 'ar' ? 'ar-AE' : 'en-GB', { day: 'numeric', month: 'short' }) })
            : d.trend.length > 1 ? paceText : t('noTrendYet')}
        </Txt>
      </Card>

      {/* 3 · For you */}
      {cards.length ? (
        <Animated.View entering={FadeInDown.delay(140).springify()} style={{ marginHorizontal: -20 }}>
          <FlatList
            data={cards}
            horizontal
            pagingEnabled={false}
            snapToInterval={CARD_W + 10}
            decelerationRate="fast"
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 20, gap: 10 }}
            keyExtractor={(c) => c.key}
            onMomentumScrollEnd={(e) => setPage(Math.round(e.nativeEvent.contentOffset.x / (CARD_W + 10)))}
            renderItem={({ item: c }) => {
              const fg = c.dark ? theme.bg : theme.text;
              const sub = c.dark ? theme.bg : theme.muted;
              return (
                <Press onPress={c.onPress} scaleTo={0.98} haptic={!!c.onPress} style={{ width: CARD_W, minHeight: 150, backgroundColor: c.dark ? theme.text : theme.card, borderRadius: 28, padding: 18, gap: 8 }}>
                  <Row style={{ justifyContent: 'space-between' }}>
                    <Txt v="label" color={sub}>{c.label}</Txt>
                    <Icon name={c.icon} size={18} color={c.dark ? theme.bg : theme.accent} />
                  </Row>
                  <Txt v="h2" color={fg}>{c.title}</Txt>
                  {c.body ? <Txt v="small" color={sub} numberOfLines={3}>{c.body}</Txt> : null}
                  {c.cta ? (
                    <Press onPress={c.onCta} style={{ alignSelf: 'flex-start', marginTop: 4, backgroundColor: theme.accent, borderRadius: 999, paddingHorizontal: 16, height: 38, justifyContent: 'center' }}>
                      <Txt v="bodyStrong" color={theme.onAccent} style={{ fontSize: 14 }}>{c.cta}</Txt>
                    </Press>
                  ) : null}
                </Press>
              );
            }}
          />
          {cards.length > 1 ? (
            <Row gap={6} style={{ alignSelf: 'center', marginTop: 10 }}>
              {cards.map((c, i) => (
                <View key={c.key} style={{ width: i === page ? 18 : 6, height: 6, borderRadius: 3, backgroundColor: i === page ? theme.text : theme.faint }} />
              ))}
            </Row>
          ) : null}
        </Animated.View>
      ) : null}
    </Screen>
  );
}
