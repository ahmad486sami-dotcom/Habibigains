// Custom tab bar: sliding pill indicator, center + button that opens a quick-action menu.
import { BottomTabBarProps } from '@react-navigation/bottom-tabs';
import { router, Tabs } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { Modal, Pressable, View } from 'react-native';
import Animated, { FadeIn, FadeInDown, FadeOut, useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useI18n } from '@/i18n/i18n';
import { press, select } from '@/lib/haptics';
import { useTheme } from '@/theme/theme';
import { Icon, IconName } from '@/ui/Icon';
import { Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

const TABS: { name: string; icon: IconName; label: 'tabToday' | 'tabFood' | 'tabProgress' | 'tabTrain' }[] = [
  { name: 'index', icon: 'home', label: 'tabToday' },
  { name: 'food', icon: 'food', label: 'tabFood' },
  { name: 'progress', icon: 'chart', label: 'tabProgress' },
  { name: 'train', icon: 'run', label: 'tabTrain' },
];

function TabBar({ state, navigation }: BottomTabBarProps) {
  const { theme } = useTheme();
  const { t } = useI18n();
  const insets = useSafeAreaInsets();
  const [menu, setMenu] = useState(false);
  const [w, setW] = useState(0);
  const slot = w / 5;
  const idx = state.index;
  const visual = idx >= 2 ? idx + 1 : idx; // skip the center slot
  const x = useSharedValue(0);
  useEffect(() => {
    x.value = withSpring(visual * slot, { damping: 18, stiffness: 180 });
  }, [visual, slot, x]);
  const pill = useAnimatedStyle(() => ({ transform: [{ translateX: x.value }] }));

  const actions: { icon: IconName; label: string; sub: string; go: () => void }[] = [
    { icon: 'camera', label: t('cameraTitle'), sub: t('cameraSub'), go: () => router.push('/camera') },
    { icon: 'fork', label: t('logFood'), sub: t('logFoodSub'), go: () => router.push('/add-food') },
    { icon: 'scale', label: t('weighIn'), sub: t('weighInSub'), go: () => router.push('/weigh-in') },
  ];

  const item = (i: number) => {
    const tab = TABS[i];
    const focused = state.index === i;
    return (
      <Press
        key={tab.name}
        haptic={false}
        scaleTo={0.9}
        onPress={() => {
          select();
          if (!focused) navigation.navigate(state.routes[i].name);
        }}
        style={{ width: slot, alignItems: 'center', justifyContent: 'center', height: 56, gap: 3 }}
      >
        <Icon name={tab.icon} size={22} color={focused ? theme.text : theme.faint} />
        <Txt v="small" color={focused ? theme.text : theme.faint} style={{ fontSize: 10.5 }}>{t(tab.label)}</Txt>
      </Press>
    );
  };

  return (
    <>
      <View
        onLayout={(e) => setW(e.nativeEvent.layout.width)}
        style={{
          position: 'absolute',
          left: 14,
          right: 14,
          bottom: insets.bottom + 8,
          height: 64,
          borderRadius: 32,
          backgroundColor: 'rgba(20,22,25,0.96)',
          borderWidth: 1,
          borderColor: theme.border,
          flexDirection: 'row',
          alignItems: 'center',
          direction: 'ltr',
        }}
      >
        {w > 0 ? (
          <Animated.View style={[{ position: 'absolute', left: 0, width: slot, alignItems: 'center' }, pill]}>
            <View style={{ width: slot - 14, height: 50, borderRadius: 25, backgroundColor: theme.cardHigh }} />
          </Animated.View>
        ) : null}
        {item(0)}
        {item(1)}
        <View style={{ width: slot, alignItems: 'center' }}>
          <Press
            haptic={false}
            scaleTo={0.88}
            onPress={() => {
              press();
              setMenu(true);
            }}
            accessibilityLabel="Quick log"
            style={{ width: 52, height: 52, borderRadius: 26, backgroundColor: theme.accent, alignItems: 'center', justifyContent: 'center' }}
          >
            <Icon name="plus" size={26} color={theme.onAccent} stroke={2.6} />
          </Press>
        </View>
        {item(2)}
        {item(3)}
      </View>

      <Modal visible={menu} transparent animationType="none" onRequestClose={() => setMenu(false)}>
        <Animated.View entering={FadeIn.duration(150)} exiting={FadeOut.duration(150)} style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.7)' }}>
          <Pressable style={{ flex: 1, justifyContent: 'flex-end', padding: 16, paddingBottom: insets.bottom + 96 }} onPress={() => setMenu(false)}>
            <View style={{ gap: 10 }}>
              {actions.map((a, i) => (
                <Animated.View key={a.label} entering={FadeInDown.delay((actions.length - i) * 45).springify().damping(16)}>
                  <Press
                    onPress={() => {
                      setMenu(false);
                      setTimeout(a.go, 120);
                    }}
                    style={{ flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: theme.card, borderRadius: 22, padding: 18 }}
                  >
                    <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: theme.cardHigh, alignItems: 'center', justifyContent: 'center' }}>
                      <Icon name={a.icon} color={theme.accent} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Txt v="h3">{a.label}</Txt>
                      <Txt v="small" muted>{a.sub}</Txt>
                    </View>
                  </Press>
                </Animated.View>
              ))}
            </View>
          </Pressable>
        </Animated.View>
      </Modal>
    </>
  );
}

export default function TabsLayout() {
  const { theme } = useTheme();
  return (
    <Tabs tabBar={(p) => <TabBar {...p} />} screenOptions={{ headerShown: false, sceneStyle: { backgroundColor: theme.bg } }}>
      {TABS.map((tab) => (
        <Tabs.Screen key={tab.name} name={tab.name} />
      ))}
    </Tabs>
  );
}
