# Habibi Gains: build and install (full version)

The app is fully connected: real accounts, real food database, GPS runs.
Backend: Supabase project **habibi-gains** (already set up: database, food data, sign-up and delete-account functions).

## Build the .ipa (free, on GitHub)
1. In your GitHub repo, upload this zip (keep the old one or delete it; the build always uses the newest zip).
2. Make sure `.github/workflows/ipa.yml` is the latest version.
3. Actions → **Build IPA from zip** → **Run workflow**. Takes about 20–25 minutes.
4. Open the green run → **Artifacts** → download **HabibiGains-ipa** → unzip → `HabibiGains.ipa`.
5. Sign and install with ESign. The app is called **Habibi Gains**.

If the run is red: open it, tap **Build**, screenshot the **REAL ERRORS** box.

## First launch
1. Create your account (name, email, password). You're in instantly.
2. Answer the plan questions (about 1 minute).
3. Allow location "Always" when you start your first run, so it records with the screen locked.

## What is not in this build (can be added later)
- Sign in with Apple / Google, Apple Health steps, paid Premium: need an Apple Developer account.
- AI food camera: needs an Anthropic API key (code in `supabase/functions/food-photo`).

## Where to see data
supabase.com → project **habibi-gains** → Table Editor (profiles, food_logs, runs, waitlist, ...).
