// Turn a recipe into a clean one-page PDF and open the share sheet (WhatsApp, Mail, AirDrop, Files...).
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import type { Food, Ingredient } from './data';

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);
const n0 = (v: number | null | undefined) => (v === null || v === undefined ? '–' : Math.round(Number(v)).toLocaleString('en-US'));
const n1 = (v: number | null | undefined) => (v === null || v === undefined ? '–' : (Math.round(Number(v) * 10) / 10).toString());

const LOGO = `<svg width="64" height="36" viewBox="0 0 400 220"><g fill="#0A0B0D"><rect x="20" y="62" width="38" height="76" rx="19"/><rect x="70" y="30" width="46" height="140" rx="23"/><rect x="284" y="30" width="46" height="140" rx="23"/><rect x="342" y="62" width="38" height="76" rx="19"/></g><path d="M116 92 Q200 152 284 92" fill="none" stroke="#0A0B0D" stroke-width="34" stroke-linecap="round"/></svg>`;

export function recipeHtml(recipe: Food, author?: string | null) {
  const ing: Ingredient[] = recipe.ingredients ?? [];
  const servings = recipe.recipe_servings ?? 1;
  const totalG = ing.reduce((s, i) => s + i.grams, 0);
  const kcal = recipe.kcal;
  const pct = (g: number, per: number) => (kcal > 0 ? Math.round(((g * per) / kcal) * 100) : 0);
  const rows = ing
    .map(
      (i) => `<tr><td>${esc(i.name)}</td><td class="r">${esc(i.serving_label === 'g' ? `${n0(i.quantity)} g` : i.quantity === 1 ? i.serving_label : `${n1(i.quantity)} × ${i.serving_label}`)}</td><td class="r">${n0(i.grams)} g</td><td class="r">${n0(i.kcal)}</td></tr>`,
    )
    .join('');
  const facts: [string, string][] = [
    ['Calories', `${n0(recipe.kcal)} kcal`],
    ['Protein', `${n1(recipe.protein_g)} g`],
    ['Carbs', `${n1(recipe.carbs_g)} g`],
    ['Fat', `${n1(recipe.fat_g)} g`],
    ['Fiber', `${n1(recipe.fiber_g)} g`],
    ['Sugar', `${n1(recipe.sugar_g)} g`],
    ['Saturated fat', `${n1(recipe.sat_fat_g)} g`],
    ['Sodium', `${n0(recipe.sodium_mg)} mg`],
    ['Cholesterol', `${n0(recipe.cholesterol_mg)} mg`],
    ['Potassium', `${n0(recipe.potassium_mg)} mg`],
  ];
  return `<!doctype html><html><head><meta charset="utf-8"><style>
  @page { margin: 36px; }
  body { padding: 0; font-family: -apple-system, Helvetica, Arial, sans-serif; color: #0A0B0D; margin: 0; }
  .top { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #0A0B0D; padding-bottom: 14px; }
  .brand { font-weight: 800; letter-spacing: -0.5px; font-size: 15px; display: flex; align-items: center; gap: 10px; }
  h1 { font-size: 34px; letter-spacing: -1px; margin: 26px 0 6px; }
  .sub { color: #5E6268; font-size: 14px; }
  .big { display: flex; gap: 14px; margin: 22px 0; }
  .tile { flex: 1; background: #F2F2EF; border-radius: 14px; padding: 14px; }
  .tile b { display: block; font-size: 26px; letter-spacing: -0.5px; }
  .tile span { color: #5E6268; font-size: 12px; text-transform: uppercase; letter-spacing: 1px; }
  h2 { font-size: 16px; text-transform: uppercase; letter-spacing: 1.5px; margin: 26px 0 8px; }
  table { width: 100%; border-collapse: collapse; font-size: 14px; }
  td { padding: 9px 0; border-bottom: 1px solid #E2E2DE; }
  .r { text-align: right; white-space: nowrap; padding-left: 12px; }
  .facts td:first-child { color: #3A3D42; }
  .foot { margin-top: 30px; color: #8A8F95; font-size: 11px; display: flex; justify-content: space-between; }
  </style></head><body>
  <div class="top"><div class="brand">${LOGO} HABIBI GAINS</div><div class="sub">Recipe card</div></div>
  <h1>${esc(recipe.name_en)}</h1>
  <div class="sub">Makes ${n1(servings)} serving${servings === 1 ? '' : 's'} · about ${n0(totalG / Math.max(1, servings))} g per serving${author ? ` · by ${esc(author)}` : ''}</div>
  <div class="big">
    <div class="tile"><span>Per serving</span><b>${n0(kcal)} kcal</b></div>
    <div class="tile"><span>Protein</span><b>${n1(recipe.protein_g)} g</b><span>${pct(recipe.protein_g, 4)}% of kcal</span></div>
    <div class="tile"><span>Carbs</span><b>${n1(recipe.carbs_g)} g</b><span>${pct(recipe.carbs_g, 4)}% of kcal</span></div>
    <div class="tile"><span>Fat</span><b>${n1(recipe.fat_g)} g</b><span>${pct(recipe.fat_g, 9)}% of kcal</span></div>
  </div>
  <h2>Ingredients (whole recipe)</h2>
  <table><tr><td class="sub">Ingredient</td><td class="r sub">Amount</td><td class="r sub">Weight</td><td class="r sub">kcal</td></tr>${rows}</table>
  <h2>Nutrition per serving</h2>
  <table class="facts">${facts.map(([k, v]) => `<tr><td>${k}</td><td class="r">${v}</td></tr>`).join('')}</table>
  <div class="foot"><span>Values calculated from USDA FoodData Central and the Habibi Gains food database.</span><span>habibigains.store</span></div>
  </body></html>`;
}

export async function shareRecipePdf(recipe: Food, author?: string | null) {
  const { uri } = await Print.printToFileAsync({ html: recipeHtml(recipe, author), width: 595, height: 842 });
  await Sharing.shareAsync(uri, { mimeType: 'application/pdf', UTI: 'com.adobe.pdf', dialogTitle: recipe.name_en });
}
