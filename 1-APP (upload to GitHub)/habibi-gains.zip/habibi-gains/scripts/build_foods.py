import csv, json, re
from clean import clean
from uae_foods import UAE
def num(x):
    try: return round(float(x), 2)
    except: return None
weights = {}
for ndb, amt, desc, g in csv.reader(open('/var/tmp/weights.tsv'), delimiter='\t'):
    a = float(amt); lab = f"{a:g} {desc}".strip()
    weights.setdefault(ndb, []).append({'label': lab, 'g': round(float(g), 1)})
groups = {'0100':'dairy','0200':'spices','0400':'fats','0500':'poultry','0600':'soups','0700':'sausages','0800':'cereals','0900':'fruits','1000':'pork','1100':'vegetables','1200':'nuts','1300':'beef','1400':'beverages','1500':'fish','1600':'legumes','1700':'lamb','1800':'baked','1900':'sweets','2000':'grains','2100':'fastfood','2200':'meals','2500':'snacks','3600':'restaurant'}
out = []
for r in csv.reader(open('/var/tmp/foods.tsv'), delimiter='\t'):
    ndb, grp, desc, com, kcal, p, c, f, fib, sug, na, sat, chol, k = r
    if num(kcal) is None: continue
    sv = weights.get(ndb, [])
    out.append({'usda_id': ndb, 'source': 'usda', 'food_group': groups.get(grp), 'name_en': clean(desc), 'search_text': (desc + ' ' + com).lower(),
      'base_g': 100, 'kcal': num(kcal), 'protein_g': num(p) or 0, 'carbs_g': num(c) or 0, 'fat_g': num(f) or 0, 'fiber_g': num(fib), 'sugar_g': num(sug),
      'sodium_mg': num(na), 'sat_fat_g': num(sat), 'cholesterol_mg': num(chol), 'potassium_mg': num(k), 'servings': sv})
bad = []
for (en, ar, lab, g, kcal, p, c, f, fib, sug, na) in UAE:
    est = 4*p + 4*c + 9*f
    if abs(est - kcal) / kcal > 0.15: bad.append((en, kcal, round(est)))
    k = 100 / g
    out.append({'source': 'uae', 'food_group': 'uae', 'name_en': en, 'name_ar': ar, 'search_text': en.lower(), 'is_local': True, 'base_g': 100,
      'kcal': round(kcal*k, 2), 'protein_g': round(p*k, 2), 'carbs_g': round(c*k, 2), 'fat_g': round(f*k, 2), 'fiber_g': round(fib*k, 2), 'sugar_g': round(sug*k, 2), 'sodium_mg': round(na*k, 1),
      'sat_fat_g': None, 'cholesterol_mg': None, 'potassium_mg': None, 'servings': [{'label': lab, 'g': g}]})
print('foods', len(out), 'uae', len(UAE)); print('kcal mismatch >15%:', bad)
json.dump(out, open('foods.json', 'w'), ensure_ascii=False)
names = [o['name_en'] for o in out]; import collections
print('dup names', sum(1 for v in collections.Counter(names).values() if v > 1))
