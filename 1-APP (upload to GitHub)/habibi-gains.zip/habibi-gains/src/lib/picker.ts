// Hand-off between the food search and the recipe builder:
// the search screen puts the chosen ingredient here, the recipe screen picks it up when it regains focus.
import type { Ingredient } from './data';

let pending: Ingredient | null = null;

export function putIngredient(i: Ingredient) {
  pending = i;
}

export function takeIngredient() {
  const i = pending;
  pending = null;
  return i;
}
