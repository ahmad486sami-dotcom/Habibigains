import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { ScrollView, View } from 'react-native';
import QRCode from 'react-native-qrcode-svg';
import Animated, { ZoomIn } from 'react-native-reanimated';
import { useI18n } from '@/i18n/i18n';
import { EventRow, fetchEvents } from '@/lib/data';
import { useSession } from '@/lib/session';
import { useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Card, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function EventDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { t, lang } = useI18n();
  const { theme } = useTheme();
  const { session, profile } = useSession();
  const [e, setE] = useState<EventRow | null>(null);
  const [showCode, setShowCode] = useState(false);

  useEffect(() => {
    fetchEvents().then((all) => setE(all.find((x) => x.id === id) ?? null)).catch(() => {});
  }, [id]);

  if (!e) return <View style={{ flex: 1, backgroundColor: theme.bg }} />;
  const isHost = e.host_id === session?.user.id || profile?.role === 'admin';

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ padding: 20, gap: 16, paddingBottom: 60 }}>
      <Row style={{ justifyContent: 'flex-end' }}>
        <Press onPress={() => router.back()} accessibilityLabel={t('close')} style={{ padding: 6 }}>
          <Icon name="close" />
        </Press>
      </Row>
      <Txt v="label" muted>
        {new Date(e.starts_at).toLocaleString(lang === 'ar' ? 'ar-AE' : 'en-GB', { weekday: 'long', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })}
      </Txt>
      <Txt v="hero">{e.title}</Txt>
      {e.women_only ? (
        <View style={{ alignSelf: 'flex-start', backgroundColor: theme.accentSoft, borderRadius: 999, paddingHorizontal: 12, paddingVertical: 5 }}>
          <Txt v="label" color={theme.accent}>{t('womenOnly')}</Txt>
        </View>
      ) : null}
      <Row gap={8}>
        <Icon name="pin" size={18} color={theme.muted} />
        <Txt muted>{`${e.location_name} · ${e.emirate}`}</Txt>
      </Row>
      {e.description ? <Txt>{e.description}</Txt> : null}

      <Card>
        <Row gap={14}>
          <View style={{ width: 54, height: 54, borderRadius: 27, borderWidth: 3, borderColor: theme.accent, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="medal" color={theme.accent} />
          </View>
          <View style={{ flex: 1 }}>
            <Txt v="h3">{e.badge_name}</Txt>
            <Txt v="small" muted>{`+${e.xp} XP · ${t('going', { n: e.going })}`}</Txt>
          </View>
        </Row>
      </Card>

      <Button title={t('checkIn')} onPress={() => router.replace('/camera')} />

      {isHost && e.checkin_code ? (
        <>
          <Button title={t('showCode')} kind="secondary" onPress={() => setShowCode(!showCode)} />
          {showCode ? (
            <Animated.View entering={ZoomIn.springify()} style={{ alignSelf: 'center', backgroundColor: '#fff', padding: 22, borderRadius: 28 }}>
              <QRCode value={`habibigains://checkin/${e.checkin_code}`} size={240} backgroundColor="#fff" color="#000" />
            </Animated.View>
          ) : null}
        </>
      ) : null}
    </ScrollView>
  );
}
