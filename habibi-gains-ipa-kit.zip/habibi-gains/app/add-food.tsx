import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, View } from 'react-native';
import Animated, { FadeIn, FadeInDown, SlideInDown } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useI18n } from '@/i18n/i18n';
import { addFoodLog, awardBadge, Food, searchFoods } from '@/lib/data';
import { select, success } from '@/lib/haptics';
import { useSession } from '@/lib/session';
import { useTheme } from '@/theme/theme';
import { useCelebrate } from '@/ui/Celebrate';
import { Icon } from '@/ui/Icon';
import { Chips, Field, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

type Meal = 'breakfast' | 'lunch' | 'dinner' | 'snack' | 'suhoor' | 'iftar';

function defaultMeal(ramadan: boolean): Meal {
  const h = new Date().getHours();
  if (ramadan) return h >= 17 || h < 2 ? 'iftar' : 'suhoor';
  if (h < 11) return 'breakfast';
  if (h < 16) return 'lunch';
  if (h < 21) return 'dinner';
  return 'snack';
}

export default function AddFood() {
  const { t, lang } = useI18n();
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const celebrate = useCelebrate();
  const { profile, session } = useSession();
  const params = useLocalSearchParams<{ meal?: Meal; quick?: string; foodJson?: string }>();
  const ramadan = !!profile?.ramadan_mode;

  const [q, setQ] = useState('');
  const [results, setResults] = useState<Food[]>([]);
  const [selected, setSelected] = useState<Food | null>(params.foodJson ? JSON.parse(params.foodJson) : null);
  const [servings, setServings] = useState(1);
  const [meal, setMeal] = useState<Meal>(params.meal ?? defaultMeal(ramadan));
  const [quick, setQuick] = useState(params.quick === '1');
  const [custom, setCustom] = useState({ name: '', kcal: '', protein: '', carbs: '', fat: '' });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const h = setTimeout(() => searchFoods(q).then(setResults).catch(() => setResults([])), 220);
    return () => clearTimeout(h);
  }, [q]);

  const mealOptions = (ramadan ? ['iftar', 'dinner', 'snack', 'suhoor'] : ['breakfast', 'lunch', 'dinner', 'snack']).map((m) => ({
    value: m as Meal,
    label: t(m as Meal),
  }));

  const save = async () => {
    if (!session) return;
    setSaving(true);
    try {
      if (quick) {
        await addFoodLog(session.user.id, {
          name: custom.name.trim() || t('quickAdd'),
          meal,
          servings: 1,
          kcal: Math.round(Number(custom.kcal) || 0),
          protein_g: Number(custom.protein) || 0,
          carbs_g: Number(custom.carbs) || 0,
          fat_g: Number(custom.fat) || 0,
          source: 'quick',
        });
      } else if (selected) {
        await addFoodLog(session.user.id, {
          food_id: selected.id || null,
          name: lang === 'ar' && selected.name_ar ? selected.name_ar : selected.name_en,
          meal,
          servings,
          kcal: Math.round(selected.kcal * servings),
          protein_g: Math.round(selected.protein_g * servings * 10) / 10,
          carbs_g: Math.round(selected.carbs_g * servings * 10) / 10,
          fat_g: Math.round(selected.fat_g * servings * 10) / 10,
          source: params.foodJson ? 'barcode' : 'search',
        });
      }
      success();
      if (await awardBadge('first-log')) celebrate({ title: lang === 'ar' ? 'أول لقمة' : 'First Bite', icon: 'fork' });
      router.back();
    } finally {
      setSaving(false);
    }
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: theme.bg }}>
      <View style={{ paddingTop: 16, paddingHorizontal: 20, gap: 14, flex: 1 }}>
        <Row style={{ justifyContent: 'space-between' }}>
          <Txt v="h2">{quick ? t('quickAdd') : t('logFood')}</Txt>
          <Press onPress={() => router.back()} accessibilityLabel={t('close')} style={{ padding: 6 }}>
            <Icon name="close" />
          </Press>
        </Row>
        <Chips value={meal} onChange={setMeal} options={mealOptions} />

        {quick ? (
          <Animated.View entering={FadeIn} style={{ gap: 12 }}>
            <Field label={t('name')} value={custom.name} onChangeText={(v) => setCustom({ ...custom, name: v })} autoFocus />
            <Row gap={10}>
              <View style={{ flex: 1 }}><Field label={t('calories')} keyboardType="number-pad" value={custom.kcal} onChangeText={(v) => setCustom({ ...custom, kcal: v })} /></View>
              <View style={{ flex: 1 }}><Field label={`${t('protein')} (${t('g')})`} keyboardType="decimal-pad" value={custom.protein} onChangeText={(v) => setCustom({ ...custom, protein: v })} /></View>
            </Row>
            <Row gap={10}>
              <View style={{ flex: 1 }}><Field label={`${t('carbs')} (${t('g')})`} keyboardType="decimal-pad" value={custom.carbs} onChangeText={(v) => setCustom({ ...custom, carbs: v })} /></View>
              <View style={{ flex: 1 }}><Field label={`${t('fat')} (${t('g')})`} keyboardType="decimal-pad" value={custom.fat} onChangeText={(v) => setCustom({ ...custom, fat: v })} /></View>
            </Row>
          </Animated.View>
        ) : (
          <>
            <Field value={q} onChangeText={setQ} placeholder={t('searchFood')} autoFocus={!selected} returnKeyType="search" />
            <FlatList
              data={results}
              keyExtractor={(f) => f.id || f.name_en}
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={{ gap: 8, paddingBottom: 220 }}
              ListEmptyComponent={
                q.length > 1 ? (
                  <Press onPress={() => { setQuick(true); setCustom({ ...custom, name: q }); }} style={{ padding: 16 }}>
                    <Txt muted>{t('notFound')}</Txt>
                  </Press>
                ) : null
              }
              renderItem={({ item, index }) => (
                <Animated.View entering={FadeInDown.delay(Math.min(index, 8) * 30)}>
                  <Press
                    haptic={false}
                    onPress={() => {
                      select();
                      setSelected(item);
                      setServings(1);
                    }}
                    scaleTo={0.98}
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      padding: 16,
                      borderRadius: 18,
                      backgroundColor: selected?.id === item.id ? theme.cardHigh : theme.card,
                    }}
                  >
                    <View style={{ flex: 1, gap: 2 }}>
                      <Row gap={6}>
                        <Txt v="bodyStrong" numberOfLines={1} style={{ flexShrink: 1 }}>{lang === 'ar' && item.name_ar ? item.name_ar : item.name_en}</Txt>
                        {item.is_local ? <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: theme.accent }} /> : null}
                      </Row>
                      <Txt v="small" faint>{`${item.serving} · ${item.protein_g}${t('g')} ${t('protein').toLowerCase()}`}</Txt>
                    </View>
                    <Txt v="bodyStrong">{item.kcal}</Txt>
                  </Press>
                </Animated.View>
              )}
            />
          </>
        )}
      </View>

      {(selected && !quick) || quick ? (
        <Animated.View
          entering={SlideInDown.springify().damping(18)}
          style={{ position: 'absolute', left: 0, right: 0, bottom: 0, backgroundColor: theme.surface, borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 20, paddingBottom: insets.bottom + 16, gap: 14, borderTopWidth: 1, borderColor: theme.border }}
        >
          {selected && !quick ? (
            <>
              <Row style={{ justifyContent: 'space-between' }}>
                <View style={{ flex: 1 }}>
                  <Txt v="h3" numberOfLines={1}>{lang === 'ar' && selected.name_ar ? selected.name_ar : selected.name_en}</Txt>
                  <Txt v="small" muted>{`${Math.round(selected.kcal * servings)} ${t('kcal')} · ${Math.round(selected.protein_g * servings)}${t('g')} ${t('protein').toLowerCase()}`}</Txt>
                </View>
                <Row gap={8}>
                  <Press onPress={() => setServings(Math.max(0.5, servings - 0.5))} style={stepper(theme)}><Txt v="h3">−</Txt></Press>
                  <Txt v="h3" style={{ minWidth: 36, textAlign: 'center' }}>{servings}</Txt>
                  <Press onPress={() => setServings(Math.min(10, servings + 0.5))} style={stepper(theme)}><Txt v="h3">+</Txt></Press>
                </Row>
              </Row>
            </>
          ) : null}
          <Button title={t('add')} loading={saving} disabled={quick && !custom.kcal} onPress={save} />
        </Animated.View>
      ) : null}
    </KeyboardAvoidingView>
  );
}

const stepper = (theme: { cardHigh: string }) => ({
  width: 40,
  height: 40,
  borderRadius: 20,
  backgroundColor: theme.cardHigh,
  alignItems: 'center' as const,
  justifyContent: 'center' as const,
});
