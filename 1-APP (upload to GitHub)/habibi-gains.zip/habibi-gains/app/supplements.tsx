// What actually works: an evidence-graded supplement guide.
import { router } from 'expo-router';
import React, { useState } from 'react';
import { View } from 'react-native';
import Animated, { FadeIn, FadeInDown, LinearTransition } from 'react-native-reanimated';
import { useI18n } from '@/i18n/i18n';
import { select } from '@/lib/haptics';
import { Supplement, SUPPLEMENTS, Tier, TIERS } from '@/lib/supplements';
import { useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Chips, Row, Screen } from '@/ui/Layout';
import { Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

const TIER_ICON: Record<Tier, 'check' | 'star' | 'info' | 'close'> = { works: 'check', situational: 'star', mixed: 'info', skip: 'close' };

export default function Supplements() {
  const { lang } = useI18n();
  const { theme } = useTheme();
  const L = (o: { en: string; ar: string }) => (lang === 'ar' ? o.ar : o.en);
  const [tier, setTier] = useState<Tier | 'all'>('all');
  const [open, setOpen] = useState<string | null>(null);

  const tiers = TIERS.filter((t) => tier === 'all' || t.id === tier);

  const Line = ({ label, body }: { label: string; body: string }) => (
    <View style={{ gap: 2 }}>
      <Txt v="label" muted>{label}</Txt>
      <Txt>{body}</Txt>
    </View>
  );

  const card = (s: Supplement, i: number) => {
    const isOpen = open === s.id;
    const tone = s.tier === 'skip' ? theme.danger : s.tier === 'works' ? theme.accent : theme.muted;
    return (
      <Animated.View key={s.id} entering={FadeInDown.delay(Math.min(i, 6) * 40)} layout={LinearTransition.springify().damping(18)}>
        <Press
          haptic={false}
          scaleTo={0.99}
          onPress={() => {
            select();
            setOpen(isOpen ? null : s.id);
          }}
          style={{ backgroundColor: theme.card, borderRadius: 22, padding: 16, gap: 10 }}
        >
          <Row style={{ justifyContent: 'space-between' }}>
            <Row gap={10} style={{ flex: 1 }}>
              <View style={{ width: 30, height: 30, borderRadius: 15, backgroundColor: theme.cardHigh, alignItems: 'center', justifyContent: 'center' }}>
                <Icon name={TIER_ICON[s.tier]} size={16} color={tone} stroke={2.4} />
              </View>
              <Txt v="h3" style={{ flex: 1 }}>{L(s.name)}</Txt>
            </Row>
            <View style={{ transform: [{ rotate: isOpen ? '90deg' : '0deg' }] }}>
              <Icon name="chevron" size={18} color={theme.faint} />
            </View>
          </Row>
          <Txt muted numberOfLines={isOpen ? undefined : 2}>{L(s.what)}</Txt>
          {isOpen ? (
            <Animated.View entering={FadeIn.duration(220)} style={{ gap: 12, marginTop: 2 }}>
              <Line label={lang === 'ar' ? 'الجرعة' : 'Dose'} body={L(s.dose)} />
              <Line label={lang === 'ar' ? 'متى' : 'When'} body={L(s.when)} />
              <Line label={lang === 'ar' ? 'لمن' : 'Who it is for'} body={L(s.who)} />
              {s.caution ? (
                <View style={{ backgroundColor: theme.cardHigh, borderRadius: 14, padding: 12, gap: 4 }}>
                  <Txt v="label" color={theme.danger}>{lang === 'ar' ? 'انتبه' : 'Heads up'}</Txt>
                  <Txt v="small">{L(s.caution)}</Txt>
                </View>
              ) : null}
              <Txt v="small" faint>{s.source}</Txt>
            </Animated.View>
          ) : null}
        </Press>
      </Animated.View>
    );
  };

  return (
    <Screen bottomInset={60}>
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="h1" style={{ flex: 1 }}>{lang === 'ar' ? 'المكملات: وش يشتغل فعلاً' : 'Supplements: what actually works'}</Txt>
        <Press onPress={() => router.back()} style={{ padding: 6 }}>
          <Icon name="close" />
        </Press>
      </Row>
      <Txt muted>
        {lang === 'ar'
          ? 'مبني على بيانات الجمعية الدولية لتغذية الرياضيين والمراجعات العلمية. الأكل والنوم والتمرين أهم من أي مكمل.'
          : 'Based on ISSN position stands and meta-analyses. Food, sleep and training matter far more than any tub. Not medical advice: check with your doctor if you take medication, are pregnant or have a condition.'}
      </Txt>
      <Chips
        value={tier}
        onChange={setTier}
        options={[{ value: 'all' as const, label: lang === 'ar' ? 'الكل' : 'All' }, ...TIERS.map((t) => ({ value: t.id, label: lang === 'ar' ? t.ar : t.en }))]}
      />
      {tiers.map((t) => (
        <View key={t.id} style={{ gap: 10 }}>
          <View style={{ marginTop: 8, gap: 2 }}>
            <Txt v="h2">{lang === 'ar' ? t.ar : t.en}</Txt>
            <Txt v="small" muted>{lang === 'ar' ? t.blurbAr : t.blurbEn}</Txt>
          </View>
          {SUPPLEMENTS.filter((s) => s.tier === t.id).map(card)}
        </View>
      ))}
    </Screen>
  );
}
