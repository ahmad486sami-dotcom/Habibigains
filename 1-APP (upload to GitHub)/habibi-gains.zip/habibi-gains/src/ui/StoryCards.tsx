// 9:16 story cards for sharing: your day of eating, and a run.
import React, { forwardRef } from 'react';
import { View } from 'react-native';
import { Logo, Ring } from './Graphics';
import { RouteShape } from './RouteShape';
import { Txt } from './Txt';

const BG = '#000';
const FG = '#F5F5F2';
const SUB = '#9BA1A6';

export type DayStoryData = {
  dateLabel: string;
  kcal: number;
  target: number;
  protein: number;
  carbs: number;
  fat: number;
  proteinTarget: number;
  meals: { label: string; kcal: number }[];
  streak: number;
  accent: string;
};

export const DayStory = forwardRef<View, { d: DayStoryData; width: number }>(({ d, width }, ref) => {
  const height = (width * 16) / 9;
  const u = width / 100;
  const stat = (label: string, value: string) => (
    <View style={{ gap: 2 }}>
      <Txt v="h2" color={FG} style={{ fontSize: u * 7.5, lineHeight: u * 8.5 }}>{value}</Txt>
      <Txt v="small" color={SUB} style={{ fontSize: u * 3.4 }}>{label}</Txt>
    </View>
  );
  return (
    <View ref={ref} collapsable={false} style={{ width, height, backgroundColor: BG, padding: u * 8, justifyContent: 'space-between', borderRadius: 24, overflow: 'hidden' }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Logo width={u * 20} color={FG} />
        <Txt v="label" color={SUB} style={{ fontSize: u * 3 }}>{d.dateLabel}</Txt>
      </View>
      <View style={{ alignItems: 'center', gap: u * 4 }}>
        <Ring size={u * 62} stroke={u * 4.4} progress={d.target ? d.kcal / d.target : 0} color={d.accent}>
          <Txt v="hero" color={FG} style={{ fontSize: u * 15, lineHeight: u * 16 }}>{d.kcal.toLocaleString('en-US')}</Txt>
          <Txt v="small" color={SUB} style={{ fontSize: u * 3.6 }}>{`of ${d.target.toLocaleString('en-US')} kcal`}</Txt>
        </Ring>
        <View style={{ flexDirection: 'row', width: '100%', justifyContent: 'space-between' }}>
          {stat('Protein', `${Math.round(d.protein)}g`)}
          {stat('Carbs', `${Math.round(d.carbs)}g`)}
          {stat('Fat', `${Math.round(d.fat)}g`)}
        </View>
      </View>
      <View style={{ gap: u * 2.4 }}>
        {d.meals.filter((m) => m.kcal > 0).map((m) => (
          <View key={m.label} style={{ flexDirection: 'row', justifyContent: 'space-between', borderBottomWidth: 1, borderColor: '#24272C', paddingBottom: u * 1.6 }}>
            <Txt color={SUB} style={{ fontSize: u * 3.8 }}>{m.label}</Txt>
            <Txt v="bodyStrong" color={FG} style={{ fontSize: u * 3.8 }}>{`${m.kcal} kcal`}</Txt>
          </View>
        ))}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: u * 2 }}>
          <Txt v="bodyStrong" color={SUB} style={{ fontSize: u * 3.4 }}>{d.streak > 1 ? `${d.streak}-day streak` : 'Day logged'}</Txt>
          <Txt v="bodyStrong" color={SUB} style={{ fontSize: u * 3.4 }}>habibigains.store</Txt>
        </View>
      </View>
    </View>
  );
});
DayStory.displayName = 'DayStory';

export type RunStoryData = {
  title: string;
  dateLabel: string;
  km: string;
  time: string;
  pace: string;
  climb: string | null;
  kcal: number;
  route: [number, number][];
  accent: string;
  transparent?: boolean;
};

export const RunStory = forwardRef<View, { d: RunStoryData; width: number }>(({ d, width }, ref) => {
  const height = (width * 16) / 9;
  const u = width / 100;
  const stat = (label: string, value: string) => (
    <View style={{ gap: 2, minWidth: u * 26 }}>
      <Txt v="small" color={SUB} style={{ fontSize: u * 3.2 }}>{label}</Txt>
      <Txt v="h2" color={FG} style={{ fontSize: u * 7.6, lineHeight: u * 8.6 }}>{value}</Txt>
    </View>
  );
  return (
    <View
      ref={ref}
      collapsable={false}
      style={{ width, height, backgroundColor: d.transparent ? 'transparent' : BG, padding: u * 8, justifyContent: 'space-between', borderRadius: d.transparent ? 0 : 24, overflow: 'hidden' }}
    >
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Logo width={u * 20} color={FG} />
        <Txt v="label" color={SUB} style={{ fontSize: u * 3 }}>{d.dateLabel}</Txt>
      </View>
      <View style={{ alignItems: 'center' }}>
        {d.route.length > 1 ? <RouteShape route={d.route} width={u * 84} height={u * 84} color={d.accent} stroke={u * 1.4} dots /> : <View style={{ height: u * 84 }} />}
      </View>
      <View style={{ gap: u * 4 }}>
        <View style={{ gap: u * 1 }}>
          <Txt v="label" color={SUB} style={{ fontSize: u * 3.2 }}>{d.title}</Txt>
          <Txt v="hero" color={FG} style={{ fontSize: u * 20, lineHeight: u * 21 }}>{`${d.km} km`}</Txt>
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          {stat('Time', d.time)}
          {stat('Pace /km', d.pace)}
          {stat(d.climb ? 'Climb' : 'kcal', d.climb ?? String(d.kcal))}
        </View>
        <Txt v="bodyStrong" color={SUB} style={{ fontSize: u * 3.4 }}>habibigains.store</Txt>
      </View>
    </View>
  );
});
RunStory.displayName = 'RunStory';
