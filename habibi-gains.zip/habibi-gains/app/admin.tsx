// Admin: approve scanned and user-made foods before they go public, and make other admins.
// A scan or a created food is saved to its owner instantly; everyone else sees it only after approval.
import { router, useFocusEffect } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { Alert, ScrollView, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { Food, foodName } from '@/lib/data';
import { success, warn } from '@/lib/haptics';
import { useSession } from '@/lib/session';
import { supabase } from '@/lib/supabase';
import { useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Card, Chips, Field, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

type Tab = 'queue' | 'ramadan' | 'admins';
type Period = { id: string; starts_on: string; ends_on: string };

export default function Admin() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { profile } = useSession();
  const [tab, setTab] = useState<Tab>('queue');
  const [queue, setQueue] = useState<Food[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [userId, setUserId] = useState('');
  const [periods, setPeriods] = useState<Period[]>([]);
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const loadPeriods = useCallback(() => {
    supabase.from('ramadan_periods').select('id,starts_on,ends_on').order('starts_on', { ascending: false }).then(({ data }) => setPeriods((data ?? []) as Period[]));
  }, []);
  useFocusEffect(useCallback(() => { loadPeriods(); }, [loadPeriods]));
  const validDate = (d: string) => /^\d{4}-\d{2}-\d{2}$/.test(d.trim());
  const addPeriod = async () => {
    if (!validDate(start) || !validDate(end) || end < start) {
      Alert.alert(L('Check the dates', 'تحقق من التواريخ'), L('Use YYYY-MM-DD, and the end must be after the start.', 'استخدم صيغة YYYY-MM-DD.'));
      return;
    }
    const { error } = await supabase.from('ramadan_periods').insert({ starts_on: start.trim(), ends_on: end.trim() });
    if (error) { warn(); Alert.alert(L('Not saved', 'لم يُحفظ'), error.message); return; }
    success(); setStart(''); setEnd(''); loadPeriods();
  };
  const removePeriod = async (id: string) => {
    await supabase.from('ramadan_periods').delete().eq('id', id);
    loadPeriods();
  };

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('foods')
      .select('*')
      .in('source', ['off', 'user'])
      .eq('review_status', 'pending')
      .order('created_at', { ascending: false })
      .limit(100);
    setErr(error ? error.message : null);
    setQueue((data ?? []) as Food[]);
    setLoading(false);
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  if (!profile || profile.role !== 'admin') return null;

  const decide = async (f: Food, approve: boolean) => {
    setQueue((q) => q.filter((x) => x.id !== f.id));
    const { error } = await supabase.rpc('review_food', { food_id: f.id, approve });
    if (error) {
      warn();
      Alert.alert(L('Could not save', 'لم يتم الحفظ'), error.message);
      load();
    } else success();
  };

  const makeAdmin = () =>
    Alert.alert(
      L('Make admin?', 'تعيين كمسؤول؟'),
      L('Admin role changes are done in Supabase (SQL Editor) for safety. Copy this user ID and ask Claude for the exact line.', 'تغيير الأدوار يتم من Supabase لأمان أكثر.'),
    );

  const per = (f: Food) => `${Math.round(Number(f.kcal))} kcal · P ${Math.round(Number(f.protein_g))} · C ${Math.round(Number(f.carbs_g))} · F ${Math.round(Number(f.fat_g))} ${L(`per ${f.base_g} g`, `لكل ${f.base_g} جم`)}`;

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ padding: 20, gap: 14, paddingBottom: 60 }}>
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="h1">{L('Admin', 'الإدارة')}</Txt>
        <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
      </Row>
      <Chips value={tab} onChange={setTab} options={[{ value: 'queue', label: L(`Approve foods (${queue.length})`, `اعتماد الأكل (${queue.length})`) }, { value: 'ramadan', label: L('Ramadan dates', 'مواعيد رمضان') }, { value: 'admins', label: L('Admins', 'المسؤولون') }]} />

      {tab === 'queue' ? (
        <>
          <Txt v="small" muted>{L('Scanned products and foods people created. Approve to make them public for everyone, or reject to keep them private to the person who added them.', 'المنتجات الممسوحة والأكلات اللي أضافها المستخدمون. اعتمدها لتصير للجميع، أو ارفضها لتبقى خاصة بصاحبها.')}</Txt>
          {err ? <Txt v="small" color={theme.danger}>{L('The approvals database update has not been run yet. Run the SQL Claude gave you, then reopen this screen.', 'لم يتم تحديث قاعدة البيانات بعد.')}</Txt> : null}
          {!loading && !queue.length && !err ? <Txt muted>{L('Nothing waiting. All caught up.', 'لا يوجد شي بانتظار الاعتماد.')}</Txt> : null}
          {queue.map((f, i) => (
            <Card key={f.id} index={i}>
              <View style={{ gap: 2 }}>
                <Txt v="bodyStrong">{foodName(f, lang)}</Txt>
                <Txt v="small" faint>{[f.brand, f.source === 'off' ? L('Barcode scan', 'مسح باركود') : L('Created by a user', 'أضافه مستخدم'), f.barcode].filter(Boolean).join(' · ')}</Txt>
                <Txt v="small" muted>{per(f)}</Txt>
              </View>
              <Row gap={10}>
                <View style={{ flex: 1 }}><Button title={L('Approve', 'اعتماد')} onPress={() => decide(f, true)} /></View>
                <View style={{ flex: 1 }}><Button title={L('Reject', 'رفض')} kind="ghost" onPress={() => decide(f, false)} /></View>
              </Row>
            </Card>
          ))}
        </>
      ) : tab === 'ramadan' ? (
        <>
          <Txt v="small" muted>{L('Set the first and last day of Ramadan each year (from the official UAE announcement). During these dates everyone gets Ramadan mode offered; it turns off by itself after the last day.', 'حدد أول وآخر يوم من رمضان كل سنة. خلال هذه الأيام يظهر وضع رمضان للجميع وينطفي بعدها تلقائياً.')}</Txt>
          <Row gap={10}>
            <View style={{ flex: 1 }}><Field label={L('First day', 'أول يوم')} value={start} onChangeText={setStart} placeholder="2027-02-08" autoCapitalize="none" /></View>
            <View style={{ flex: 1 }}><Field label={L('Last day', 'آخر يوم')} value={end} onChangeText={setEnd} placeholder="2027-03-09" autoCapitalize="none" /></View>
          </Row>
          <Button title={L('Add Ramadan dates', 'أضف المواعيد')} onPress={addPeriod} />
          {periods.map((r) => (
            <Card key={r.id}>
              <Row style={{ justifyContent: 'space-between' }}>
                <Txt v="bodyStrong">{`${r.starts_on} → ${r.ends_on}`}</Txt>
                <Press onPress={() => removePeriod(r.id)} style={{ padding: 6 }}><Icon name="trash" size={16} color={theme.danger} /></Press>
              </Row>
            </Card>
          ))}
          {!periods.length ? <Txt v="small" faint>{L('No dates set: the app uses the Islamic calendar on the phone as a fallback.', 'بدون مواعيد: يستخدم التطبيق التقويم الهجري في الجوال.')}</Txt> : null}
        </>
      ) : (
        <>
          <Txt v="small" muted>{L('For safety, admin rights can only be given from the Supabase dashboard, never from inside the app.', 'لأمان أكثر، صلاحيات المسؤول تُعطى فقط من Supabase.')}</Txt>
          <Field label={L('User ID (from Supabase > Authentication > Users)', 'معرف المستخدم')} value={userId} onChangeText={setUserId} />
          <Button title={L('How to make them admin', 'كيف أجعله مسؤولاً')} kind="ghost" onPress={makeAdmin} />
        </>
      )}
    </ScrollView>
  );
}
