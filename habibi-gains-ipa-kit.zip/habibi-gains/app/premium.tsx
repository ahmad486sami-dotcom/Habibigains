import { router } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { Alert, ScrollView, View } from 'react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { useI18n } from '@/i18n/i18n';
import { success } from '@/lib/haptics';
import { buy, getPlans, Plan, restore } from '@/lib/purchases';
import { useSession } from '@/lib/session';
import { useTheme } from '@/theme/theme';
import { Logo } from '@/ui/Graphics';
import { Icon, IconName } from '@/ui/Icon';
import { Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function Premium() {
  const { t } = useI18n();
  const { theme } = useTheme();
  const { profile, refreshProfile, updateProfile } = useSession();
  const [plans, setPlans] = useState<Plan[]>([]);
  const [sel, setSel] = useState<'monthly' | 'annual'>('annual');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    getPlans().then(setPlans);
  }, []);

  const perks: { icon: IconName; text: string }[] = [
    { icon: 'camera', text: t('pAi') },
    { icon: 'sparkle', text: t('pMenu') },
    { icon: 'share', text: t('pCards') },
    { icon: 'bolt', text: t('pCoach') },
    { icon: 'run', text: t('pEarly') },
  ];

  const purchase = async () => {
    const plan = plans.find((p) => p.id === sel);
    if (!plan) return Alert.alert(t('premium'), t('storeNotReady'));
    setBusy(true);
    try {
      if (await buy(plan)) {
        success();
        await updateProfile({ is_premium: true }); // webhook confirms on the server
        await refreshProfile();
        router.back();
      }
    } catch (e: any) {
      Alert.alert(t('error'), e?.message ?? '');
    } finally {
      setBusy(false);
    }
  };

  if (profile?.is_premium)
    return (
      <View style={{ flex: 1, backgroundColor: theme.bg, padding: 24, justifyContent: 'center', gap: 20, alignItems: 'center' }}>
        <Logo width={120} color={theme.accent} />
        <Txt v="h1" center>{t('premiumActive')}</Txt>
        <Button title={t('close')} kind="secondary" onPress={() => router.back()} style={{ alignSelf: 'stretch' }} />
      </View>
    );

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ padding: 24, gap: 18, paddingBottom: 50 }}>
      <Row style={{ justifyContent: 'flex-end' }}>
        <Press onPress={() => router.back()} accessibilityLabel={t('close')} style={{ padding: 6 }}>
          <Icon name="close" />
        </Press>
      </Row>
      <Logo width={100} color={theme.accent} />
      <Txt v="hero">{t('premiumTitle')}</Txt>
      <Txt muted>{t('premiumSub')}</Txt>

      <View style={{ gap: 14, marginVertical: 6 }}>
        {perks.map((p, i) => (
          <Animated.View key={p.text} entering={FadeInDown.delay(i * 70).springify()} style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
            <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: theme.card, alignItems: 'center', justifyContent: 'center' }}>
              <Icon name={p.icon} size={19} color={theme.accent} />
            </View>
            <Txt v="bodyStrong" style={{ flex: 1 }}>{p.text}</Txt>
          </Animated.View>
        ))}
      </View>

      {(['annual', 'monthly'] as const).map((id) => {
        const plan = plans.find((p) => p.id === id);
        const on = sel === id;
        return (
          <Press
            key={id}
            onPress={() => setSel(id)}
            scaleTo={0.98}
            style={{ borderRadius: 22, padding: 18, borderWidth: 2, borderColor: on ? theme.accent : theme.border, backgroundColor: theme.card, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}
          >
            <View style={{ gap: 2 }}>
              <Row gap={8}>
                <Txt v="h3">{id === 'annual' ? t('yearly') : t('monthly')}</Txt>
                {id === 'annual' ? (
                  <View style={{ backgroundColor: theme.accent, borderRadius: 999, paddingHorizontal: 8, paddingVertical: 2 }}>
                    <Txt v="label" color={theme.onAccent}>{t('bestValue')}</Txt>
                  </View>
                ) : null}
              </Row>
              <Txt v="small" muted>{plan?.priceString ?? (id === 'annual' ? 'AED 99' : 'AED 12')}{id === 'annual' ? ` · ${t('perYear')}` : ` · ${t('perMonth')}`}</Txt>
            </View>
            <View style={{ width: 24, height: 24, borderRadius: 12, borderWidth: 2, borderColor: on ? theme.accent : theme.faint, alignItems: 'center', justifyContent: 'center' }}>
              {on ? <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: theme.accent }} /> : null}
            </View>
          </Press>
        );
      })}

      <Button title={t('subscribe')} loading={busy} onPress={purchase} />
      <Press onPress={async () => { if (await restore().catch(() => false)) { success(); await refreshProfile(); router.back(); } }} style={{ alignSelf: 'center', padding: 8 }}>
        <Txt muted>{t('restore')}</Txt>
      </Press>
      <Txt v="small" faint center>{t('subscriptionTerms')}</Txt>
    </ScrollView>
  );
}
