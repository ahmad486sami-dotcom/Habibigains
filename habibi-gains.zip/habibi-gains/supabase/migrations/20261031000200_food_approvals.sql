-- Food approvals: scans and user foods stay private until an admin approves them.
alter table public.foods add column if not exists review_status text not null default 'pending'
  check (review_status in ('pending', 'approved', 'rejected'));
update public.foods set review_status = 'approved' where verified = true;
drop policy if exists "foods readable" on public.foods;
create policy "foods readable" on public.foods for select to authenticated using (
  source in ('usda', 'uae')
  or (source in ('off', 'user') and verified = true)
  or created_by = (select auth.uid())
  or (source = 'recipe' and is_shared = true)
  or public.my_role() = 'admin');
alter table public.foods drop constraint if exists foods_barcode_key;
create unique index if not exists foods_barcode_per_user on public.foods (barcode, created_by) where barcode is not null;
create index if not exists foods_review_queue on public.foods (created_at desc) where review_status = 'pending' and source in ('off', 'user');
