// Weekly calorie bank.
// Rules (Build Plan): a day counts once it has at least one food logged.
// Unlogged days are greyed out and left out of the week: budget = daily target x days logged.
// The week starts on Saturday by default (UAE weekend); the user can change it in settings.
import { todayISO } from './supabase';

export type DayStatus = 'under' | 'over' | 'unlogged' | 'future';
export type WeekDay = { day: string; label: string; kcal: number; status: DayStatus; isToday: boolean };
export type WeekSummary = { days: WeekDay[]; eaten: number; budget: number; left: number; logged: number };

const LABELS_EN = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
const LABELS_AR = ['ح', 'ن', 'ث', 'ر', 'خ', 'ج', 'س'];

/** 0 = Sunday ... 6 = Saturday. Default 6 (Saturday). */
export function weekStart(date = new Date(), startDay = 6) {
  const d = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const diff = (d.getDay() - startDay + 7) % 7;
  d.setDate(d.getDate() - diff);
  return d;
}

export function buildWeek(
  totals: { day: string; kcal: number }[],
  todayKcal: number,
  target: number,
  lang = 'en',
  startDay = 6,
  now = new Date(),
): WeekSummary {
  const map = new Map(totals.map((t) => [t.day, t.kcal]));
  const today = todayISO(now);
  map.set(today, todayKcal);
  const start = weekStart(now, startDay);
  const labels = lang === 'ar' ? LABELS_AR : LABELS_EN;

  const days: WeekDay[] = [];
  let eaten = 0;
  let logged = 0;
  for (let i = 0; i < 7; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    const iso = todayISO(d);
    const kcal = Math.round(map.get(iso) ?? 0);
    const isToday = iso === today;
    let status: DayStatus;
    if (iso > today) status = 'future';
    else if (kcal <= 0) status = 'unlogged';
    else status = kcal > target ? 'over' : 'under';
    if (status === 'under' || status === 'over') {
      eaten += kcal;
      logged += 1;
    }
    days.push({ day: iso, label: labels[d.getDay()], kcal, status, isToday });
  }
  const budget = target * logged;
  return { days, eaten, budget, left: budget - eaten, logged };
}
