// Week strip under the daily calories: 7 dots + one honest line.
// green = under target, coral = over, grey = not logged (left out of the week), outline = still to come.
import React from 'react';
import { View } from 'react-native';
import { WeekSummary } from '@/lib/week';
import { useTheme } from '@/theme/theme';
import { Card, Row } from './Layout';
import { Txt } from './Txt';

const fmt = (n: number) => Math.round(n).toLocaleString('en-US');

export function WeekStrip({ week, lang, onPress, index = 2 }: { week: WeekSummary; lang: string; onPress?: () => void; index?: number }) {
  const { theme } = useTheme();
  const ar = lang === 'ar';
  const coral = '#FF7A59';

  const line = week.logged === 0
    ? (ar ? 'هذا الأسبوع: سجّل أول وجبة لتبدأ' : 'This week: log your first meal to start')
    : ar
      ? `هذا الأسبوع: ${fmt(week.eaten)} أكلت · ${fmt(week.budget)} الميزانية · ${fmt(Math.abs(week.left))} ${week.left >= 0 ? 'متبقي' : 'زيادة'} · ${week.logged} من 7 أيام`
      : `This week: ${fmt(week.eaten)} eaten · ${fmt(week.budget)} budget · ${fmt(Math.abs(week.left))} ${week.left >= 0 ? 'left' : 'over'} · ${week.logged} of 7 days`;

  return (
    <Card index={index} onPress={onPress}>
      <Row style={{ justifyContent: 'space-between' }}>
        {week.days.map((d) => {
          const fill = d.status === 'under' ? theme.accent : d.status === 'over' ? coral : d.status === 'unlogged' ? theme.cardHigh : 'transparent';
          const border = d.status === 'future' ? theme.faint : fill;
          return (
            <View key={d.day} style={{ alignItems: 'center', gap: 6 }}>
              <Txt v="small" muted style={{ fontSize: 11, fontWeight: d.isToday ? '700' : '400' }}>{d.label}</Txt>
              <View
                style={{
                  width: 26, height: 26, borderRadius: 13, backgroundColor: fill,
                  borderWidth: d.isToday ? 2 : 1.5, borderColor: d.isToday ? theme.text : border,
                  borderStyle: d.status === 'unlogged' ? 'dashed' : 'solid',
                }}
              />
            </View>
          );
        })}
      </Row>
      <Txt v="small" muted>{line}</Txt>
      {week.logged > 0 && week.logged < week.days.filter((d) => d.status !== 'future').length ? (
        <Txt v="small" color={theme.faint} style={{ fontSize: 11 }}>
          {ar ? 'الأيام الرمادية غير مسجلة ولا تُحسب في الأسبوع.' : 'Grey days were not logged and are left out of the week.'}
        </Txt>
      ) : null}
    </Card>
  );
}
