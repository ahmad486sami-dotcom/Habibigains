// Profiles, friends, privacy, food-diary sharing and challenges.
import * as Crypto from 'expo-crypto';
import { supabase, todayISO } from './supabase';

export type Visibility = 'everyone' | 'friends' | 'only_me' | 'specific';
export const PRIVACY_FIELDS = ['photo', 'bio', 'gym', 'streak', 'steps', 'kg_lost', 'week', 'diary'] as const;
export type PrivacyField = (typeof PRIVACY_FIELDS)[number];
export type Privacy = Record<PrivacyField, Visibility>;
export const DEFAULT_PRIVACY: Privacy = { photo: 'everyone', bio: 'everyone', gym: 'friends', streak: 'friends', steps: 'friends', kg_lost: 'only_me', week: 'friends', diary: 'only_me' };

export const FIELD_LABEL: Record<PrivacyField, { en: string; ar: string }> = {
  photo: { en: 'Profile photo', ar: 'الصورة' },
  bio: { en: 'Bio', ar: 'النبذة' },
  gym: { en: 'My gym', ar: 'النادي' },
  streak: { en: 'Streak', ar: 'السلسلة' },
  steps: { en: 'Steps', ar: 'الخطوات' },
  kg_lost: { en: 'Weight lost', ar: 'الوزن المفقود' },
  week: { en: 'My week (calorie dots)', ar: 'أسبوعي' },
  diary: { en: 'Food diary (what I eat)', ar: 'يومياتي الغذائية' },
};

export const UAE_GYMS = ['Fitness First', 'GymNation', "Gold's Gym", 'Warehouse Gym', 'Gymnasium', 'Snap Fitness', 'Anytime Fitness', 'Fitness Time', 'ProFit', 'Home gym'];

export type ProfileCard = {
  id: string;
  display_name: string | null;
  username: string | null;
  relation: 'self' | 'friend' | 'requested' | 'incoming' | 'none';
  avatar_url: string | null;
  bio: string | null;
  gym: string | null;
  streak: number | null;
  steps_today: number | null;
  kg_lost: number | null;
  week: { day: string; kcal: number }[] | null;
  calorie_target: number | null;
  diary: boolean;
};

async function me() {
  const { data } = await supabase.auth.getUser();
  if (!data.user) throw new Error('not signed in');
  return data.user.id;
}

export async function getProfileCard(id: string): Promise<ProfileCard | null> {
  const { data, error } = await supabase.rpc('profile_card', { target: id });
  if (error) throw error;
  return (data as ProfileCard) ?? null;
}

export async function uploadAvatar(uri: string) {
  const uid = await me();
  const path = `${uid}/avatar-${Date.now()}.jpg`;
  const body = await (await fetch(uri)).arrayBuffer();
  const { error } = await supabase.storage.from('avatars').upload(path, body, { contentType: 'image/jpeg', upsert: true });
  if (error) throw error;
  return supabase.storage.from('avatars').getPublicUrl(path).data.publicUrl;
}

// Phone numbers are matched by a hash of their last 9 digits, never stored in plain text.
const tail = (n: string) => n.replace(/\D/g, '').slice(-9);
export const hashPhone = async (n: string) => (tail(n).length === 9 ? Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, tail(n)) : null);

export type Person = { id: string; username: string | null; display_name: string | null; avatar_url?: string | null };

export async function searchPeople(q: string): Promise<Person[]> {
  const term = q.trim().replace(/^@/, '').toLowerCase();
  if (term.length < 2) return [];
  const { data, error } = await supabase.rpc('find_by_username', { q: term });
  if (error) throw error;
  return (data ?? []) as Person[];
}

export async function matchContacts(numbers: string[]): Promise<Person[]> {
  const hashes = (await Promise.all([...new Set(numbers)].slice(0, 2000).map(hashPhone))).filter(Boolean) as string[];
  if (!hashes.length) return [];
  const { data, error } = await supabase.rpc('match_contacts', { hashes });
  if (error) throw error;
  return (data ?? []) as Person[];
}

export async function sendRequest(to: string) {
  const { error } = await supabase.from('friendships').insert({ requester: await me(), addressee: to, status: 'pending' });
  if (error) throw error;
}
export async function acceptRequest(from: string) {
  const { error } = await supabase.from('friendships').update({ status: 'accepted' }).eq('requester', from).eq('addressee', await me());
  if (error) throw error;
}
export async function removeFriend(other: string) {
  const uid = await me();
  const { error } = await supabase.from('friendships').delete().or(`and(requester.eq.${uid},addressee.eq.${other}),and(requester.eq.${other},addressee.eq.${uid})`);
  if (error) throw error;
}

export type FriendRow = Person & { status: 'accepted' | 'incoming' | 'outgoing' };
export async function listFriends(): Promise<FriendRow[]> {
  const uid = await me();
  const { data, error } = await supabase.from('friendships').select('requester,addressee,status');
  if (error) throw error;
  const rows = (data ?? []) as { requester: string; addressee: string; status: string }[];
  const ids = rows.map((r) => (r.requester === uid ? r.addressee : r.requester));
  if (!ids.length) return [];
  const { data: cards } = await supabase.rpc('profile_cards', { ids });
  const byId = new Map(((cards ?? []) as any[]).map((c) => [c.id, c]));
  return rows.map((r) => {
    const other = r.requester === uid ? r.addressee : r.requester;
    const c = byId.get(other) ?? {};
    return {
      id: other,
      username: c.username ?? null,
      display_name: c.display_name ?? null,
      avatar_url: c.avatar_url ?? null,
      status: r.status === 'accepted' ? 'accepted' : r.requester === uid ? 'outgoing' : 'incoming',
    } as FriendRow;
  });
}

/** "Specific people" list: who can see fields set to Specific. */
export async function getAllowList(): Promise<string[]> {
  const { data } = await supabase.from('visibility_allow').select('viewer');
  return (data ?? []).map((r: any) => r.viewer);
}
export async function setAllowed(viewer: string, on: boolean) {
  const owner = await me();
  if (on) await supabase.from('visibility_allow').upsert({ owner, viewer });
  else await supabase.from('visibility_allow').delete().eq('owner', owner).eq('viewer', viewer);
}

/** A friend's food diary for a day (only works if they share it with you). */
export async function friendDiary(userId: string, day = todayISO()) {
  const { data, error } = await supabase.from('food_logs').select('id,name,brand,meal,kcal,protein_g,carbs_g,fat_g,serving_label,quantity').eq('user_id', userId).eq('logged_on', day).order('created_at');
  if (error) throw error;
  return data ?? [];
}

// ───────── Steps (saved so friends and step challenges can use them) ─────────
export async function saveSteps(steps: number, day = todayISO()) {
  const user_id = await me();
  await supabase.from('daily_steps').upsert({ user_id, day, steps: Math.max(0, Math.min(200000, Math.round(steps))) });
}

// ───────── Challenges ─────────
export type ChallengeKind = 'weight_pct' | 'weight_kg' | 'steps' | 'log_days';
export const KIND_LABEL: Record<ChallengeKind, { en: string; ar: string; unit: string }> = {
  weight_pct: { en: '% weight lost', ar: 'نسبة الوزن المفقود', unit: '%' },
  weight_kg: { en: 'kg lost', ar: 'كجم مفقود', unit: 'kg' },
  steps: { en: 'Most steps', ar: 'أكثر خطوات', unit: 'steps' },
  log_days: { en: 'Days logged', ar: 'أيام التسجيل', unit: 'days' },
};
export type Challenge = { id: string; creator: string; title: string; kind: ChallengeKind; starts_on: string; ends_on: string; stake: string | null };

export async function myChallenges(): Promise<Challenge[]> {
  const { data, error } = await supabase.from('challenges').select('id,creator,title,kind,starts_on,ends_on,stake').eq('is_community', false).order('ends_on', { ascending: false }).limit(30);
  if (error) throw error;
  return (data ?? []) as Challenge[];
}

export async function createChallenge(c: { title: string; kind: ChallengeKind; days: number; stake: string; friends: string[] }) {
  const creator = await me();
  const start = todayISO();
  const end = todayISO(new Date(Date.now() + (c.days - 1) * 86_400_000));
  const { data, error } = await supabase.from('challenges').insert({ creator, title: c.title, kind: c.kind, starts_on: start, ends_on: end, is_community: false, stake: c.stake || null }).select('id').single();
  if (error) throw error;
  const members = [creator, ...c.friends].map((user_id) => ({ challenge_id: data.id, user_id }));
  const { error: e2 } = await supabase.from('challenge_members').insert(members);
  if (e2) throw e2;
  return data.id as string;
}

export async function challengeBoard(id: string) {
  const { data, error } = await supabase.rpc('challenge_board', { cid: id });
  if (error) throw error;
  return (data ?? []) as { user_id: string; username: string | null; display_name: string | null; avatar_key: string | null; score: number | null }[];
}

export async function leaveChallenge(id: string) {
  const { error } = await supabase.from('challenge_members').delete().eq('challenge_id', id).eq('user_id', await me());
  if (error) throw error;
}
