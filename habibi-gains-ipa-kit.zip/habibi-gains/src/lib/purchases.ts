// RevenueCat subscriptions. Needs a development/production build (not Expo Go).
// In RevenueCat: create an entitlement called "premium", and an offering with
// monthly (12 AED) and annual (99 AED) packages linked to your App Store / Play products.
import { Platform } from 'react-native';
import { IS_DEMO } from './demo';

export const ENTITLEMENT = 'premium';
let configured = false;

function rc(): any | null {
  try {
    const mod = require('react-native-purchases');
    return mod.default ?? mod;
  } catch {
    return null;
  }
}

export function configurePurchases(userId: string) {
  const Purchases = rc();
  if (!Purchases) return;
  const apiKey = Platform.OS === 'ios' ? process.env.EXPO_PUBLIC_REVENUECAT_IOS_KEY : process.env.EXPO_PUBLIC_REVENUECAT_ANDROID_KEY;
  if (!apiKey) return;
  try {
    if (!configured) {
      Purchases.configure({ apiKey, appUserID: userId });
      configured = true;
    } else {
      Purchases.logIn(userId);
    }
  } catch {
    // ignore in unsupported environments
  }
}

export type Plan = { id: 'monthly' | 'annual'; priceString: string; pkg: unknown };

export async function getPlans(): Promise<Plan[]> {
  if (IS_DEMO) return [{ id: 'monthly', priceString: 'AED 12.00', pkg: null }, { id: 'annual', priceString: 'AED 99.00', pkg: null }];
  const Purchases = rc();
  if (!Purchases || !configured) return [];
  try {
    const offerings = await Purchases.getOfferings();
    const current = offerings.current;
    if (!current) return [];
    const plans: Plan[] = [];
    if (current.monthly) plans.push({ id: 'monthly', priceString: current.monthly.product.priceString, pkg: current.monthly });
    if (current.annual) plans.push({ id: 'annual', priceString: current.annual.product.priceString, pkg: current.annual });
    return plans;
  } catch {
    return [];
  }
}

export async function buy(plan: Plan): Promise<boolean> {
  if (IS_DEMO) return true;
  const Purchases = rc();
  if (!Purchases) return false;
  try {
    const { customerInfo } = await Purchases.purchasePackage(plan.pkg);
    return !!customerInfo.entitlements.active[ENTITLEMENT];
  } catch (e: any) {
    if (e?.userCancelled) return false;
    throw e;
  }
}

export async function restore(): Promise<boolean> {
  if (IS_DEMO) return true;
  const Purchases = rc();
  if (!Purchases) return false;
  const info = await Purchases.restorePurchases();
  return !!info.entitlements.active[ENTITLEMENT];
}

export async function hasPremium(): Promise<boolean> {
  if (IS_DEMO) return true;
  const Purchases = rc();
  if (!Purchases || !configured) return false;
  try {
    const info = await Purchases.getCustomerInfo();
    return !!info.entitlements.active[ENTITLEMENT];
  } catch {
    return false;
  }
}
