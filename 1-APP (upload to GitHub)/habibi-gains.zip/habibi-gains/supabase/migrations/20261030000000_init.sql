-- Habibi Gains · initial schema
-- Run with: supabase db push   (or paste into the Supabase SQL editor)

create extension if not exists "pgcrypto";
create extension if not exists pg_trgm with schema extensions;

-- ───────────────────────── Profiles & roles ─────────────────────────
create type public.user_role as enum ('member', 'host', 'admin');
create type public.goal_type as enum ('lose', 'maintain', 'gain');
create type public.activity_level as enum ('low', 'light', 'moderate', 'high');

create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  display_name text,
  role public.user_role not null default 'member',
  sex text check (sex in ('male', 'female')),
  birth_year int check (birth_year between 1920 and 2020),
  height_cm numeric check (height_cm between 120 and 230),
  start_weight_kg numeric check (start_weight_kg between 30 and 300),
  goal_weight_kg numeric check (goal_weight_kg between 30 and 300),
  goal public.goal_type not null default 'lose',
  activity public.activity_level not null default 'moderate',
  calorie_target int,
  protein_target_g int,
  ramadan_mode boolean not null default false,
  emirate text not null default 'Abu Dhabi',
  wake_time text not null default '07:00',
  sleep_time text not null default '23:30',
  training_time text default '18:00',
  use_creatine boolean not null default false,
  use_caffeine boolean not null default false,
  language text not null default 'en' check (language in ('en', 'ar')),
  accent text not null default '#F5F5F2',
  xp int not null default 0,
  streak_days int not null default 0,
  last_active_date date,
  is_premium boolean not null default false,
  water_goal_ml int not null default 3000 check (water_goal_ml between 500 and 10000),
  created_at timestamptz not null default now()
);

-- Create a profile automatically when someone signs up.
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', split_part(new.email, '@', 1)));
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Helper: is the current user an admin / host?
create function public.my_role() returns public.user_role
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid()
$$;

-- Users must not be able to promote themselves.
create function public.protect_profile_fields() returns trigger
language plpgsql set search_path = public as $$
begin
  -- Only app users (the anon/authenticated roles) are restricted. The SQL editor,
  -- the service role (webhooks) and our own security-definer XP functions run as other roles.
  if current_user in ('authenticated', 'anon')
     and coalesce(current_setting('app.trusted', true), '') <> 'on'
     and public.my_role() is distinct from 'admin' then
    new.role := old.role;
    new.is_premium := old.is_premium;
    new.xp := old.xp;
  end if;
  return new;
end $$;

create trigger profiles_protect before update on public.profiles
  for each row execute function public.protect_profile_fields();

-- ───────────────────────── Weight & progress ─────────────────────────
create table public.weigh_ins (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  weight_kg numeric not null check (weight_kg between 30 and 300),
  measured_on date not null default current_date,
  source text not null default 'manual' check (source in ('manual', 'health')),
  created_at timestamptz not null default now(),
  unique (user_id, measured_on)
);

create table public.progress_photos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  storage_path text not null,
  pose text not null default 'front' check (pose in ('front', 'side', 'back')),
  taken_on date not null default current_date,
  created_at timestamptz not null default now()
);

-- ───────────────────────── Food ─────────────────────────
-- Nutrients are stored per base_g grams (100 g for database foods).
-- servings = [{"label": "1 cup", "g": 240}, ...]; logging multiplies grams by the per-gram values.

create table public.foods (
  id uuid primary key default gen_random_uuid(),
  name_en text not null check (char_length(name_en) between 1 and 160),
  name_ar text,
  brand text,
  source text not null default 'user' check (source in ('usda', 'uae', 'off', 'user', 'recipe')),
  usda_id text unique,
  food_group text,
  barcode text unique,
  search_text text,
  base_g numeric not null default 100 check (base_g > 0),
  kcal numeric not null check (kcal >= 0),
  protein_g numeric not null default 0 check (protein_g >= 0),
  carbs_g numeric not null default 0 check (carbs_g >= 0),
  fat_g numeric not null default 0 check (fat_g >= 0),
  fiber_g numeric,
  sugar_g numeric,
  sodium_mg numeric,
  sat_fat_g numeric,
  cholesterol_mg numeric,
  potassium_mg numeric,
  servings jsonb not null default '[]'::jsonb,
  ingredients jsonb,
  recipe_servings numeric,
  is_local boolean not null default false,
  created_by uuid references public.profiles (id) on delete cascade,
  verified boolean not null default false,
  created_at timestamptz not null default now()
);
create index foods_name_trgm on public.foods using gin (lower(name_en) extensions.gin_trgm_ops);
create index foods_search_trgm on public.foods using gin (search_text extensions.gin_trgm_ops);
create index foods_name_ar_trgm on public.foods using gin (name_ar extensions.gin_trgm_ops);
create index foods_owner on public.foods (created_by);

create table public.food_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  food_id uuid references public.foods (id) on delete set null,
  name text not null,
  brand text,
  meal text not null default 'snack' check (meal in ('breakfast', 'lunch', 'dinner', 'snack', 'suhoor', 'iftar')),
  quantity numeric not null default 1 check (quantity > 0 and quantity <= 10000),
  serving_label text not null default '1 serving',
  serving_g numeric check (serving_g is null or serving_g > 0),
  kcal numeric not null check (kcal >= 0),
  protein_g numeric not null default 0,
  carbs_g numeric not null default 0,
  fat_g numeric not null default 0,
  fiber_g numeric,
  sugar_g numeric,
  sodium_mg numeric,
  sat_fat_g numeric,
  cholesterol_mg numeric,
  potassium_mg numeric,
  logged_on date not null default current_date,
  source text not null default 'search' check (source in ('search', 'barcode', 'photo', 'quick', 'recipe', 'custom', 'copy')),
  created_at timestamptz not null default now()
);
create index food_logs_user_day on public.food_logs (user_id, logged_on);
create index food_logs_user_recent on public.food_logs (user_id, created_at desc);
create index food_logs_food on public.food_logs (food_id);

create table public.favorite_foods (
  user_id uuid not null references public.profiles (id) on delete cascade,
  food_id uuid not null references public.foods (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, food_id)
);
create index favorite_foods_food on public.favorite_foods (food_id);

create table public.water_days (
  user_id uuid not null references public.profiles (id) on delete cascade,
  day date not null,
  ml int not null default 0 check (ml between 0 and 20000),
  primary key (user_id, day)
);

-- Ranked food search: your own foods, then UAE dishes, then prefix matches, then closest names.
create function public.search_foods(q text, lim int default 40) returns setof public.foods
language sql stable set search_path = public, extensions as $$
  with t as (select lower(trim(q)) as q),
  words as (select array_agg('%' || w || '%') as pats from t, unnest(string_to_array(regexp_replace(t.q, '[%_,()]', ' ', 'g'), ' ')) w where w <> '')
  select f.* from public.foods f, t, words
  where (lower(f.name_en) ilike all (words.pats) or coalesce(f.search_text, '') ilike all (words.pats) or coalesce(f.name_ar, '') ilike '%' || t.q || '%')
  order by (f.created_by = auth.uid()) desc nulls last,
           (lower(f.name_en) = t.q or lower(f.name_en) like t.q || ',%' or lower(f.name_en) like t.q || 's,%') desc,
           (f.source = 'uae') desc,
           (lower(f.name_en) like t.q || '%') desc,
           (lower(f.name_en) like '%, raw%' or lower(f.name_en) like '%, cooked%') desc,
           similarity(lower(f.name_en), t.q) desc,
           char_length(f.name_en)
  limit least(greatest(lim, 1), 80)
$$;

-- Runs recorded with the GPS tracker.
create table public.runs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  title text,
  started_at timestamptz not null,
  ended_at timestamptz not null,
  moving_s int not null check (moving_s >= 0),
  elapsed_s int not null check (elapsed_s >= 0),
  distance_m numeric not null check (distance_m >= 0),
  kcal int not null default 0,
  elev_gain_m numeric,
  route jsonb not null default '[]'::jsonb,
  splits jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now()
);
create index runs_user_started on public.runs (user_id, started_at desc);

-- ───────────────────────── Community ─────────────────────────
create table public.events (
  id uuid primary key default gen_random_uuid(),
  host_id uuid not null references public.profiles (id) on delete cascade,
  title text not null,
  description text,
  location_name text not null,
  emirate text not null default 'Abu Dhabi',
  starts_at timestamptz not null,
  checkin_code text not null default encode(gen_random_bytes(6), 'hex'),
  badge_name text not null default 'Run Club',
  xp int not null default 100,
  women_only boolean not null default false,
  created_at timestamptz not null default now()
);
create index events_host on public.events (host_id);

create table public.event_rsvps (
  event_id uuid references public.events (id) on delete cascade,
  user_id uuid references public.profiles (id) on delete cascade,
  checked_in_at timestamptz,
  primary key (event_id, user_id)
);
create index event_rsvps_user on public.event_rsvps (user_id);

create table public.quests (
  id uuid primary key default gen_random_uuid(),
  created_by uuid not null references public.profiles (id) on delete cascade,
  title_en text not null,
  title_ar text,
  description text,
  proof text not null default 'photo' check (proof in ('photo', 'steps', 'checkin', 'honor')),
  target_steps int,
  xp int not null default 50,
  starts_on date not null default current_date,
  ends_on date not null default (current_date + 7),
  created_at timestamptz not null default now()
);
create index quests_created_by on public.quests (created_by);

create table public.quest_completions (
  quest_id uuid references public.quests (id) on delete cascade,
  user_id uuid references public.profiles (id) on delete cascade,
  proof_path text,
  completed_at timestamptz not null default now(),
  primary key (quest_id, user_id)
);
create index quest_completions_user on public.quest_completions (user_id);

create table public.badges (
  id text primary key,
  name_en text not null,
  name_ar text,
  description text,
  icon text not null default 'medal'
);

create table public.user_badges (
  user_id uuid references public.profiles (id) on delete cascade,
  badge_id text references public.badges (id) on delete cascade,
  earned_at timestamptz not null default now(),
  primary key (user_id, badge_id)
);
create index user_badges_badge on public.user_badges (badge_id);

-- Women-only events are visible to women, admins and the event host.
create function public.can_see_women_only() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and (sex = 'female' or role = 'admin'))
$$;

-- Check in to an event with the code shown on the host's screen (QR).
create function public.check_in(p_code text) returns json
language plpgsql security definer set search_path = public as $$
declare ev public.events; prev timestamptz;
begin
  select * into ev from public.events
   where checkin_code = p_code
     and now() between starts_at - interval '1 hour' and starts_at + interval '4 hours';
  if ev.id is null then
    return json_build_object('ok', false, 'error', 'invalid_or_expired');
  end if;
  if ev.women_only and not public.can_see_women_only() then
    return json_build_object('ok', false, 'error', 'women_only');
  end if;
  select checked_in_at into prev from public.event_rsvps where event_id = ev.id and user_id = auth.uid();
  if prev is not null then
    return json_build_object('ok', true, 'event', ev.title, 'badge', ev.badge_name, 'xp', 0, 'already', true);
  end if;
  insert into public.event_rsvps (event_id, user_id, checked_in_at)
  values (ev.id, auth.uid(), now())
  on conflict (event_id, user_id) do update set checked_in_at = coalesce(event_rsvps.checked_in_at, now());
  insert into public.badges (id, name_en) values ('event-' || ev.id, ev.badge_name) on conflict do nothing;
  insert into public.user_badges (user_id, badge_id) values (auth.uid(), 'event-' || ev.id) on conflict do nothing;
  perform set_config('app.trusted', 'on', true);
  update public.profiles set xp = xp + ev.xp where id = auth.uid();
  return json_build_object('ok', true, 'event', ev.title, 'badge', ev.badge_name, 'xp', ev.xp);
end $$;

-- Complete a quest and collect XP once.
create function public.complete_quest(p_quest uuid, p_proof text default null) returns json
language plpgsql security definer set search_path = public as $$
declare q public.quests;
begin
  select * into q from public.quests where id = p_quest and current_date between starts_on and ends_on;
  if q.id is null then return json_build_object('ok', false, 'error', 'not_active'); end if;
  insert into public.quest_completions (quest_id, user_id, proof_path) values (q.id, auth.uid(), p_proof)
  on conflict do nothing;
  if found then
    perform set_config('app.trusted', 'on', true);
    update public.profiles set xp = xp + q.xp where id = auth.uid();
  end if;
  return json_build_object('ok', true, 'xp', q.xp);
end $$;

-- Daily streak: call once when the app opens.
create function public.touch_streak() returns int
language plpgsql security definer set search_path = public as $$
declare p public.profiles;
begin
  select * into p from public.profiles where id = auth.uid();
  if p.last_active_date = current_date then return p.streak_days; end if;
  update public.profiles
     set streak_days = case when p.last_active_date = current_date - 1 then p.streak_days + 1 else 1 end,
         last_active_date = current_date
   where id = auth.uid()
   returning streak_days into p.streak_days;
  return p.streak_days;
end $$;

-- ───────────────────────── Row level security ─────────────────────────
alter table public.profiles enable row level security;
alter table public.weigh_ins enable row level security;
alter table public.progress_photos enable row level security;
alter table public.foods enable row level security;
alter table public.food_logs enable row level security;
alter table public.favorite_foods enable row level security;
alter table public.water_days enable row level security;
alter table public.runs enable row level security;
alter table public.events enable row level security;
alter table public.event_rsvps enable row level security;
alter table public.quests enable row level security;
alter table public.quest_completions enable row level security;
alter table public.badges enable row level security;
alter table public.user_badges enable row level security;

create policy "own profile read" on public.profiles for select using (id = (select auth.uid()) or public.my_role() = 'admin');
create policy "own profile update" on public.profiles for update using (id = (select auth.uid()) or public.my_role() = 'admin');

create policy "own weigh-ins" on public.weigh_ins for all using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy "own photos" on public.progress_photos for all using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy "own food logs" on public.food_logs for all using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

create policy "foods readable" on public.foods for select to authenticated using (
  source in ('usda', 'uae', 'off') or created_by = (select auth.uid()) or public.my_role() = 'admin');
create policy "users add foods" on public.foods for insert to authenticated with check (
  (created_by = (select auth.uid()) and verified = false and source in ('user', 'recipe', 'off')) or public.my_role() = 'admin');
create policy "users edit own foods" on public.foods for update to authenticated
  using ((created_by = (select auth.uid()) and source in ('user', 'recipe')) or public.my_role() = 'admin')
  with check ((created_by = (select auth.uid()) and source in ('user', 'recipe')) or public.my_role() = 'admin');
create policy "users delete own foods" on public.foods for delete to authenticated
  using ((created_by = (select auth.uid()) and source in ('user', 'recipe')) or public.my_role() = 'admin');
create policy "own favorites" on public.favorite_foods for all using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy "own water" on public.water_days for all using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy "own runs" on public.runs for all using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

create policy "events readable" on public.events for select using ((select auth.role()) = 'authenticated');
create policy "hosts create events" on public.events for insert with check (host_id = (select auth.uid()) and public.my_role() in ('host', 'admin'));
create policy "hosts edit own events" on public.events for update using (host_id = (select auth.uid()) or public.my_role() = 'admin');
create policy "hosts delete own events" on public.events for delete using (host_id = (select auth.uid()) or public.my_role() = 'admin');
-- Members never see the check-in code. They can read every column except it,
-- and the app reads events through this view, which only reveals the code to the host or an admin.
revoke select on public.events from anon, authenticated;
grant select (id, host_id, title, description, location_name, emirate, starts_at, badge_name, xp, women_only, created_at)
  on public.events to authenticated;
create view public.events_public with (security_invoker = false) as
  select e.id, e.host_id, e.title, e.description, e.location_name, e.emirate, e.starts_at, e.badge_name, e.xp, e.women_only,
         case when e.host_id = auth.uid() or public.my_role() = 'admin' then e.checkin_code end as checkin_code,
         (select count(*) from public.event_rsvps r where r.event_id = e.id) as going,
         exists (select 1 from public.event_rsvps r where r.event_id = e.id and r.user_id = auth.uid()) as i_am_going
  from public.events e
  where not e.women_only or e.host_id = auth.uid() or public.can_see_women_only();
revoke all on public.events_public from anon;
grant select on public.events_public to authenticated;

create policy "rsvp own" on public.event_rsvps for all using (user_id = (select auth.uid())) with check (
  user_id = (select auth.uid())
  and exists (select 1 from public.events e where e.id = event_id and (not e.women_only or public.can_see_women_only())));
create policy "hosts see rsvps" on public.event_rsvps for select using (
  exists (select 1 from public.events e where e.id = event_id and (e.host_id = (select auth.uid()) or public.my_role() = 'admin')));

create policy "quests readable" on public.quests for select using ((select auth.role()) = 'authenticated');
create policy "hosts create quests" on public.quests for insert with check (created_by = (select auth.uid()) and public.my_role() in ('host', 'admin'));
create policy "hosts edit quests" on public.quests for update using (created_by = (select auth.uid()) or public.my_role() = 'admin');
create policy "own completions" on public.quest_completions for select using (user_id = (select auth.uid()));

create policy "badges readable" on public.badges for select using (true);
create policy "own badges" on public.user_badges for select using (user_id = (select auth.uid()));

-- ───────────────────────── Storage ─────────────────────────
insert into storage.buckets (id, name, public) values ('progress', 'progress', false) on conflict do nothing;
insert into storage.buckets (id, name, public) values ('quests', 'quests', false) on conflict do nothing;

create policy "own progress files" on storage.objects for all to authenticated
  using (bucket_id in ('progress', 'quests') and (storage.foldername(name))[1] = (select auth.uid())::text)
  with check (bucket_id in ('progress', 'quests') and (storage.foldername(name))[1] = (select auth.uid())::text);

-- ───────────────────────── Starter badges ─────────────────────────
insert into public.badges (id, name_en, name_ar, description, icon) values
  ('first-log', 'First Bite', 'أول لقمة', 'Logged your first meal', 'fork'),
  ('first-weigh', 'On the Scale', 'على الميزان', 'Logged your first weigh-in', 'scale'),
  ('streak-7', 'One Week Strong', 'أسبوع قوي', '7-day streak', 'flame'),
  ('streak-30', 'Habibi Habit', 'عادة حبيبي', '30-day streak', 'flame'),
  ('first-photo', 'Day One', 'اليوم الأول', 'Took your first progress photo', 'camera'),
  ('first-run', 'Run Club', 'نادي الجري', 'Checked in to your first run club', 'run'),
  ('first-quest', 'Side Quester', 'صاحب المهمات', 'Completed your first side quest', 'star'),
  ('down-5', 'Five Down', 'خمسة أقل', 'Trend weight down 5 kg', 'trend'),
  ('first-gps-run', 'First Steps', 'أول خطوات', 'Recorded your first run', 'run'),
  ('run-5k', '5K Club', 'نادي ٥ كم', 'Ran 5 km in one go', 'run'),
  ('run-10k', 'Double Digits', 'عشرة كيلو', 'Ran 10 km in one go', 'run')
on conflict do nothing;

create function public.award_badge(p_badge text) returns boolean
language plpgsql security definer set search_path = public as $$
begin
  if p_badge not in ('first-log', 'first-weigh', 'streak-7', 'streak-30', 'first-photo', 'first-run', 'first-quest', 'down-5', 'first-gps-run', 'run-5k', 'run-10k') then
    return false;
  end if;
  insert into public.user_badges (user_id, badge_id) values (auth.uid(), p_badge) on conflict do nothing;
  return found;
end $$;
