// Live GPS run: map, time, distance, pace. Keeps recording with the phone locked.
import * as Location from 'expo-location';
import { router } from 'expo-router';
import { activateKeepAwakeAsync, deactivateKeepAwake } from 'expo-keep-awake';
import React, { useEffect, useRef, useState } from 'react';
import { Alert, Linking, StyleSheet, View } from 'react-native';
import MapView, { Polyline } from 'react-native-maps';
import Animated, { Easing, FadeIn, FadeInDown, useAnimatedStyle, useSharedValue, withTiming } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useI18n } from '@/i18n/i18n';
import { awardBadge, fetchTrend, saveRun } from '@/lib/data';
import { press, success, warn } from '@/lib/haptics';
import {
  currentPace,
  discardRun,
  distanceM,
  elevationGain,
  finishRun,
  formatDuration,
  getRunState,
  formatKm,
  formatPace,
  movingMs,
  pauseRun,
  requestRunPermission,
  restoreRun,
  resumeRun,
  RunState,
  runKcal,
  simplify,
  splits,
  startRun,
  subscribe,
} from '@/lib/runTracker';
import { useSession } from '@/lib/session';
import { useTheme } from '@/theme/theme';
import { useCelebrate } from '@/ui/Celebrate';
import { Icon } from '@/ui/Icon';
import { Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function LiveRun() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const celebrate = useCelebrate();
  const { profile } = useSession();
  const map = useRef<MapView>(null);
  const [s, setS] = useState<RunState | null>(null);
  const [now, setNow] = useState(Date.now());
  const [fix, setFix] = useState<{ lat: number; lng: number; acc: number } | null>(null);
  const [perm, setPerm] = useState<'unknown' | 'background' | 'foreground' | 'denied'>('unknown');
  const [saving, setSaving] = useState(false);
  const [weight, setWeight] = useState<number>(Number(profile?.start_weight_kg ?? 75));

  useEffect(() => {
    restoreRun().catch(() => {});
    const off = subscribe((x) => setS({ ...x, segments: x.segments }));
    fetchTrend(60).then((t) => t.length && setWeight(t[t.length - 1].trend)).catch(() => {});
    const tick = setInterval(() => setNow(Date.now()), 1000);
    return () => {
      off();
      clearInterval(tick);
    };
  }, []);

  // Before starting: show where you are and how good the GPS signal is.
  useEffect(() => {
    let sub: Location.LocationSubscription | null = null;
    (async () => {
      const cur = await Location.getForegroundPermissionsAsync();
      if (cur.status !== 'granted') return;
      sub = await Location.watchPositionAsync({ accuracy: Location.Accuracy.BestForNavigation, distanceInterval: 2 }, (l) =>
        setFix({ lat: l.coords.latitude, lng: l.coords.longitude, acc: l.coords.accuracy ?? 99 }),
      );
    })();
    return () => sub?.remove();
  }, [perm]);

  useEffect(() => {
    if (s && s.status !== 'idle') activateKeepAwakeAsync('run').catch(() => {});
    else deactivateKeepAwake('run').catch(() => {});
  }, [s?.status]);

  const status = s?.status ?? 'idle';
  const dist = s ? distanceM(s.segments) : 0;
  const ms = s ? movingMs(s, now) : 0;
  const avgPace = dist > 20 ? ms / 1000 / (dist / 1000) : null;
  const pace = s ? currentPace(s.segments) : null;
  const last = s?.segments.flat().at(-1);

  useEffect(() => {
    const at = last ?? fix;
    if (at) map.current?.animateCamera({ center: { latitude: at.lat, longitude: at.lng }, zoom: 16, altitude: 900 }, { duration: 600 });
  }, [last?.t, fix?.lat]);

  const start = async () => {
    const p = await requestRunPermission();
    setPerm(p);
    if (p === 'denied') {
      Alert.alert(L('Location needed', 'نحتاج الموقع'), L('Allow location for Habibi Gains to record your route.', 'اسمح بالموقع عشان نسجل مسارك.'), [
        { text: L('Cancel', 'إلغاء'), style: 'cancel' },
        { text: L('Open Settings', 'الإعدادات'), onPress: () => Linking.openSettings() },
      ]);
      return;
    }
    if (p === 'foreground') {
      Alert.alert(
        L('Keep the app open', 'خل التطبيق مفتوح'),
        L('Location is set to "While Using". The run records while the app is open. For locked-screen tracking choose "Always" in Settings → Habibi Gains → Location.', 'الموقع مضبوط على "أثناء الاستخدام". للتسجيل والشاشة مقفلة اختر "دائماً" من الإعدادات.'),
      );
    }
    press();
    await startRun(p === 'background');
  };

  const finish = async () => {
    if (!s) return;
    if (dist < 50) {
      Alert.alert(L('Run too short', 'الجري قصير'), L('Less than 50 m recorded. Discard it?', 'أقل من ٥٠ متر. تحذفه؟'), [
        { text: L('Keep running', 'كمّل'), style: 'cancel' },
        { text: L('Discard', 'احذف'), style: 'destructive', onPress: async () => { await discardRun(); router.back(); } },
      ]);
      return;
    }
    setSaving(true);
    try {
      // Save first; only stop and clear the recording once the run is safely stored.
      pauseRun();
      const done = getRunState();
      const d = distanceM(done.segments);
      const mov = Math.round(movingMs(done) / 1000);
      const saved = await saveRun({
        title: null,
        started_at: new Date(done.startedAt ?? Date.now()).toISOString(),
        ended_at: new Date().toISOString(),
        moving_s: mov,
        elapsed_s: Math.round((Date.now() - (done.startedAt ?? Date.now())) / 1000),
        distance_m: Math.round(d),
        kcal: runKcal(d, weight),
        elev_gain_m: elevationGain(done.segments),
        route: simplify(done.segments),
        splits: splits(done.segments),
      });
      await finishRun();
      success();
      const badges: [string, string, string][] = [
        ['first-gps-run', 'First Steps', 'أول خطوات'],
        ...(d >= 5000 ? [['run-5k', '5K Club', 'نادي ٥ كم'] as [string, string, string]] : []),
        ...(d >= 10000 ? [['run-10k', 'Double Digits', 'عشرة كيلو'] as [string, string, string]] : []),
      ];
      router.replace({ pathname: '/run/[id]', params: { id: saved.id } });
      for (const [id, en, ar] of badges) {
        if (await awardBadge(id).catch(() => false)) {
          setTimeout(() => celebrate({ title: L(en, ar), icon: 'run' }), 500);
          break;
        }
      }
    } catch {
      warn();
      Alert.alert(L('Could not save the run', 'ما قدرنا نحفظ الجري'), L('Your run is kept on this phone. Check your connection and tap Finish again.', 'الجري محفوظ في الجوال. تأكد من الاتصال واضغط إنهاء مرة ثانية.'));
    } finally {
      setSaving(false);
    }
  };

  const quit = () => {
    if (status === 'idle') return router.back();
    Alert.alert(L('Discard this run?', 'تحذف الجري؟'), undefined, [
      { text: L('Cancel', 'إلغاء'), style: 'cancel' },
      { text: L('Discard', 'احذف'), style: 'destructive', onPress: async () => { await discardRun(); router.back(); } },
    ]);
  };

  // Hold-to-finish so a pocket tap can't end the run.
  const hold = useSharedValue(0);
  const holdTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const holdStyle = useAnimatedStyle(() => ({ width: `${hold.value * 100}%` }));
  const startHold = () => {
    hold.value = withTiming(1, { duration: 900, easing: Easing.linear });
    holdTimer.current = setTimeout(() => {
      hold.value = 0;
      finish();
    }, 900);
  };
  const cancelHold = () => {
    if (holdTimer.current) clearTimeout(holdTimer.current);
    holdTimer.current = null;
    hold.value = withTiming(0, { duration: 150 });
  };

  const gpsLabel = !fix ? L('Finding GPS…', 'جاري البحث عن GPS…') : fix.acc <= 15 ? L('GPS strong', 'GPS قوي') : fix.acc <= 35 ? L('GPS okay', 'GPS مقبول') : L('GPS weak: step outside', 'GPS ضعيف: اطلع برا');
  const gpsColor = !fix ? theme.muted : fix.acc <= 15 ? '#4CD964' : fix.acc <= 35 ? '#FFCC00' : theme.danger;

  const big = (label: string, value: string, size = 40) => (
    <View style={{ flex: 1, gap: 2 }}>
      <Txt v="label" muted>{label}</Txt>
      <Txt v="hero" style={{ fontSize: size, lineHeight: size + 4 }}>{value}</Txt>
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: theme.bg }}>
      <MapView
        ref={map}
        style={StyleSheet.absoluteFill}
        showsUserLocation
        showsMyLocationButton={false}
        showsCompass={false}
        userInterfaceStyle="dark"
        initialCamera={{ center: { latitude: 24.4539, longitude: 54.3773 }, zoom: 13, altitude: 12000, heading: 0, pitch: 0 }}
      >
        {(s?.segments ?? []).filter((seg) => seg.length > 1).map((seg, i) => (
          <Polyline key={i} coordinates={seg.map((p) => ({ latitude: p.lat, longitude: p.lng }))} strokeColor={theme.accent} strokeWidth={5} lineCap="round" lineJoin="round" />
        ))}
      </MapView>

      <Row style={{ position: 'absolute', top: insets.top + 10, left: 16, right: 16, justifyContent: 'space-between' }}>
        <Press onPress={quit} style={pill(theme)}>
          <Icon name="close" size={18} />
        </Press>
        <View style={[pill(theme), { flexDirection: 'row', gap: 8, paddingHorizontal: 14, width: undefined }]}>
          <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: status === 'idle' ? gpsColor : status === 'paused' ? '#FFCC00' : '#4CD964' }} />
          <Txt v="bodyStrong" style={{ fontSize: 13 }}>
            {status === 'idle' ? gpsLabel : status === 'paused' ? L('Paused', 'متوقف') : s?.background ? L('Recording · lock screen OK', 'يسجل · تقدر تقفل الشاشة') : L('Recording · keep app open', 'يسجل · خل التطبيق مفتوح')}
          </Txt>
        </View>
      </Row>

      <Animated.View
        entering={FadeInDown.springify()}
        style={{ position: 'absolute', left: 0, right: 0, bottom: 0, backgroundColor: theme.surface, borderTopLeftRadius: 30, borderTopRightRadius: 30, padding: 22, paddingBottom: insets.bottom + 18, gap: 18 }}
      >
        <Row>
          {big(L('Time', 'الوقت'), formatDuration(ms))}
          {big(L('Distance km', 'المسافة كم'), formatKm(dist))}
        </Row>
        <Row>
          {big(L('Pace /km', 'السرعة /كم'), formatPace(pace), 28)}
          {big(L('Avg pace', 'المعدل'), formatPace(avgPace), 28)}
        </Row>

        {status === 'idle' ? (
          <Animated.View entering={FadeIn} style={{ gap: 10 }}>
            <Button title={L('Start', 'ابدأ')} icon={<Icon name="run" color={theme.onAccent} />} onPress={start} />
            <Txt v="small" faint center>{L('Tip: wait for "GPS strong" for the most accurate distance.', 'نصيحة: انتظر "GPS قوي" لأدق مسافة.')}</Txt>
          </Animated.View>
        ) : (
          <Row gap={12}>
            {status === 'running' ? (
              <Button style={{ flex: 1 }} kind="secondary" title={L('Pause', 'إيقاف مؤقت')} onPress={() => { press(); pauseRun(); }} />
            ) : (
              <Button style={{ flex: 1 }} title={L('Resume', 'كمّل')} onPress={() => { press(); resumeRun(); }} />
            )}
            <Press
              haptic={false}
              onPressIn={startHold}
              onPressOut={cancelHold}
              disabled={saving}
              style={{ flex: 1, height: 56, borderRadius: 28, backgroundColor: theme.cardHigh, overflow: 'hidden', alignItems: 'center', justifyContent: 'center' }}
            >
              <Animated.View style={[{ position: 'absolute', left: 0, top: 0, bottom: 0, backgroundColor: theme.danger }, holdStyle]} />
              <Txt v="bodyStrong">{saving ? L('Saving…', 'جاري الحفظ…') : L('Hold to finish', 'اضغط مطولاً للإنهاء')}</Txt>
            </Press>
          </Row>
        )}
      </Animated.View>
    </View>
  );
}

const pill = (theme: { surface: string }) => ({
  height: 40,
  width: 40,
  borderRadius: 20,
  backgroundColor: theme.surface,
  alignItems: 'center' as const,
  justifyContent: 'center' as const,
});
