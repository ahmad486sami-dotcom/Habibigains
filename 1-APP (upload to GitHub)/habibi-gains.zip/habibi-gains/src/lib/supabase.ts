import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';
import { AppState } from 'react-native';

// The publishable key is safe to ship in the app: every table is protected by row level security.
const url = process.env.EXPO_PUBLIC_SUPABASE_URL || 'https://ekeybuzzxyzyuwczqnrz.supabase.co';
const anonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || 'sb_publishable_EXuzbg-O8Gc6yGmFSwG73Q_1IKL3HUi';
export const SUPABASE_URL = url;
export const SUPABASE_KEY = anonKey;

export const isConfigured = url.startsWith('https://') && anonKey.length > 20;

export const supabase = createClient(url || 'https://placeholder.supabase.co', anonKey || 'placeholder', {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

// Keep the session fresh only while the app is in the foreground.
AppState.addEventListener('change', (state) => {
  if (state === 'active') supabase.auth.startAutoRefresh();
  else supabase.auth.stopAutoRefresh();
});

export function todayISO(d = new Date()) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export async function uploadImage(bucket: 'progress' | 'quests', userId: string, uri: string) {
  const path = `${userId}/${Date.now()}.jpg`;
  const res = await fetch(uri);
  const body = await res.arrayBuffer();
  const { error } = await supabase.storage.from(bucket).upload(path, body, { contentType: 'image/jpeg', upsert: false });
  if (error) throw error;
  return path;
}

export async function signedUrl(bucket: 'progress' | 'quests', path: string) {
  if (path.startsWith('file:') || path.startsWith('ph:') || path.startsWith('http')) return path; // showcase/local
  const { data } = await supabase.storage.from(bucket).createSignedUrl(path, 60 * 60);
  return data?.signedUrl ?? null;
}
