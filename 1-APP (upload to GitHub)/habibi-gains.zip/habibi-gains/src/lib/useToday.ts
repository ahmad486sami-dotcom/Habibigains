// Everything the Today and Progress screens need, loaded together and refreshed on focus.
import { useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';
import { fetchDailyTotals, fetchDayLogs, fetchTrend, FoodLog } from './data';
import { measuredTDEE, paceCheck, sumDay, calcTargets } from './nutrition';
import { Profile } from './session';
import { predictGoalDate, slopePerDay, TrendPoint, weeklyRatePct } from './trend';

export function useToday(profile: Profile | null) {
  const [logs, setLogs] = useState<FoodLog[]>([]);
  const [trend, setTrend] = useState<TrendPoint[]>([]);
  const [measured, setMeasured] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [daily, setDaily] = useState<{ day: string; kcal: number }[]>([]);

  const load = useCallback(async () => {
    try {
      const [l, tr, totals] = await Promise.all([fetchDayLogs(), fetchTrend(), fetchDailyTotals(30)]);
      setLogs(l);
      setDaily(totals);
      setTrend(tr);
      const recent = tr.filter((p) => +new Date(p.date) > Date.now() - 30 * 86_400_000);
      setMeasured(measuredTDEE(totals, slopePerDay(recent, 30)));
    } catch {
      // keep whatever we had
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load]),
  );

  const totals = sumDay(logs);
  const last = trend.at(-1) ?? null;
  const startWeight = profile?.start_weight_kg ?? trend[0]?.weight ?? null;
  const goalDate = predictGoalDate(trend, profile?.goal_weight_kg);
  const rate = weeklyRatePct(trend);
  const pace = paceCheck(profile?.goal ?? 'maintain', rate);

  // When measured metabolism is available, show what the target would become.
  const suggested =
    measured && profile?.sex && profile.birth_year && profile.height_cm && last
      ? calcTargets({
          sex: profile.sex,
          birthYear: profile.birth_year,
          heightCm: Number(profile.height_cm),
          weightKg: last.trend,
          goal: profile.goal,
          activity: profile.activity,
          measuredTDEE: measured,
        })
      : null;

  return {
    loading,
    reload: load,
    logs,
    daily,
    totals,
    trend,
    last,
    startWeight,
    goalDate,
    rate,
    pace,
    measured,
    suggested,
  };
}
