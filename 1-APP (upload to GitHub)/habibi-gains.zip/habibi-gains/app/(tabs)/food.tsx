// Food diary: any day, meal by meal, with water and a link to full nutrition.
import { router, useFocusEffect } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { ActionSheetIOS, Alert, Platform, View } from 'react-native';
import Animated, { FadeIn, FadeInDown, LinearTransition, ZoomOut } from 'react-native-reanimated';
import { useI18n } from '@/i18n/i18n';
import { copyMeal, deleteFoodLog, fetchDayLogs, FoodLog, getWater, Meal, setWater, sumNutrients } from '@/lib/data';
import { dayLabel, macroTargets, MEAL_LABEL, mealsFor, servingText, shiftDay } from '@/lib/day';
import { select, success, warn } from '@/lib/haptics';
import { useSession } from '@/lib/session';
import { todayISO } from '@/lib/supabase';
import { useTheme } from '@/theme/theme';
import { Bar, Ticker } from '@/ui/Graphics';
import { Icon } from '@/ui/Icon';
import { Card, Row, Screen } from '@/ui/Layout';
import { Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

const GLASS = 250;

export default function Diary() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { profile } = useSession();
  const [day, setDay] = useState(todayISO());
  const [logs, setLogs] = useState<FoodLog[]>([]);
  const [water, setWaterState] = useState(0);
  const [loaded, setLoaded] = useState(false);

  const target = profile?.calorie_target ?? 2000;
  const goals = macroTargets(target, profile?.protein_target_g ?? 140);
  const waterGoal = profile?.water_goal_ml ?? 3000;
  const totals = sumNutrients(logs);
  const remaining = target - totals.kcal;

  const load = useCallback(async (d: string) => {
    const [l, w] = await Promise.all([fetchDayLogs(d).catch(() => [] as FoodLog[]), getWater(d).catch(() => 0)]);
    setLogs(l);
    setWaterState(w);
    setLoaded(true);
  }, []);

  useFocusEffect(
    useCallback(() => {
      load(day);
    }, [load, day]),
  );

  const go = (by: number) => {
    select();
    const next = shiftDay(day, by);
    setDay(next);
    load(next);
  };

  const addWater = async (delta: number) => {
    select();
    const next = Math.max(0, water + delta);
    setWaterState(next);
    await setWater(next, day).catch(() => warn());
  };

  const remove = (log: FoodLog) =>
    Alert.alert(log.name, L('Remove from your diary?', 'تحذفه من اليوميات؟'), [
      { text: L('Cancel', 'إلغاء'), style: 'cancel' },
      {
        text: L('Remove', 'حذف'),
        style: 'destructive',
        onPress: async () => {
          warn();
          setLogs((ls) => ls.filter((x) => x.id !== log.id));
          await deleteFoodLog(log.id).catch(() => load(day));
        },
      },
    ]);

  const copyFromYesterday = async (meal?: Meal) => {
    try {
      const n = await copyMeal(shiftDay(day, -1), day, meal);
      if (n) success();
      else Alert.alert(L('Nothing to copy', 'ما في شي للنسخ'), L('Yesterday has no food logged for this.', 'ما في أكل مسجل أمس.'));
      load(day);
    } catch {
      warn();
    }
  };

  const mealMenu = (meal: Meal) => {
    const options = [L('Quick add calories', 'إضافة سريعة للسعرات'), L("Copy yesterday's", 'نسخ من أمس'), L('Cancel', 'إلغاء')];
    const pick = (i: number) => {
      if (i === 0) router.push({ pathname: '/food/quick', params: { meal, day } });
      if (i === 1) copyFromYesterday(meal);
    };
    if (Platform.OS === 'ios') ActionSheetIOS.showActionSheetWithOptions({ options, cancelButtonIndex: 2, title: L(MEAL_LABEL[meal].en, MEAL_LABEL[meal].ar) }, pick);
    else Alert.alert(L(MEAL_LABEL[meal].en, MEAL_LABEL[meal].ar), undefined, [{ text: options[0], onPress: () => pick(0) }, { text: options[1], onPress: () => pick(1) }, { text: options[2], style: 'cancel' }]);
  };

  const macro = (label: string, value: number, goal: number) => (
    <View style={{ flex: 1, gap: 6 }}>
      <Txt v="small" muted>{label}</Txt>
      <Txt v="bodyStrong">{`${Math.round(value)}/${goal}g`}</Txt>
      <Bar progress={goal ? value / goal : 0} color={value > goal * 1.1 ? theme.danger : undefined} />
    </View>
  );

  return (
    <Screen>
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="h1">{L('Diary', 'اليوميات')}</Txt>
        <Press onPress={() => router.push({ pathname: '/food/nutrition', params: { day } })} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: theme.card, borderRadius: 999, paddingHorizontal: 14, height: 38 }}>
          <Icon name="chart" size={16} />
          <Txt v="bodyStrong" style={{ fontSize: 14 }}>{L('Nutrition', 'التغذية')}</Txt>
        </Press>
      </Row>

      {/* date switcher */}
      <Row style={{ justifyContent: 'space-between', backgroundColor: theme.card, borderRadius: 999, height: 48, paddingHorizontal: 6 }}>
        <Press onPress={() => go(-1)} haptic={false} style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center', transform: [{ scaleX: -1 }] }}>
          <Icon name="chevron" />
        </Press>
        <Press onPress={() => { setDay(todayISO()); load(todayISO()); }} haptic={false}>
          <Txt v="bodyStrong">{dayLabel(day, lang)}</Txt>
        </Press>
        <Press onPress={() => go(1)} haptic={false} style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="chevron" />
        </Press>
      </Row>

      {/* goal − food = remaining */}
      <Card index={0}>
        <Row style={{ justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <View style={{ alignItems: 'center' }}>
            <Txt v="h3">{target.toLocaleString('en-US')}</Txt>
            <Txt v="small" muted>{L('Goal', 'الهدف')}</Txt>
          </View>
          <Txt v="h3" muted>−</Txt>
          <View style={{ alignItems: 'center' }}>
            <Txt v="h3">{totals.kcal.toLocaleString('en-US')}</Txt>
            <Txt v="small" muted>{L('Food', 'الأكل')}</Txt>
          </View>
          <Txt v="h3" muted>=</Txt>
          <View style={{ alignItems: 'center' }}>
            <Ticker value={remaining} v="h2" />
            <Txt v="small" color={remaining < 0 ? theme.danger : theme.muted}>{remaining < 0 ? L('Over', 'زيادة') : L('Remaining', 'المتبقي')}</Txt>
          </View>
        </Row>
        <Bar progress={totals.kcal / target} height={8} color={remaining < 0 ? theme.danger : undefined} />
        <Row gap={14} style={{ marginTop: 4 }}>
          {macro(L('Protein', 'بروتين'), totals.protein_g, goals.protein)}
          {macro(L('Carbs', 'كارب'), totals.carbs_g, goals.carbs)}
          {macro(L('Fat', 'دهون'), totals.fat_g, goals.fat)}
        </Row>
      </Card>

      {/* search */}
      <Row gap={10}>
        <Press
          onPress={() => router.push({ pathname: '/add-food', params: { day } })}
          style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: theme.card, borderRadius: 999, height: 54, paddingHorizontal: 18 }}
        >
          <Icon name="search" color={theme.muted} size={20} />
          <Txt muted numberOfLines={1} style={{ flex: 1 }}>{L('Search 8,000+ foods', 'ابحث في ٨٠٠٠+ أكلة')}</Txt>
        </Press>
        <Press
          onPress={() => router.push({ pathname: '/scan', params: { day } })}
          accessibilityLabel={L('Scan barcode', 'مسح الباركود')}
          style={{ width: 54, height: 54, borderRadius: 27, backgroundColor: theme.accent, alignItems: 'center', justifyContent: 'center' }}
        >
          <Icon name="scan" color={theme.onAccent} />
        </Press>
      </Row>

      {/* meals */}
      {mealsFor(!!profile?.ramadan_mode).map((meal, mi) => {
        const items = logs.filter((l) => l.meal === meal);
        const kcal = Math.round(items.reduce((s, l) => s + l.kcal, 0));
        return (
          <Animated.View key={meal} entering={FadeInDown.delay(mi * 50).springify()} layout={LinearTransition.springify()}>
            <View style={{ backgroundColor: theme.card, borderRadius: 24, padding: 16, gap: 4 }}>
              <Row style={{ justifyContent: 'space-between' }}>
                <Txt v="h3">{L(MEAL_LABEL[meal].en, MEAL_LABEL[meal].ar)}</Txt>
                <Row gap={8}>
                  {kcal > 0 ? <Txt v="bodyStrong">{kcal}</Txt> : null}
                  <Press onPress={() => mealMenu(meal)} accessibilityLabel={L('More', 'المزيد')} style={{ width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' }}>
                    <Txt v="h3" muted>···</Txt>
                  </Press>
                </Row>
              </Row>
              {items.map((l) => (
                <Animated.View key={l.id} exiting={ZoomOut.duration(180)} layout={LinearTransition}>
                  <Press
                    onPress={() => router.push({ pathname: '/food/[id]', params: { id: l.food_id ?? 'log', logId: l.id } })}
                    onLongPress={() => remove(l)}
                    haptic={false}
                    scaleTo={0.98}
                    style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 9 }}
                  >
                    <View style={{ flex: 1, paddingEnd: 12 }}>
                      <Txt numberOfLines={1}>{l.name}</Txt>
                      <Txt v="small" faint numberOfLines={1}>{[l.brand, servingText(l.quantity, l.serving_label)].filter(Boolean).join(' · ')}</Txt>
                    </View>
                    <Txt v="bodyStrong">{Math.round(l.kcal)}</Txt>
                  </Press>
                </Animated.View>
              ))}
              <Press
                onPress={() => router.push({ pathname: '/add-food', params: { meal, day } })}
                style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 8 }}
              >
                <Icon name="plus" size={16} color={theme.accent} />
                <Txt v="bodyStrong" color={theme.accent}>{L('Add food', 'أضف أكل')}</Txt>
              </Press>
            </View>
          </Animated.View>
        );
      })}

      {loaded && logs.length === 0 ? (
        <Press onPress={() => copyFromYesterday()} style={{ alignSelf: 'center', padding: 8 }}>
          <Txt v="small" muted>{L("Copy all of yesterday's food", 'انسخ كل أكل أمس')}</Txt>
        </Press>
      ) : null}

      {/* water */}
      <Animated.View entering={FadeIn.delay(200)}>
        <View style={{ backgroundColor: theme.card, borderRadius: 24, padding: 16, gap: 12 }}>
          <Row style={{ justifyContent: 'space-between' }}>
            <Txt v="h3">{L('Water', 'الماء')}</Txt>
            <Txt v="bodyStrong">{`${(water / 1000).toFixed(2)} / ${(waterGoal / 1000).toFixed(1)} L`}</Txt>
          </Row>
          <Row gap={6} style={{ flexWrap: 'wrap' }}>
            {Array.from({ length: Math.max(8, Math.ceil(waterGoal / GLASS)) }).map((_, i) => {
              const full = water >= (i + 1) * GLASS;
              return (
                <Press key={i} haptic={false} onPress={() => addWater(full ? -GLASS : GLASS)} style={{ width: 28, height: 36, borderRadius: 8, borderWidth: 2, borderColor: full ? theme.accent : theme.border, backgroundColor: full ? theme.accentSoft : 'transparent' }} />
              );
            })}
          </Row>
          <Row gap={10}>
            {[GLASS, 500].map((ml) => (
              <Press key={ml} onPress={() => addWater(ml)} style={{ flex: 1, height: 42, borderRadius: 21, backgroundColor: theme.cardHigh, alignItems: 'center', justifyContent: 'center' }}>
                <Txt v="bodyStrong">{`+${ml} ml`}</Txt>
              </Press>
            ))}
            <Press onPress={() => addWater(-GLASS)} disabled={water <= 0} style={{ width: 64, height: 42, borderRadius: 21, backgroundColor: theme.cardHigh, alignItems: 'center', justifyContent: 'center', opacity: water <= 0 ? 0.4 : 1 }}>
              <Txt v="bodyStrong">−</Txt>
            </Press>
          </Row>
        </View>
      </Animated.View>

      <Txt v="small" faint center>{L('Tap a food to edit it. Hold to remove.', 'اضغط على الأكل للتعديل. اضغط مطولاً للحذف.')}</Txt>
    </Screen>
  );
}
