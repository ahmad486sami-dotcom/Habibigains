import { router } from 'expo-router';
import * as WebBrowser from 'expo-web-browser';
import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, View } from 'react-native';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useI18n } from '@/i18n/i18n';
import { AuthError, signInWithPassword, signUpWithPassword } from '@/lib/auth';
import { LEGAL_URL } from '@/lib/config';
import { success, warn } from '@/lib/haptics';
import { useTheme } from '@/theme/theme';
import { Logo } from '@/ui/Graphics';
import { Chips, Field } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function SignIn() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const [mode, setMode] = useState<'create' | 'signin'>('create');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const emailOk = /^\S+@\S+\.\S+$/.test(email.trim());
  const ready = emailOk && password.length >= 8 && (mode === 'signin' || name.trim().length > 0);

  const messages: Record<AuthError['code'], string> = {
    email_taken: L('That email already has an account. Sign in instead.', 'هذا الإيميل عنده حساب. سجّل دخول بدلاً من ذلك.'),
    invalid_email: L('Please check your email.', 'تأكد من الإيميل.'),
    weak_password: L('Password needs at least 8 characters.', 'كلمة المرور لازم ٨ أحرف على الأقل.'),
    wrong_password: L('Email or password is wrong.', 'الإيميل أو كلمة المرور غلط.'),
    network: L('No connection. Check your internet and try again.', 'ما في اتصال. تأكد من الإنترنت وحاول مرة ثانية.'),
    failed: L('Something went wrong. Please try again.', 'صار خطأ. حاول مرة ثانية.'),
  };

  const submit = async () => {
    setBusy(true);
    setError('');
    try {
      if (mode === 'create') await signUpWithPassword(name, email, password);
      else await signInWithPassword(email, password);
      success();
      router.replace('/');
    } catch (e) {
      warn();
      const code = e instanceof AuthError ? e.code : 'failed';
      setError(messages[code]);
      if (code === 'email_taken') setMode('signin');
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: theme.bg }}>
      <ScrollView
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ flexGrow: 1, paddingTop: insets.top + 36, paddingBottom: insets.bottom + 24, paddingHorizontal: 24, gap: 22 }}
      >
        <Animated.View entering={FadeInDown.springify()} style={{ gap: 18 }}>
          <Logo width={104} />
          <Txt v="hero">{mode === 'create' ? L('Create your account', 'أنشئ حسابك') : L('Welcome back', 'أهلاً من جديد')}</Txt>
        </Animated.View>

        <Chips
          value={mode}
          onChange={(m) => {
            setMode(m);
            setError('');
          }}
          options={[
            { value: 'create', label: L('New account', 'حساب جديد') },
            { value: 'signin', label: L('Sign in', 'تسجيل دخول') },
          ]}
        />

        <View style={{ gap: 12 }}>
          {mode === 'create' ? (
            <Animated.View entering={FadeIn}>
              <Field label={L('Name', 'الاسم')} value={name} onChangeText={setName} placeholder={L('Your first name', 'اسمك')} autoComplete="name" textContentType="givenName" maxLength={60} />
            </Animated.View>
          ) : null}
          <Field
            label={L('Email', 'الإيميل')}
            value={email}
            onChangeText={setEmail}
            placeholder="you@email.com"
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            autoComplete="email"
            textContentType="emailAddress"
          />
          <View>
            <Field
              label={L('Password', 'كلمة المرور')}
              value={password}
              onChangeText={setPassword}
              placeholder={L('At least 8 characters', '٨ أحرف على الأقل')}
              secureTextEntry={!show}
              autoCapitalize="none"
              autoCorrect={false}
              autoComplete={mode === 'create' ? 'new-password' : 'current-password'}
              textContentType={mode === 'create' ? 'newPassword' : 'password'}
              onSubmitEditing={() => ready && submit()}
            />
            <Press onPress={() => setShow(!show)} style={{ position: 'absolute', right: 14, bottom: 16, padding: 4 }}>
              <Txt v="small" muted>{show ? L('Hide', 'إخفاء') : L('Show', 'إظهار')}</Txt>
            </Press>
          </View>
          {error ? (
            <Animated.View entering={FadeIn}>
              <Txt color={theme.danger}>{error}</Txt>
            </Animated.View>
          ) : null}
        </View>

        <View style={{ flex: 1 }} />

        <View style={{ gap: 12 }}>
          <Button title={mode === 'create' ? L('Create account', 'إنشاء الحساب') : L('Sign in', 'دخول')} disabled={!ready} loading={busy} onPress={submit} />
          <Press onPress={() => WebBrowser.openBrowserAsync(`${LEGAL_URL}/terms`)} style={{ paddingTop: 4 }}>
            <Txt v="small" faint center>
              {L('By continuing you agree to the Terms and Privacy Policy.', 'بالمتابعة أنت توافق على الشروط وسياسة الخصوصية.')}
            </Txt>
          </Press>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
