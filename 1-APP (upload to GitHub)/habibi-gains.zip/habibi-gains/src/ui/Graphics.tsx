import React, { useEffect, useMemo, useState } from 'react';
import { View } from 'react-native';
import Animated, {
  Easing,
  useAnimatedProps,
  useSharedValue,
  withDelay,
  withTiming,
} from 'react-native-reanimated';
import Svg, { Circle, Defs, LinearGradient, Path, Rect, Stop } from 'react-native-svg';
import { useTheme } from '@/theme/theme';
import { Txt } from './Txt';

const ACircle = Animated.createAnimatedComponent(Circle);
const APath = Animated.createAnimatedComponent(Path);

/** The happy dumbbell. */
export function Logo({ width = 80, color }: { width?: number; color?: string }) {
  const { theme } = useTheme();
  const c = color ?? theme.text;
  return (
    <Svg width={width} height={width / 2} viewBox="0 0 400 200">
      <Rect x={20} y={62} width={38} height={76} rx={19} fill={c} />
      <Rect x={70} y={30} width={46} height={140} rx={23} fill={c} />
      <Rect x={284} y={30} width={46} height={140} rx={23} fill={c} />
      <Rect x={342} y={62} width={38} height={76} rx={19} fill={c} />
      <Path d="M116 92 Q200 152 284 92" fill="none" stroke={c} strokeWidth={34} strokeLinecap="round" />
    </Svg>
  );
}

/** Ring that fills smoothly from empty. progress 0..1 (can exceed 1). */
export function Ring({
  size = 150,
  stroke = 16,
  progress,
  color,
  children,
}: {
  size?: number;
  stroke?: number;
  progress: number;
  color?: string;
  children?: React.ReactNode;
}) {
  const { theme } = useTheme();
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const p = useSharedValue(0);
  useEffect(() => {
    p.value = withDelay(150, withTiming(Math.min(1, Math.max(0, progress)), { duration: 1100, easing: Easing.out(Easing.cubic) }));
  }, [progress, p]);
  const animatedProps = useAnimatedProps(() => ({ strokeDashoffset: circ * (1 - p.value) }));
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={size} style={{ position: 'absolute', transform: [{ rotate: '-90deg' }] }}>
        <Circle cx={size / 2} cy={size / 2} r={r} stroke={theme.cardHigh} strokeWidth={stroke} fill="none" />
        <ACircle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={progress > 1 ? theme.danger : color ?? theme.accent}
          strokeWidth={stroke}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={`${circ} ${circ}`}
          animatedProps={animatedProps}
        />
      </Svg>
      {children}
    </View>
  );
}

/** Line chart that draws itself in. Dots = daily weigh-ins, line = trend. */
export function TrendChart({
  points,
  width,
  height = 120,
  showDots = true,
}: {
  points: { weight: number; trend: number }[];
  width: number;
  height?: number;
  showDots?: boolean;
}) {
  const { theme } = useTheme();
  const { line, area, dots, length } = useMemo(() => {
    if (points.length < 2) return { line: '', area: '', dots: [] as { x: number; y: number }[], length: 0 };
    const vals = points.flatMap((p) => [p.weight, p.trend]);
    const min = Math.min(...vals) - 0.3;
    const max = Math.max(...vals) + 0.3;
    const pad = 6;
    const x = (i: number) => pad + (i / (points.length - 1)) * (width - pad * 2);
    const y = (v: number) => pad + (1 - (v - min) / (max - min || 1)) * (height - pad * 2);
    let d = `M ${x(0)} ${y(points[0].trend)}`;
    let len = 0;
    for (let i = 1; i < points.length; i++) {
      d += ` L ${x(i)} ${y(points[i].trend)}`;
      len += Math.hypot(x(i) - x(i - 1), y(points[i].trend) - y(points[i - 1].trend));
    }
    const a = `${d} L ${x(points.length - 1)} ${height} L ${x(0)} ${height} Z`;
    return { line: d, area: a, dots: points.map((p, i) => ({ x: x(i), y: y(p.weight) })), length: len };
  }, [points, width, height]);

  const t = useSharedValue(0);
  useEffect(() => {
    t.value = 0;
    t.value = withTiming(1, { duration: 1400, easing: Easing.inOut(Easing.cubic) });
  }, [line, t]);
  const lineProps = useAnimatedProps(() => ({ strokeDashoffset: length * (1 - t.value) }));

  if (!line) return <View style={{ height }} />;
  return (
    <Svg width={width} height={height}>
      <Defs>
        <LinearGradient id="fill" x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor={theme.accent} stopOpacity={0.18} />
          <Stop offset="1" stopColor={theme.accent} stopOpacity={0} />
        </LinearGradient>
      </Defs>
      <Path d={area} fill="url(#fill)" />
      {showDots && dots.map((d, i) => <Circle key={i} cx={d.x} cy={d.y} r={2.2} fill={theme.faint} />)}
      <APath
        d={line}
        stroke={theme.accent}
        strokeWidth={3}
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
        strokeDasharray={`${length} ${length}`}
        animatedProps={lineProps}
      />
    </Svg>
  );
}

/** Number that counts up/down to its new value. */
export function Ticker({
  value,
  decimals = 0,
  v = 'number',
  color,
  suffix,
}: {
  value: number;
  decimals?: number;
  v?: 'number' | 'hero' | 'h1' | 'h2' | 'h3';
  color?: string;
  suffix?: string;
}) {
  const [shown, setShown] = useState(0);
  useEffect(() => {
    let raf = 0;
    const from = shown;
    const start = Date.now();
    const dur = 900;
    const step = () => {
      const k = Math.min(1, (Date.now() - start) / dur);
      const e = 1 - Math.pow(1 - k, 3);
      setShown(from + (value - from) * e);
      if (k < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);
  const text = shown.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  return (
    <Txt v={v} color={color}>
      {text}
      {suffix ?? ''}
    </Txt>
  );
}

/** Thin progress bar that grows in. */
export function Bar({ progress, color, height = 6 }: { progress: number; color?: string; height?: number }) {
  const { theme } = useTheme();
  const w = useSharedValue(0);
  useEffect(() => {
    w.value = withDelay(200, withTiming(Math.min(1, Math.max(0, progress)), { duration: 900, easing: Easing.out(Easing.cubic) }));
  }, [progress, w]);
  const [box, setBox] = useState(0);
  const props = useAnimatedProps(() => ({ width: box * w.value }));
  const ARect = useMemo(() => Animated.createAnimatedComponent(Rect), []);
  return (
    <View onLayout={(e) => setBox(e.nativeEvent.layout.width)} style={{ height }}>
      <Svg width="100%" height={height}>
        <Rect x={0} y={0} width="100%" height={height} rx={height / 2} fill={theme.cardHigh} />
        <ARect x={0} y={0} height={height} rx={height / 2} fill={color ?? theme.accent} animatedProps={props} />
      </Svg>
    </View>
  );
}
