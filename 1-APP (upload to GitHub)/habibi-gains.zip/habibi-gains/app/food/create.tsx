// Create (or edit) your own food, entered per serving straight from the nutrition label.
import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { getFood, Nutrients, saveCustomFood } from '@/lib/data';
import { success, warn } from '@/lib/haptics';
import { useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Field, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

const EMPTY = { name: '', brand: '', serving: '1 serving', grams: '', kcal: '', protein: '', carbs: '', fat: '', fiber: '', sugar: '', sat: '', sodium: '', chol: '', potassium: '' };

export default function CreateFood() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const p = useLocalSearchParams<{ id?: string; name?: string; barcode?: string }>();
  const [f, setF] = useState({ ...EMPTY, name: p.name ?? '' });
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!p.id) return;
    getFood(p.id)
      .then((food) => {
        const s = food.servings[0];
        const k = (s?.g ?? food.base_g) / food.base_g;
        const v = (x: number | null) => (x === null || x === undefined ? '' : String(Math.round(Number(x) * k * 10) / 10));
        setF({
          name: food.name_en,
          brand: food.brand ?? '',
          serving: s?.label ?? '1 serving',
          grams: s && s.g !== 100 ? String(s.g) : '',
          kcal: v(food.kcal),
          protein: v(food.protein_g),
          carbs: v(food.carbs_g),
          fat: v(food.fat_g),
          fiber: v(food.fiber_g),
          sugar: v(food.sugar_g),
          sat: v(food.sat_fat_g),
          sodium: v(food.sodium_mg),
          chol: v(food.cholesterol_mg),
          potassium: v(food.potassium_mg),
        });
      })
      .catch(() => {});
  }, [p.id]);

  const set = (k: keyof typeof f, numeric = true) => (v: string) => setF({ ...f, [k]: numeric ? v.replace(/[^0-9.,]/g, '') : v });
  const n = (v: string) => (v.trim() === '' ? null : Math.max(0, Number(v.replace(',', '.')) || 0));
  const ok = f.name.trim().length > 0 && n(f.kcal) !== null;

  const save = async () => {
    setBusy(true);
    try {
      const per: Nutrients = {
        kcal: Math.round(n(f.kcal) ?? 0),
        protein_g: n(f.protein) ?? 0,
        carbs_g: n(f.carbs) ?? 0,
        fat_g: n(f.fat) ?? 0,
        fiber_g: n(f.fiber),
        sugar_g: n(f.sugar),
        sat_fat_g: n(f.sat),
        sodium_mg: n(f.sodium),
        cholesterol_mg: n(f.chol),
        potassium_mg: n(f.potassium),
      };
      const food = await saveCustomFood({ name_en: f.name, brand: f.brand, serving_label: f.serving, serving_g: n(f.grams), per, barcode: p.barcode ?? null }, p.id);
      success();
      if (p.id) router.back();
      else router.replace({ pathname: '/food/[id]', params: { id: food.id } });
    } catch {
      warn();
      Alert.alert(L('Could not save', 'ما قدرنا نحفظ'), L('Check your connection and try again.', 'تأكد من الاتصال وحاول مرة ثانية.'));
    } finally {
      setBusy(false);
    }
  };

  const pair = (a: [string, keyof typeof f], b: [string, keyof typeof f]) => (
    <Row gap={10}>
      <View style={{ flex: 1 }}><Field label={a[0]} keyboardType="decimal-pad" value={f[a[1]]} onChangeText={set(a[1])} /></View>
      <View style={{ flex: 1 }}><Field label={b[0]} keyboardType="decimal-pad" value={f[b[1]]} onChangeText={set(b[1])} /></View>
    </Row>
  );

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: theme.bg }}>
      <ScrollView contentContainerStyle={{ padding: 20, gap: 14, paddingBottom: 60 }} keyboardShouldPersistTaps="handled">
        <Row style={{ justifyContent: 'space-between' }}>
          <Txt v="h2">{p.id ? L('Edit food', 'تعديل الأكل') : L('Create a food', 'أضف أكل جديد')}</Txt>
          <Press onPress={() => router.back()} style={{ padding: 6 }}>
            <Icon name="close" />
          </Press>
        </Row>
        {p.barcode ? <Txt v="small" muted>{L(`Barcode ${p.barcode} will be saved with this food, so scanning it next time finds it instantly.`, `الباركود ${p.barcode} بينحفظ مع هذا الأكل.`)}</Txt> : null}
        <Field label={L('Name', 'الاسم')} value={f.name} onChangeText={set('name', false)} placeholder={L('e.g. Al Ain protein yogurt', 'مثلاً زبادي بروتين')} maxLength={160} />
        <Field label={L('Brand (optional)', 'الماركة (اختياري)')} value={f.brand} onChangeText={set('brand', false)} maxLength={80} />
        <Row gap={10}>
          <View style={{ flex: 1.4 }}><Field label={L('Serving', 'الحصة')} value={f.serving} onChangeText={set('serving', false)} placeholder="1 cup" maxLength={40} /></View>
          <View style={{ flex: 1 }}><Field label={L('Grams (optional)', 'جرام (اختياري)')} keyboardType="decimal-pad" value={f.grams} onChangeText={set('grams')} /></View>
        </Row>
        <Txt v="label" muted style={{ marginTop: 6 }}>{L('Per serving (from the label)', 'لكل حصة (من الملصق)')}</Txt>
        {pair([L('Calories', 'السعرات'), 'kcal'], [L('Protein g', 'بروتين جم'), 'protein'])}
        {pair([L('Carbs g', 'كارب جم'), 'carbs'], [L('Fat g', 'دهون جم'), 'fat'])}
        {pair([L('Fiber g', 'ألياف جم'), 'fiber'], [L('Sugar g', 'سكر جم'), 'sugar'])}
        {pair([L('Sat. fat g', 'دهون مشبعة جم'), 'sat'], [L('Sodium mg', 'صوديوم ملجم'), 'sodium'])}
        {pair([L('Cholesterol mg', 'كوليسترول ملجم'), 'chol'], [L('Potassium mg', 'بوتاسيوم ملجم'), 'potassium'])}
        <Txt v="small" faint>{L('Only calories are required. Leave anything you do not know empty.', 'السعرات بس مطلوبة. اترك الباقي فاضي إذا ما تعرفه.')}</Txt>
        <Button title={L('Save food', 'حفظ')} loading={busy} disabled={!ok} onPress={save} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
