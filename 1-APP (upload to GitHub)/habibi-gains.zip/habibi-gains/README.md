# Habibi Gains

The social fitness app built for the UAE. Track food (shawarma to salmon), see your real weight trend,
get science-based targets that adapt to your own metabolism, and join free run clubs with badges you can't buy.

One codebase, two apps:

| | **App Store version** | **Showcase version** |
|---|---|---|
| Name on phone | Habibi Gains | HG Showcase |
| Bundle ID | `com.habibigains.app` | `com.habibigains.showcase` |
| Needs internet / login | Yes (Supabase) | No: full demo account built in |
| Apple Health, payments | Yes | Simulated |
| How you get it | EAS build → TestFlight → App Store | Free GitHub build → .ipa → ESign |

---

## A. Show it on your phone tonight (free, no accounts)

You need a laptop with [Node.js 22](https://nodejs.org) and the **Expo Go** app on your iPhone.

```bash
npm install
npx expo install --fix          # aligns every package with your Expo version
EXPO_PUBLIC_DEMO=1 npx expo start
```

Scan the QR code with your iPhone camera. The showcase account opens with 60 days of data,
badges, run clubs and the smart camera (tap the **Plate / Menu / Barcode / Run QR** chips to demo it).
Apple Health and payments are off in Expo Go; everything else works.

> On Windows PowerShell use: `$env:EXPO_PUBLIC_DEMO=1; npx expo start`

## B. Get the showcase .ipa (free, for ESign)

1. Push this project to GitHub (repo can be private).
2. GitHub → **Actions** → **Showcase IPA** → **Run workflow**.
3. After ~20–30 minutes, open the run and download **HG-Showcase-ipa**.
4. Unzip, open `HG-Showcase.ipa` in ESign, sign it with your certificate, install.

The build is unsigned on purpose so ESign can sign it. If the workflow fails, open the failed step,
copy the red error and send it to me.

## C. The real app (App Store version)

### 1. Accounts
| Service | Cost | Used for |
|---|---|---|
| [Apple Developer](https://developer.apple.com/programs/) | ~AED 365 / year | TestFlight, App Store |
| [Google Play Console](https://play.google.com/console) | ~AED 92 once | Android |
| [Supabase](https://supabase.com) | Free to start | Login, database, photos |
| [RevenueCat](https://www.revenuecat.com) | Free until ~$2.5k/month revenue | Subscriptions |
| [Expo](https://expo.dev) | Free tier | Cloud builds |
| [Anthropic API](https://console.anthropic.com) | Pay per use (fils per photo) | Smart camera |

### 2. Supabase
**Database (easiest way):** Supabase dashboard → **SQL editor** → paste the whole of
`supabase/migrations/20261030000000_init.sql` → **Run**. Then paste `supabase/seed.sql` → **Run**.

**Server functions** (needs the [Supabase CLI](https://supabase.com/docs/guides/cli)):
```bash
supabase login
supabase init            # if asked to overwrite anything, answer No
supabase link --project-ref YOUR-PROJECT-REF
supabase functions deploy food-photo
supabase functions deploy delete-account
supabase functions deploy revenuecat-webhook --no-verify-jwt
supabase secrets set ANTHROPIC_API_KEY=sk-ant-...
supabase secrets set REVENUECAT_WEBHOOK_SECRET=$(openssl rand -hex 24)
```
- **Auth → Providers**: enable Email (OTP code), Apple and Google.
- **Auth → URL configuration**: add `habibigains://**` to the redirect URLs.
- **Make yourself admin**: sign up in the app, then in the SQL editor run
  `update profiles set role = 'admin' where id = 'YOUR-USER-ID';`

### 3. Keys
Copy `.env.example` to `.env` and fill in the Supabase URL + publishable key and the RevenueCat public keys.

### 4. RevenueCat
- Create products in App Store Connect / Play Console: `hg_premium_monthly` (AED 12) and `hg_premium_annual` (AED 99).
- In RevenueCat: entitlement **premium**, default offering with **monthly** and **annual** packages.
- Webhook → `https://YOUR-PROJECT.supabase.co/functions/v1/revenuecat-webhook`
  with header `Authorization: Bearer <REVENUECAT_WEBHOOK_SECRET>`.

### 5. Build & ship
```bash
npm i -g eas-cli
eas login
eas init                                  # writes your project ID into the config
eas build --profile development --platform ios   # dev build for testing Health + payments
eas build --profile production --platform ios
eas submit --platform ios --latest        # → TestFlight
```
Then invite testers in App Store Connect → TestFlight. When it's ready, submit for review.
See `docs/LAUNCH_CHECKLIST.md` before submitting.

---

## What's inside

```
app/                    Screens (Expo Router)
  (auth)/               Welcome intro, sign-in (Apple, Google, email code)
  (tabs)/               Today · Food · Progress · Train + the custom tab bar
  camera.tsx            One smart camera: plate, menu, barcode, run-club QR
  add-food, weigh-in, share, premium, settings, timing, why, tutorials, admin
  event/[id], quest/[id]
src/lib/                Logic
  nutrition.ts          Evidence-based targets + measured metabolism
  trend.ts              Smoothed weight trend, pace, goal date
  timing.ts             Timing coach (protein, carbs, creatine, caffeine, Ramadan)
  ramadan.ts            Suhoor/iftar times for every emirate, Ramadan detection
  data.ts, session.tsx  Supabase data + auth state
  demo.ts               Showcase account
src/ui/                 Animated components (ring, self-drawing chart, ticker,
                        celebration + confetti, before/after slider, share card)
src/i18n/               English + Arabic (full right-to-left)
supabase/               Database schema, seed data, server functions
docs/                   Launch checklist, privacy, terms, store listing, science
```

## The science
Every number the app shows is explained in-app ("Why this number?") with its source.
Summary in `docs/SCIENCE.md`.

## Testing notes
- The database rules were tested on a real Postgres: members can't promote themselves, check-in codes
  stay hidden from members, XP can't be farmed, women-only events are hidden from and closed to men.
- The maths (targets, trend, measured metabolism, timing coach, prayer times) was tested with real cases.
- The app code was written and type-checked without running a phone build. Expect one or two small fixes
  on the first `npx expo start`; send the error text and it's a quick fix.
