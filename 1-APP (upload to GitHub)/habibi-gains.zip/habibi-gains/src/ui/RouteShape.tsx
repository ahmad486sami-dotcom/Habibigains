// Draws a GPS route as a clean line (no map tiles), used for run thumbnails and share cards.
import React from 'react';
import Svg, { Circle, Path } from 'react-native-svg';

export function routePath(route: [number, number][], w: number, h: number, pad = 0.08) {
  if (route.length < 2) return null;
  const lat0 = route.reduce((s, p) => s + p[0], 0) / route.length;
  const k = Math.cos((lat0 * Math.PI) / 180);
  const xs = route.map((p) => p[1] * k);
  const ys = route.map((p) => -p[0]);
  const minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys), maxY = Math.max(...ys);
  const spanX = maxX - minX || 1e-9, spanY = maxY - minY || 1e-9;
  const s = Math.min((w * (1 - 2 * pad)) / spanX, (h * (1 - 2 * pad)) / spanY);
  const ox = (w - spanX * s) / 2, oy = (h - spanY * s) / 2;
  const pts = xs.map((x, i) => [ox + (x - minX) * s, oy + (ys[i] - minY) * s] as [number, number]);
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' ');
  return { d, start: pts[0], end: pts[pts.length - 1] };
}

export function RouteShape({ route, size, width, height, color, stroke = 3, dots = false }: { route: [number, number][]; size?: number; width?: number; height?: number; color: string; stroke?: number; dots?: boolean }) {
  const w = width ?? size ?? 60;
  const h = height ?? size ?? 60;
  const r = routePath(route, w, h);
  if (!r) return <Svg width={w} height={h} />;
  return (
    <Svg width={w} height={h}>
      <Path d={r.d} stroke={color} strokeWidth={stroke} fill="none" strokeLinecap="round" strokeLinejoin="round" />
      {dots ? (
        <>
          <Circle cx={r.start[0]} cy={r.start[1]} r={stroke * 1.6} fill={color} />
          <Circle cx={r.end[0]} cy={r.end[1]} r={stroke * 1.6} fill="#000" stroke={color} strokeWidth={stroke} />
        </>
      ) : null}
    </Svg>
  );
}
