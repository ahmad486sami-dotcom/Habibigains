// Round profile photo with an initial fallback, and a small stat block.
import { Image } from 'expo-image';
import React from 'react';
import { View } from 'react-native';
import { useTheme } from '@/theme/theme';
import { Txt } from './Txt';

export function Avatar({ url, name, size = 72 }: { url?: string | null; name?: string | null; size?: number }) {
  const { theme } = useTheme();
  if (url) return <Image source={{ uri: url }} style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: theme.cardHigh }} contentFit="cover" />;
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: theme.cardHigh, alignItems: 'center', justifyContent: 'center' }}>
      <Txt v={size > 50 ? 'h2' : 'bodyStrong'}>{(name ?? '?').trim().charAt(0).toUpperCase() || '?'}</Txt>
    </View>
  );
}

export function Stat({ value, label }: { value: string; label: string }) {
  return (
    <View style={{ alignItems: 'center', flex: 1 }}>
      <Txt v="h3">{value}</Txt>
      <Txt v="small" muted style={{ fontSize: 11 }}>{label}</Txt>
    </View>
  );
}

