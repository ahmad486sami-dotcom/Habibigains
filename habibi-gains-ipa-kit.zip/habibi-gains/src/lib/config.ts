// Public website that hosts the privacy policy and terms (see docs/PRIVACY.md and docs/TERMS.md).
export const LEGAL_URL = 'https://habibigains.app';
export const SUPPORT_EMAIL = 'support@habibigains.app';
