// Resize a photo to ~1024px JPEG + base64 for the smart camera.
// Uses the newer ImageManipulator API when available, the classic one otherwise.
import * as IM from 'expo-image-manipulator';

export async function toSmallJpegBase64(uri: string): Promise<string> {
  const anyIM = IM as any;
  try {
    if (anyIM.ImageManipulator?.manipulate) {
      const ctx = anyIM.ImageManipulator.manipulate(uri);
      ctx.resize({ width: 1024 });
      const img = await ctx.renderAsync();
      const out = await img.saveAsync({ compress: 0.7, format: anyIM.SaveFormat.JPEG, base64: true });
      return out.base64 ?? '';
    }
  } catch {
    // fall through to the classic API
  }
  const out = await anyIM.manipulateAsync(uri, [{ resize: { width: 1024 } }], {
    compress: 0.7,
    format: anyIM.SaveFormat.JPEG,
    base64: true,
  });
  return out.base64 ?? '';
}
