import { router } from 'expo-router';
import * as WebBrowser from 'expo-web-browser';
import React, { useEffect, useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, View } from 'react-native';
import Animated, { FadeInDown, FadeInUp } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useI18n } from '@/i18n/i18n';
import { LEGAL_URL } from '@/lib/config';
import { appleAvailable, sendEmailCode, signInWithApple, signInWithGoogle, verifyEmailCode } from '@/lib/auth';
import { success, warn } from '@/lib/haptics';
import { isConfigured } from '@/lib/supabase';
import { useTheme } from '@/theme/theme';
import { Logo } from '@/ui/Graphics';
import { Field } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function SignIn() {
  const { t } = useI18n();
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const [apple, setApple] = useState(false);
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [step, setStep] = useState<'email' | 'code'>('email');
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => {
    appleAvailable().then(setApple).catch(() => setApple(false));
  }, []);

  const run = async (key: string, fn: () => Promise<unknown>) => {
    setBusy(key);
    try {
      await fn();
    } catch (e: any) {
      warn();
      if (e?.code !== 'ERR_REQUEST_CANCELED') Alert.alert(t('error'), e?.message ?? '');
    } finally {
      setBusy(null);
    }
  };

  const done = () => {
    success();
    router.replace('/');
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: theme.bg }}>
      <View style={{ flex: 1, paddingTop: insets.top + 40, paddingBottom: insets.bottom + 20, paddingHorizontal: 24, justifyContent: 'space-between' }}>
        <Animated.View entering={FadeInDown.springify()} style={{ gap: 20 }}>
          <Logo width={110} />
          <Txt v="hero">{t('signInTitle')}</Txt>
          {!isConfigured ? <Txt muted>{t('setupNeeded')}</Txt> : null}
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(150).springify()} style={{ gap: 12 }}>
          {step === 'email' ? (
            <>
              {apple ? (
                <Button title={t('continueApple')} kind="secondary" loading={busy === 'apple'} onPress={() => run('apple', async () => { await signInWithApple(); done(); })} />
              ) : null}
              <Button
                title={t('continueGoogle')}
                kind="secondary"
                loading={busy === 'google'}
                onPress={() => run('google', async () => { if (await signInWithGoogle()) done(); })}
              />
              <Txt v="small" faint center style={{ marginVertical: 6 }}>{t('orEmail')}</Txt>
              <Field
                value={email}
                onChangeText={setEmail}
                placeholder={t('emailPlaceholder')}
                keyboardType="email-address"
                autoCapitalize="none"
                autoComplete="email"
                textContentType="emailAddress"
              />
              <Button
                title={t('sendCode')}
                disabled={!/^\S+@\S+\.\S+$/.test(email)}
                loading={busy === 'send'}
                onPress={() => run('send', async () => { await sendEmailCode(email); setStep('code'); })}
              />
            </>
          ) : (
            <>
              <Txt muted>{t('codeSent')} {email}</Txt>
              <Field
                value={code}
                onChangeText={(v) => setCode(v.replace(/\D/g, '').slice(0, 6))}
                placeholder={t('codePlaceholder')}
                keyboardType="number-pad"
                autoComplete="one-time-code"
                textContentType="oneTimeCode"
                style={{ fontSize: 26, letterSpacing: 10, textAlign: 'center' }}
              />
              <Button
                title={t('verify')}
                disabled={code.length !== 6}
                loading={busy === 'verify'}
                onPress={() => run('verify', async () => { await verifyEmailCode(email, code); done(); })}
              />
              <Press onPress={() => setStep('email')} style={{ alignSelf: 'center', padding: 8 }}>
                <Txt muted>{t('changeEmail')}</Txt>
              </Press>
            </>
          )}
          <Press onPress={() => WebBrowser.openBrowserAsync(`${LEGAL_URL}/terms`)} style={{ paddingTop: 6 }}>
            <Txt v="small" faint center>{t('legalAgree')}</Txt>
          </Press>
        </Animated.View>
      </View>
    </KeyboardAvoidingView>
  );
}
