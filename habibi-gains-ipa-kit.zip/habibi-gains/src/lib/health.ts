// Apple Health (iOS) and Health Connect (Android).
// Native modules only exist in a development / production build, not in Expo Go,
// so everything is loaded lazily and fails quietly.
import { Platform } from 'react-native';
import { IS_DEMO } from './demo';

function startOfToday() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

let iosReady = false;

async function ios(): Promise<any | null> {
  try {
    const mod = require('react-native-health');
    const HK = mod.default ?? mod;
    if (iosReady) return HK;
    const P = HK.Constants.Permissions;
    await new Promise<void>((resolve, reject) =>
      HK.initHealthKit(
        { permissions: { read: [P.StepCount, P.Weight, P.ActiveEnergyBurned, P.Workout], write: [P.Weight] } },
        (err: unknown) => (err ? reject(err) : resolve()),
      ),
    );
    iosReady = true;
    return HK;
  } catch {
    return null;
  }
}

async function android(): Promise<any | null> {
  try {
    const HC = require('react-native-health-connect');
    const ok = await HC.initialize();
    if (!ok) return null;
    return HC;
  } catch {
    return null;
  }
}

export async function connectHealth(): Promise<boolean> {
  if (IS_DEMO) return true;
  if (Platform.OS === 'ios') return (await ios()) !== null;
  if (Platform.OS === 'android') {
    const HC = await android();
    if (!HC) return false;
    try {
      await HC.requestPermission([
        { accessType: 'read', recordType: 'Steps' },
        { accessType: 'read', recordType: 'ExerciseSession' },
        { accessType: 'read', recordType: 'Weight' },
        { accessType: 'write', recordType: 'Weight' },
      ]);
      return true;
    } catch {
      return false;
    }
  }
  return false;
}

export async function getTodaySteps(): Promise<number | null> {
  if (IS_DEMO) return 8412;
  if (Platform.OS === 'ios') {
    const HK = await ios();
    if (!HK) return null;
    return new Promise((resolve) =>
      HK.getStepCount({ date: new Date().toISOString(), includeManuallyAdded: true }, (err: unknown, res: { value: number }) =>
        resolve(err ? null : Math.round(res?.value ?? 0)),
      ),
    );
  }
  if (Platform.OS === 'android') {
    const HC = await android();
    if (!HC) return null;
    try {
      const res = await HC.readRecords('Steps', {
        timeRangeFilter: { operator: 'between', startTime: startOfToday().toISOString(), endTime: new Date().toISOString() },
      });
      const records: { count: number }[] = Array.isArray(res) ? res : res?.records ?? [];
      return records.reduce((s, r) => s + (r.count ?? 0), 0);
    } catch {
      return null;
    }
  }
  return null;
}

export async function saveWeightToHealth(kg: number) {
  if (IS_DEMO) return;
  try {
    if (Platform.OS === 'ios') {
      const HK = await ios();
      if (!HK) return;
      await new Promise<void>((resolve) => HK.saveWeight({ value: kg * 2.20462, unit: 'pound' }, () => resolve()));
    } else if (Platform.OS === 'android') {
      const HC = await android();
      if (!HC) return;
      await HC.insertRecords([{ recordType: 'Weight', weight: { unit: 'kilograms', value: kg }, time: new Date().toISOString() }]);
    }
  } catch {
    // Not fatal: the weigh-in is still saved in the app.
  }
}
