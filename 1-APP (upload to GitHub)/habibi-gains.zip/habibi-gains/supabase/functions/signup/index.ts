// Supabase Edge Function: create an account with email + password, ready to use straight away.
// Accounts are created already confirmed, so testers never wait for (or get rate-limited on) emails.
// The app signs in with the same email + password right after this returns.
// Deploy: supabase functions deploy signup --no-verify-jwt

import { createClient } from 'npm:@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, apikey, x-client-info',
  'content-type': 'application/json',
};
const reply = (status: number, body: unknown) => new Response(JSON.stringify(body), { status, headers: cors });

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return reply(405, { error: 'method_not_allowed' });

  let body: { email?: string; password?: string; name?: string };
  try {
    body = await req.json();
  } catch {
    return reply(400, { error: 'bad_json' });
  }
  const email = String(body.email ?? '').trim().toLowerCase();
  const password = String(body.password ?? '');
  const name = String(body.name ?? '').trim().slice(0, 60);
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || email.length > 254) return reply(400, { error: 'invalid_email' });
  if (password.length < 8 || password.length > 72) return reply(400, { error: 'weak_password' });

  const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  const { error } = await admin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    user_metadata: name ? { full_name: name } : {},
  });
  if (error) {
    const msg = error.message.toLowerCase();
    if (msg.includes('already') || msg.includes('registered') || msg.includes('exists')) return reply(409, { error: 'email_taken' });
    return reply(500, { error: 'failed' });
  }
  return reply(200, { ok: true });
});
