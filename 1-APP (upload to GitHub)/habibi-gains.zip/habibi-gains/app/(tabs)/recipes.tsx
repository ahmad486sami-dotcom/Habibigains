// Recipes tab: the Habibi Gains library, recipes people shared, and your own (with a share switch).
import { router, useFocusEffect } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { Switch, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { Food, foodName, markCooked, myFoods, setRecipeShared, sharedRecipes } from '@/lib/data';
import { success, warn } from '@/lib/haptics';
import { CATEGORIES, RECIPES } from '@/lib/recipes';
import { useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Card, Chips, Row, Screen } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

type Tab = 'library' | 'shared' | 'mine';

const perServing = (f: Food) => {
  const n = f.recipe_servings || 1;
  const s = f.servings[0];
  const k = s ? Math.round((f.kcal * s.g) / f.base_g) : Math.round(f.kcal / n);
  const p = s ? Math.round((f.protein_g * s.g) / f.base_g) : Math.round(f.protein_g / n);
  return { k, p };
};

export default function Recipes() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const [tab, setTab] = useState<Tab>('library');
  const [cat, setCat] = useState<string>(CATEGORIES[0]);
  const [shared, setShared] = useState<Food[]>([]);
  const [mine, setMine] = useState<Food[]>([]);
  const [cooked, setCooked] = useState<Record<string, number>>({});

  useFocusEffect(
    useCallback(() => {
      sharedRecipes().then(setShared).catch(() => {});
      myFoods().then((f) => setMine(f.filter((x) => x.source === 'recipe'))).catch(() => {});
    }, []),
  );

  const toggleShare = async (f: Food, on: boolean) => {
    setMine((m) => m.map((x) => (x.id === f.id ? { ...x, is_shared: on } : x)));
    try {
      await setRecipeShared(f.id, on);
      success();
    } catch {
      warn();
      setMine((m) => m.map((x) => (x.id === f.id ? { ...x, is_shared: !on } : x)));
    }
  };

  const cook = async (f: Food) => {
    try {
      const n = await markCooked(f.id);
      setCooked((c) => ({ ...c, [f.id]: n ?? (f.cooked_count ?? 0) + 1 }));
      success();
    } catch {
      warn();
    }
  };

  return (
    <Screen>
      <Txt v="h1">{L('Recipes', 'الوصفات')}</Txt>
      <Chips
        value={tab}
        onChange={setTab}
        options={[
          { value: 'library', label: L('Habibi recipes', 'وصفات حبيبي') },
          { value: 'shared', label: L('Shared', 'مشاركة') },
          { value: 'mine', label: L('Mine', 'وصفاتي') },
        ]}
      />

      {tab === 'library' ? (
        <>
          <Chips value={cat} onChange={setCat} options={CATEGORIES.map((c) => ({ value: c, label: c }))} />
          {RECIPES.filter((x) => x.cat === cat).map((x, i) => (
            <Card key={x.id} index={i} onPress={() => router.push({ pathname: '/recipe/[id]', params: { id: x.id } })}>
              <Row style={{ justifyContent: 'space-between' }}>
                <View style={{ flex: 1, gap: 2 }}>
                  <Txt v="bodyStrong">{x.name}</Txt>
                  <Txt v="small" faint>{`${x.style} · ${L('makes', 'تكفي')} ${x.makes}`}</Txt>
                </View>
                <View style={{ alignItems: 'flex-end' }}>
                  <Txt v="bodyStrong">{x.kcal}</Txt>
                  <Txt v="small" faint>{`${x.p}g ${L('protein', 'بروتين')}`}</Txt>
                </View>
              </Row>
            </Card>
          ))}
          <Txt v="small" faint>{L('Macros are per serving and approximate.', 'القيم لكل حصة وتقريبية.')}</Txt>
        </>
      ) : null}

      {tab === 'shared' ? (
        shared.length ? (
          shared.map((f, i) => {
            const { k, p } = perServing(f);
            const n = cooked[f.id] ?? f.cooked_count ?? 0;
            return (
              <Card key={f.id} index={i} onPress={() => router.push({ pathname: '/food/[id]', params: { id: f.id } })}>
                <Row style={{ justifyContent: 'space-between' }}>
                  <View style={{ flex: 1, gap: 2 }}>
                    <Txt v="bodyStrong">{foodName(f, lang)}</Txt>
                    <Txt v="small" faint>{`${k} kcal · ${p}g ${L('protein', 'بروتين')} · ${L('per serving', 'للحصة')}`}</Txt>
                  </View>
                  <Press onPress={() => cook(f)} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, height: 34, borderRadius: 17, backgroundColor: theme.cardHigh }}>
                    <Icon name="flame" size={14} color={theme.accent} />
                    <Txt v="small">{`${L('Cooked it', 'طبختها')} ${n}`}</Txt>
                  </Press>
                </Row>
              </Card>
            );
          })
        ) : (
          <Txt muted>{L('No shared recipes yet. Share one of yours from the Mine tab.', 'ما في وصفات مشاركة بعد. شارك وحدة من وصفاتك.')}</Txt>
        )
      ) : null}

      {tab === 'mine' ? (
        <>
          <Button title={L('Create a recipe', 'أنشئ وصفة')} onPress={() => router.push('/food/recipe')} />
          {mine.map((f, i) => {
            const { k, p } = perServing(f);
            return (
              <Card key={f.id} index={i} onPress={() => router.push({ pathname: '/food/[id]', params: { id: f.id } })}>
                <Row style={{ justifyContent: 'space-between' }}>
                  <View style={{ flex: 1, gap: 2 }}>
                    <Txt v="bodyStrong">{foodName(f, lang)}</Txt>
                    <Txt v="small" faint>{`${k} kcal · ${p}g ${L('protein', 'بروتين')}`}</Txt>
                  </View>
                  <View style={{ alignItems: 'center', gap: 2 }}>
                    <Switch value={!!f.is_shared} onValueChange={(v) => toggleShare(f, v)} trackColor={{ true: theme.accent }} />
                    <Txt v="small" faint style={{ fontSize: 10 }}>{L('Share', 'مشاركة')}</Txt>
                  </View>
                </Row>
              </Card>
            );
          })}
          {!mine.length ? <Txt muted>{L('Recipes you create show up here. Flip the switch to share one with everyone.', 'وصفاتك تظهر هنا. شغّل المفتاح لمشاركتها مع الكل.')}</Txt> : null}
        </>
      ) : null}
    </Screen>
  );
}
