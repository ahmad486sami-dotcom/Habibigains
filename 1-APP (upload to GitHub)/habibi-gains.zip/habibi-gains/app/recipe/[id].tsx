// A Habibi Gains library recipe: ingredients, macros per serving, log a serving, share it.
import { router, useLocalSearchParams } from 'expo-router';
import React, { useState } from 'react';
import { ScrollView, Share, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { addFoodLog, Meal } from '@/lib/data';
import { defaultMeal, MEAL_LABEL, mealsFor } from '@/lib/day';
import { success, warn } from '@/lib/haptics';
import { RECIPES } from '@/lib/recipes';
import { useSession } from '@/lib/session';
import { todayISO } from '@/lib/supabase';
import { useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Card, Chips, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

export default function RecipeDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { profile } = useSession();
  const [meal, setMeal] = useState<Meal>(defaultMeal(!!profile?.ramadan_mode));
  const [busy, setBusy] = useState(false);
  const x = RECIPES.find((r) => r.id === id);
  if (!x) return null;

  const log = async () => {
    setBusy(true);
    try {
      await addFoodLog(
        {
          food_id: null, name: x.name, brand: 'Habibi Gains recipe', meal, quantity: 1, serving_label: L('1 serving', 'حصة واحدة'), serving_g: null, source: 'recipe',
          kcal: x.kcal, protein_g: x.p, carbs_g: x.c, fat_g: x.f, fiber_g: null, sugar_g: null, sodium_mg: null, sat_fat_g: null, cholesterol_mg: null, potassium_mg: null,
        },
        todayISO(),
      );
      success();
      router.back();
    } catch {
      warn();
    } finally {
      setBusy(false);
    }
  };

  const share = () =>
    Share.share({
      message: `${x.name} (Habibi Gains)\nPer serving: ${x.kcal} kcal · ${x.p}g protein · ${x.c}g carbs · ${x.f}g fat\nMakes ${x.makes}\n\nIngredients: ${x.ingredients}`,
    }).catch(() => {});

  const ingredients = x.ingredients.split(', ');
  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ padding: 20, gap: 14, paddingBottom: 60 }}>
      <Row style={{ justifyContent: 'space-between' }}>
        <Press onPress={share} style={{ padding: 6 }}><Icon name="share" /></Press>
        <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
      </Row>
      <Txt v="h2">{x.name}</Txt>
      <Txt v="small" muted>{`${x.style} · ${L('makes', 'تكفي')} ${x.makes} ${x.makes === 1 ? L('serving', 'حصة') : L('servings', 'حصص')}`}</Txt>
      <Card>
        <Row style={{ justifyContent: 'space-between' }}>
          {[[String(x.kcal), 'kcal'], [`${x.p}g`, L('protein', 'بروتين')], [`${x.c}g`, L('carbs', 'كارب')], [`${x.f}g`, L('fat', 'دهون')]].map(([v, l]) => (
            <View key={l} style={{ alignItems: 'center', flex: 1 }}>
              <Txt v="h3">{v}</Txt>
              <Txt v="small" muted>{l}</Txt>
            </View>
          ))}
        </Row>
        <Txt v="small" faint>{L('Per serving, approximate.', 'لكل حصة، تقريبي.')}</Txt>
      </Card>
      <Txt v="label" muted>{L('Ingredients', 'المكونات')}</Txt>
      <Card>
        {ingredients.map((g) => (
          <Row key={g} gap={10}>
            <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: theme.accent }} />
            <Txt style={{ flex: 1 }}>{g}</Txt>
          </Row>
        ))}
      </Card>
      <Chips value={meal} onChange={setMeal} options={mealsFor(!!profile?.ramadan_mode).map((m) => ({ value: m, label: L(MEAL_LABEL[m].en, MEAL_LABEL[m].ar) }))} />
      <Button title={L('Log 1 serving', 'سجّل حصة واحدة')} loading={busy} onPress={log} />
    </ScrollView>
  );
}
