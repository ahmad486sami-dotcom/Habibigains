// Showcase mode: a complete, believable account that runs with no backend.
// Enabled by EXPO_PUBLIC_DEMO=1 (the showcase build, or `EXPO_PUBLIC_DEMO=1 npx expo start`).
import Constants from 'expo-constants';
import type { EventRow, Food, FoodLog, MealPick, Quest } from './data';
import type { Profile } from './session';

export const IS_DEMO =
  process.env.EXPO_PUBLIC_DEMO === '1' || (Constants.expoConfig?.extra as { demo?: boolean } | undefined)?.demo === true;

const DAY = 86_400_000;
const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const id = () => Math.random().toString(36).slice(2, 10);

export const demoUserId = '00000000-0000-4000-8000-000000000001';

export const demoProfile: Profile = {
  id: demoUserId,
  display_name: 'Ahmad',
  role: 'admin',
  sex: 'male',
  birth_year: 2002,
  height_cm: 178,
  start_weight_kg: 88.6,
  goal_weight_kg: 78,
  goal: 'lose',
  activity: 'moderate',
  calorie_target: 2220,
  protein_target_g: 172,
  ramadan_mode: false,
  emirate: 'Abu Dhabi',
  wake_time: '07:00',
  sleep_time: '23:30',
  training_time: '18:00',
  use_creatine: true,
  use_caffeine: true,
  language: 'en',
  accent: '#F5F5F2',
  xp: 1340,
  streak_days: 23,
  is_premium: true,
  created_at: new Date(Date.now() - 62 * DAY).toISOString(),
};

// 62 days of weigh-ins: steady ~0.6 kg/week loss with realistic water noise.
function makeWeighIns() {
  const out: { measured_on: string; weight_kg: number }[] = [];
  let seed = 7;
  const rnd = () => ((seed = (seed * 9301 + 49297) % 233280) / 233280);
  for (let i = 62; i >= 0; i--) {
    if (i % 9 === 4) continue; // a few missed days, like real life
    const day = new Date(Date.now() - i * DAY);
    const base = 88.6 - (62 - i) * 0.086;
    const noise = (rnd() - 0.5) * 1.4 + (day.getDay() === 6 ? 0.5 : 0); // salty Friday dinners
    out.push({ measured_on: iso(day), weight_kg: Math.round((base + noise) * 10) / 10 });
  }
  return out;
}

export const demo = {
  weighIns: makeWeighIns(),
  foods: [
    { id: 'f1', name_en: 'Chicken shawarma wrap', name_ar: 'شاورما دجاج', serving: '1 wrap', kcal: 480, protein_g: 28, carbs_g: 42, fat_g: 21, is_local: true },
    { id: 'f2', name_en: 'Chicken machboos', name_ar: 'مجبوس دجاج', serving: '1 plate', kcal: 650, protein_g: 38, carbs_g: 78, fat_g: 19, is_local: true },
    { id: 'f3', name_en: 'Karak chai', name_ar: 'شاي كرك', serving: '1 cup', kcal: 120, protein_g: 3, carbs_g: 18, fat_g: 4, is_local: true },
    { id: 'f4', name_en: 'Harees', name_ar: 'هريس', serving: '1 bowl', kcal: 330, protein_g: 20, carbs_g: 38, fat_g: 10, is_local: true },
    { id: 'f5', name_en: 'Dates', name_ar: 'تمر', serving: '3 dates', kcal: 70, protein_g: 0.5, carbs_g: 18, fat_g: 0, is_local: true },
    { id: 'f6', name_en: 'Shish tawook (grilled)', name_ar: 'شيش طاووق', serving: '200 g', kcal: 330, protein_g: 50, carbs_g: 6, fat_g: 11, is_local: true },
    { id: 'f7', name_en: 'Laban', name_ar: 'لبن', serving: '1 cup', kcal: 110, protein_g: 8, carbs_g: 12, fat_g: 4, is_local: true },
    { id: 'f8', name_en: 'Manakeesh zaatar', name_ar: 'مناقيش زعتر', serving: '1 piece', kcal: 380, protein_g: 9, carbs_g: 48, fat_g: 17, is_local: true },
    { id: 'f9', name_en: 'Luqaimat', name_ar: 'لقيمات', serving: '5 pieces', kcal: 290, protein_g: 3, carbs_g: 38, fat_g: 14, is_local: true },
    { id: 'f10', name_en: 'Greek yogurt (plain)', name_ar: 'زبادي يوناني', serving: '170 g', kcal: 100, protein_g: 17, carbs_g: 6, fat_g: 0.7, is_local: false },
    { id: 'f11', name_en: 'Oats', name_ar: 'شوفان', serving: '50 g dry', kcal: 190, protein_g: 7, carbs_g: 33, fat_g: 3.5, is_local: false },
    { id: 'f12', name_en: 'Whey protein shake', name_ar: 'بروتين واي', serving: '1 scoop', kcal: 120, protein_g: 24, carbs_g: 3, fat_g: 1.5, is_local: false },
    { id: 'f13', name_en: 'Grilled hammour with rice', name_ar: 'هامور مشوي مع رز', serving: '1 plate', kcal: 560, protein_g: 42, carbs_g: 60, fat_g: 14, is_local: true },
    { id: 'f14', name_en: 'Hummus', name_ar: 'حمص', serving: '100 g', kcal: 170, protein_g: 8, carbs_g: 14, fat_g: 10, is_local: true },
  ] as Food[],
  logs: [] as FoodLog[],
  events: [
    { id: 'e1', host_id: demoUserId, title: 'Corniche Sunrise 5K', description: 'Easy pace, all levels. Meet at the flag.', location_name: 'Corniche, Abu Dhabi', emirate: 'Abu Dhabi', starts_at: '', badge_name: 'Corniche Sunrise', xp: 100, women_only: false, checkin_code: 'HG-DEMO-1', going: 86, i_am_going: true },
    { id: 'e2', host_id: 'h2', title: 'Hudayriyat Night Run', description: '7K on the island loop. Lights provided.', location_name: 'Hudayriyat Island', emirate: 'Abu Dhabi', starts_at: '', badge_name: 'Night Owl', xp: 120, women_only: false, checkin_code: null, going: 54, i_am_going: false },
    { id: 'e4', host_id: 'h4', title: 'Ladies Sunset Walk & Run', description: 'Women only. Relaxed 4K, all paces welcome.', location_name: 'Umm Al Emarat Park', emirate: 'Abu Dhabi', starts_at: '', badge_name: 'Sunset Sisters', xp: 100, women_only: true, checkin_code: null, going: 41, i_am_going: false },
    { id: 'e3', host_id: 'h3', title: 'Kite Beach 5K', description: 'Dubai crew. Coffee after.', location_name: 'Kite Beach, Dubai', emirate: 'Dubai', starts_at: '', badge_name: 'Kite Beach', xp: 100, women_only: false, checkin_code: null, going: 132, i_am_going: false },
  ] as EventRow[],
  quests: [
    { id: 'q1', title_en: 'Spot a cat on your run', title_ar: 'اعثر على قطة أثناء الجري', description: 'Snap it. Bonus points for a sleepy one.', proof: 'photo', target_steps: null, xp: 50, ends_on: '', done: false },
    { id: 'q2', title_en: '10,000 steps today', title_ar: '١٠٬٠٠٠ خطوة اليوم', description: null, proof: 'steps', target_steps: 10000, xp: 40, ends_on: '', done: false },
    { id: 'q3', title_en: 'Sunrise run before 6:30', title_ar: 'جري الشروق قبل ٦:٣٠', description: null, proof: 'checkin', target_steps: null, xp: 80, ends_on: '', done: true },
    { id: 'q4', title_en: 'Take the stairs 5 times', title_ar: 'استخدم الدرج ٥ مرات', description: null, proof: 'honor', target_steps: null, xp: 30, ends_on: '', done: false },
  ] as (Quest & { done: boolean })[],
  badges: [
    { id: 'first-log', name_en: 'First Bite', name_ar: 'أول لقمة', icon: 'fork', earned: true },
    { id: 'first-weigh', name_en: 'On the Scale', name_ar: 'على الميزان', icon: 'scale', earned: true },
    { id: 'streak-7', name_en: 'One Week Strong', name_ar: 'أسبوع قوي', icon: 'flame', earned: true },
    { id: 'first-run', name_en: 'Run Club', name_ar: 'نادي الجري', icon: 'run', earned: true },
    { id: 'down-5', name_en: 'Five Down', name_ar: 'خمسة أقل', icon: 'trend', earned: true },
    { id: 'first-quest', name_en: 'Side Quester', name_ar: 'صاحب المهمات', icon: 'star', earned: true },
    { id: 'streak-30', name_en: 'Habibi Habit', name_ar: 'عادة حبيبي', icon: 'flame', earned: false },
    { id: 'first-photo', name_en: 'Day One', name_ar: 'اليوم الأول', icon: 'camera', earned: false },
  ],
  picks: [
    { id: 'p1', title_en: 'Grilled chicken bowl', title_ar: 'وعاء دجاج مشوي', restaurant: 'Fit Kitchen', kcal: 520, protein_g: 48, price_aed: 38, deal_text: '20% off this week', order_url: null, emirate: 'Abu Dhabi' },
    { id: 'p2', title_en: 'Shish tawook plate, no fries', title_ar: 'صحن شيش طاووق بدون بطاطس', restaurant: 'Grill House', kcal: 560, protein_g: 52, price_aed: 34, deal_text: null, order_url: null, emirate: 'Abu Dhabi' },
    { id: 'p3', title_en: 'Hammour with salad', title_ar: 'هامور مع سلطة', restaurant: 'Sea Catch', kcal: 430, protein_g: 40, price_aed: 45, deal_text: 'Free delivery', order_url: null, emirate: 'Abu Dhabi' },
  ] as MealPick[],
  photos: [] as { id: string; storage_path: string; pose: string; taken_on: string }[],
  // 30 days of realistic intake for the measured-metabolism demo.
  dailyTotals: Array.from({ length: 30 }, (_, i) => ({
    day: iso(new Date(Date.now() - (i + 1) * DAY)),
    kcal: 2150 + Math.round(Math.sin(i * 1.7) * 220) + (i % 7 === 5 ? 450 : 0),
  })),
};

// Event times relative to now so the demo always looks current.
(() => {
  const next = (daysAhead: number, h: number, m = 0) => {
    const d = new Date(Date.now() + daysAhead * DAY);
    d.setHours(h, m, 0, 0);
    return d.toISOString();
  };
  demo.events[0].starts_at = next(1, 6, 0);
  demo.events[1].starts_at = next(3, 20, 30);
  demo.events[2].starts_at = next(4, 17, 30);
  demo.events[3].starts_at = next(5, 6, 30);
  const end = iso(new Date(Date.now() + 4 * DAY));
  demo.quests.forEach((q) => (q.ends_on = end));

  const today = iso(new Date());
  const log = (meal: string, f: Food, servings = 1, source = 'search'): FoodLog => ({
    id: id(), name: f.name_en, meal, servings, kcal: Math.round(f.kcal * servings), protein_g: f.protein_g * servings,
    carbs_g: f.carbs_g * servings, fat_g: f.fat_g * servings, logged_on: today, source,
  });
  const F = (k: string) => demo.foods.find((f) => f.id === k)!;
  demo.logs.push(log('breakfast', F('f11')), log('breakfast', F('f10')), log('breakfast', F('f3')), log('lunch', F('f6')), log('lunch', F('f14')), log('snack', F('f12')));
})();

export const demoId = id;
export const demoToday = () => iso(new Date());
