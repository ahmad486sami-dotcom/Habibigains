// Two versions from one codebase:
//   APP_VARIANT=production (default) → "Habibi Gains", com.habibigains.app, real backend.
//   APP_VARIANT=showcase             → "HG Showcase", com.habibigains.showcase, offline demo data,
//                                       no capabilities that need a paid Apple account.
const base = require('./base-config.json');

const variant = process.env.APP_VARIANT || 'production';
const showcase = variant === 'showcase';

module.exports = () => {
  const config = JSON.parse(JSON.stringify(base));
  config.extra = { ...(config.extra || {}), variant, demo: showcase };

  if (showcase) {
    config.name = 'HG Showcase';
    config.slug = base.slug; // keep the same EAS project
    config.scheme = 'habibigainsdemo';
    config.ios.bundleIdentifier = 'com.habibigains.showcase';
    config.android.package = 'com.habibigains.showcase';
    // Free/re-signed builds can't carry these entitlements.
    delete config.ios.entitlements;
    config.ios.usesAppleSignIn = false;
    config.plugins = config.plugins.filter((p) => {
      const name = Array.isArray(p) ? p[0] : p;
      return !['react-native-health', 'expo-apple-authentication', 'expo-health-connect'].includes(name);
    });
  }
  return config;
};
