// Log a workout: pick the activity, set minutes, calories are estimated (MET x body weight x hours) and editable.
// Workout calories are added to today's budget: Remaining = Goal - Food + Exercise.
import { router, useLocalSearchParams } from 'expo-router';
import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { addExercise } from '@/lib/data';
import { success, warn } from '@/lib/haptics';
import { todayISO } from '@/lib/supabase';
import { useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Chips, Field, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

// Compendium of Physical Activities (Ainsworth et al., 2011) typical MET values.
const ACTIVITIES = [
  { id: 'gym', en: 'Gym (weights)', ar: 'جيم (أوزان)', met: 5.0 },
  { id: 'walk', en: 'Walking', ar: 'مشي', met: 3.5 },
  { id: 'run', en: 'Running', ar: 'جري', met: 9.8 },
  { id: 'cycle', en: 'Cycling', ar: 'دراجة', met: 7.5 },
  { id: 'football', en: 'Football', ar: 'كرة قدم', met: 7.0 },
  { id: 'padel', en: 'Padel', ar: 'بادل', met: 6.0 },
  { id: 'swim', en: 'Swimming', ar: 'سباحة', met: 7.0 },
  { id: 'hiit', en: 'HIIT / classes', ar: 'تمارين HIIT', met: 8.0 },
  { id: 'other', en: 'Other', ar: 'أخرى', met: 5.0 },
];

export default function Exercise() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const p = useLocalSearchParams<{ weight?: string; day?: string }>();
  const weight = Number(p.weight) || 75;
  const [act, setAct] = useState('gym');
  const [minutes, setMinutes] = useState('45');
  const [kcalText, setKcalText] = useState('');
  const [busy, setBusy] = useState(false);
  const a = ACTIVITIES.find((x) => x.id === act)!;
  const mins = Math.max(0, Number(minutes) || 0);
  const estimate = Math.round(a.met * weight * (mins / 60));
  const kcal = kcalText ? Math.max(0, Math.round(Number(kcalText) || 0)) : estimate;

  const save = async () => {
    setBusy(true);
    try {
      await addExercise({ name: L(a.en, a.ar), minutes: mins, kcal }, p.day ?? todayISO());
      success();
      router.back();
    } catch {
      warn();
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: theme.bg }}>
      <ScrollView contentContainerStyle={{ padding: 20, gap: 14 }} keyboardShouldPersistTaps="handled">
        <Row style={{ justifyContent: 'space-between' }}>
          <Txt v="h2">{L('Log a workout', 'سجّل تمرين')}</Txt>
          <Press onPress={() => router.back()} style={{ padding: 6 }}><Icon name="close" /></Press>
        </Row>
        <Chips value={act} onChange={(v) => { setAct(v); setKcalText(''); }} options={ACTIVITIES.map((x) => ({ value: x.id, label: L(x.en, x.ar) }))} />
        <Row gap={10}>
          <View style={{ flex: 1 }}>
            <Field label={L('Minutes', 'الدقائق')} keyboardType="number-pad" value={minutes} onChangeText={(v) => { setMinutes(v.replace(/[^0-9]/g, '')); setKcalText(''); }} />
          </View>
          <View style={{ flex: 1 }}>
            <Field label={L('Calories burned', 'السعرات المحروقة')} keyboardType="number-pad" value={kcalText} placeholder={String(estimate)} onChangeText={(v) => setKcalText(v.replace(/[^0-9]/g, ''))} />
          </View>
        </Row>
        <Txt v="small" muted>
          {L(`Estimate: ${estimate} kcal for ${mins} min at ${weight} kg. Type your watch's number if you have one.`, `تقدير: ${estimate} سعرة لـ ${mins} دقيقة بوزن ${weight} كجم. اكتب رقم ساعتك إذا عندك.`)}
        </Txt>
        <Txt v="small" faint>{L('These calories are added to today\'s budget.', 'هذه السعرات تُضاف إلى ميزانية اليوم.')}</Txt>
        <Button title={L(`Add ${kcal} kcal`, `أضف ${kcal} سعرة`)} loading={busy} disabled={kcal <= 0} onPress={save} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
