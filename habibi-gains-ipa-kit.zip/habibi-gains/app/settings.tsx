import { router } from 'expo-router';
import * as WebBrowser from 'expo-web-browser';
import React, { useState } from 'react';
import { Alert, ScrollView, Switch, View } from 'react-native';
import { useI18n } from '@/i18n/i18n';
import { deleteAccount } from '@/lib/auth';
import { LEGAL_URL } from '@/lib/config';
import { IS_DEMO } from '@/lib/demo';
import { select, success } from '@/lib/haptics';
import { connectHealth } from '@/lib/health';
import { disableReminders, enableReminders } from '@/lib/notifications';
import { EMIRATES } from '@/lib/ramadan';
import { useSession } from '@/lib/session';
import { ACCENTS, useTheme } from '@/theme/theme';
import { Icon, IconName } from '@/ui/Icon';
import { Chips, Row } from '@/ui/Layout';
import { Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  const { theme } = useTheme();
  return (
    <View style={{ gap: 8 }}>
      <Txt v="label" muted style={{ paddingHorizontal: 4 }}>{title}</Txt>
      <View style={{ backgroundColor: theme.card, borderRadius: 24, overflow: 'hidden' }}>{children}</View>
    </View>
  );
}

function Item({ icon, label, value, onPress, right, danger }: { icon: IconName; label: string; value?: string; onPress?: () => void; right?: React.ReactNode; danger?: boolean }) {
  const { theme } = useTheme();
  return (
    <Press onPress={onPress} disabled={!onPress} scaleTo={0.99} haptic={!!onPress} style={{ flexDirection: 'row', alignItems: 'center', gap: 14, paddingHorizontal: 16, minHeight: 56, borderBottomWidth: 1, borderBottomColor: theme.bg }}>
      <Icon name={icon} size={20} color={danger ? theme.danger : theme.muted} />
      <Txt style={{ flex: 1 }} color={danger ? theme.danger : undefined}>{label}</Txt>
      {value ? <Txt muted>{value}</Txt> : null}
      {right ?? (onPress ? <Icon name="chevron" size={16} color={theme.faint} /> : null)}
    </Press>
  );
}

export default function Settings() {
  const { t, lang, setLang } = useI18n();
  const { theme, setAccent } = useTheme();
  const { profile, updateProfile, signOut } = useSession();
  const [reminders, setReminders] = useState(false);

  if (!profile) return null;

  const confirmDelete = () =>
    Alert.alert(t('deleteAccount'), t('deleteConfirm'), [
      { text: t('cancel'), style: 'cancel' },
      {
        text: t('delete'),
        style: 'destructive',
        onPress: async () => {
          try {
            await deleteAccount();
            router.replace('/');
          } catch (e: any) {
            Alert.alert(t('error'), e?.message ?? '');
          }
        },
      },
    ]);

  const timeChips = (key: 'wake_time' | 'sleep_time' | 'training_time', opts: { value: string; label: string }[]) => (
    <View style={{ padding: 16, gap: 10, borderBottomWidth: 1, borderBottomColor: theme.bg }}>
      <Txt v="small" muted>{t(key === 'wake_time' ? 'wakeTime' : key === 'sleep_time' ? 'sleepTime' : 'trainingTime')}</Txt>
      <Chips value={(profile[key] ?? 'none') as string} onChange={(v) => updateProfile({ [key]: v === 'none' ? null : v } as any)} options={opts} />
    </View>
  );

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ padding: 20, gap: 22, paddingBottom: 60 }}>
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt v="h1">{t('settings')}</Txt>
        <Press onPress={() => router.back()} accessibilityLabel={t('close')} style={{ padding: 6 }}>
          <Icon name="close" />
        </Press>
      </Row>

      {/* Look & language */}
      <Section title={t('accentColor')}>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 14, padding: 16 }}>
          {ACCENTS.map((a) => (
            <Press
              key={a.id}
              haptic={false}
              onPress={() => {
                select();
                setAccent(a.hex);
                updateProfile({ accent: a.hex });
              }}
              accessibilityLabel={a.id}
              style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: a.hex, borderWidth: theme.accent === a.hex ? 3 : 0, borderColor: theme.text, alignItems: 'center', justifyContent: 'center' }}
            >
              {theme.accent === a.hex ? <Icon name="check" size={18} color={a.id === 'white' || a.id === 'lime' || a.id === 'gold' || a.id === 'cyan' ? '#000' : '#fff'} stroke={2.6} /> : null}
            </Press>
          ))}
        </View>
      </Section>

      <Section title={t('language')}>
        <View style={{ padding: 16 }}>
          <Chips value={lang} onChange={(l) => { setLang(l); updateProfile({ language: l }); }} options={[{ value: 'en', label: 'English' }, { value: 'ar', label: 'العربية' }]} />
        </View>
      </Section>

      {/* Your day (feeds the Timing coach) */}
      <Section title={t('timingTitle')}>
        {timeChips('wake_time', ['05:30', '06:30', '07:00', '08:00', '09:00'].map((v) => ({ value: v, label: v })))}
        {timeChips('training_time', [
          ...['06:00', '12:00', '17:00', '18:00', '20:00', '21:30'].map((v) => ({ value: v, label: v })),
          { value: 'none', label: t('noTrainYet') },
        ])}
        {timeChips('sleep_time', ['22:00', '23:00', '23:30', '00:30', '01:30'].map((v) => ({ value: v, label: v })))}
        <Item icon="pill" label={t('creatineQ')} right={<Switch value={profile.use_creatine} onValueChange={(v) => updateProfile({ use_creatine: v })} trackColor={{ true: theme.accent }} />} />
        <Item icon="bolt" label={t('caffeineQ')} right={<Switch value={profile.use_caffeine} onValueChange={(v) => updateProfile({ use_caffeine: v })} trackColor={{ true: theme.accent }} />} />
        <Item icon="clock" label={t('timingTitle')} onPress={() => router.push('/timing')} />
      </Section>

      <Section title={t('ramadanMode')}>
        <Item icon="moon" label={t('ramadanMode')} right={<Switch value={profile.ramadan_mode} onValueChange={(v) => updateProfile({ ramadan_mode: v })} trackColor={{ true: theme.accent }} />} />
        <View style={{ padding: 16, gap: 10 }}>
          <Txt v="small" muted>{t('emirate')}</Txt>
          <Chips value={profile.emirate} onChange={(v) => updateProfile({ emirate: v })} options={Object.keys(EMIRATES).map((e) => ({ value: e, label: e }))} />
        </View>
      </Section>

      <Section title={t('settings')}>
        <Item icon="trend" label={t('editPlan')} onPress={() => router.push('/onboarding')} />
        <Item icon="info" label={t('whyNumbers')} onPress={() => router.push('/why')} />
        <Item
          icon="run"
          label={t('syncHealth')}
          onPress={async () => {
            if (await connectHealth()) success();
            else Alert.alert(t('syncHealth'), t('healthUnavailable'));
          }}
        />
        <Item
          icon="clock"
          label={t('reminders')}
          right={
            <Switch
              value={reminders}
              onValueChange={async (v) => {
                setReminders(v);
                if (v) setReminders(await enableReminders(lang));
                else await disableReminders();
              }}
              trackColor={{ true: theme.accent }}
            />
          }
        />
        <Item icon="sparkle" label={t('premium')} value={profile.is_premium ? '✓' : undefined} onPress={() => router.push('/premium')} />
        {profile.role !== 'member' ? <Item icon="star" label={t('admin')} onPress={() => router.push('/admin')} /> : null}
      </Section>

      <Section title={t('privacy')}>
        <Item icon="lock" label={t('privacy')} onPress={() => WebBrowser.openBrowserAsync(`${LEGAL_URL}/privacy`)} />
        <Item icon="book" label={t('terms')} onPress={() => WebBrowser.openBrowserAsync(`${LEGAL_URL}/terms`)} />
        {!IS_DEMO ? <Item icon="close" label={t('signOut')} onPress={async () => { await signOut(); router.replace('/'); }} /> : null}
        {!IS_DEMO ? <Item icon="trash" label={t('deleteAccount')} danger onPress={confirmDelete} /> : null}
      </Section>

      <Txt v="small" faint center>{`Habibi Gains · v1.0${IS_DEMO ? ' · Showcase' : ''}`}</Txt>
    </ScrollView>
  );
}
