// Evidence-graded supplement guide. Every entry is based on position stands or meta-analyses (listed in `source`).
// Doses are for healthy adults. Not medical advice.

export type Tier = 'works' | 'situational' | 'mixed' | 'skip';

export type Supplement = {
  id: string;
  tier: Tier;
  name: { en: string; ar: string };
  what: { en: string; ar: string }; // what it actually does
  dose: { en: string; ar: string };
  when: { en: string; ar: string };
  who: { en: string; ar: string };
  caution?: { en: string; ar: string };
  source: string;
};

export const TIERS: { id: Tier; en: string; ar: string; blurbEn: string; blurbAr: string }[] = [
  { id: 'works', en: 'Works', ar: 'فعّال', blurbEn: 'Strong, repeated evidence in healthy people.', blurbAr: 'أدلة قوية ومتكررة عند الأصحاء.' },
  { id: 'situational', en: 'Works in specific cases', ar: 'فعّال في حالات معينة', blurbEn: 'Real effect, but only for certain goals or people.', blurbAr: 'له تأثير حقيقي لكن لأهداف أو أشخاص معينين.' },
  { id: 'mixed', en: 'Mixed evidence', ar: 'أدلة متضاربة', blurbEn: 'Small or inconsistent effects. Optional at best.', blurbAr: 'تأثير صغير أو غير ثابت. اختياري في أحسن الأحوال.' },
  { id: 'skip', en: 'Save your money', ar: 'وفّر فلوسك', blurbEn: 'Does not do what the label says for most people.', blurbAr: 'ما يسوي اللي مكتوب على العلبة لأغلب الناس.' },
];

export const SUPPLEMENTS: Supplement[] = [
  // ───────── Works ─────────
  {
    id: 'creatine',
    tier: 'works',
    name: { en: 'Creatine monohydrate', ar: 'كرياتين مونوهيدرات' },
    what: {
      en: 'The most researched supplement there is. Adds strength and lean mass on top of training (about 1–2 kg more lean mass over a few months) and helps repeated hard efforts. Also has early evidence for brain benefits.',
      ar: 'أكثر مكمل مدروس. يزيد القوة والكتلة العضلية مع التمرين (حوالي ١–٢ كجم كتلة عضلية زيادة خلال أشهر) ويساعد في الجهد المتكرر.',
    },
    dose: { en: '3–5 g every day. No loading needed (loading 20 g/day for 5–7 days just gets you there faster).', ar: '٣–٥ جم يومياً. التحميل مو ضروري.' },
    when: { en: 'Any time of day. Consistency matters, timing does not.', ar: 'أي وقت في اليوم. المهم الاستمرار مو التوقيت.' },
    who: { en: 'Anyone who lifts or does sprint-type sport, men and women.', ar: 'أي شخص يرفع أوزان أو يمارس رياضات سريعة، رجال ونساء.' },
    caution: {
      en: 'Expect +1–2 kg on the scale in the first weeks: that is water inside muscle, not fat. Safe for healthy kidneys; talk to a doctor if you have kidney disease.',
      ar: 'توقع زيادة ١–٢ كجم في الأسابيع الأولى: هذا ماء داخل العضلة مو دهون. آمن للكلى السليمة.',
    },
    source: 'Kreider RB et al. ISSN position stand: safety and efficacy of creatine supplementation. J Int Soc Sports Nutr. 2017.',
  },
  {
    id: 'caffeine',
    tier: 'works',
    name: { en: 'Caffeine', ar: 'الكافيين' },
    what: {
      en: 'Improves endurance, strength and power by a few percent and makes hard work feel easier. Coffee works as well as pills.',
      ar: 'يحسن التحمل والقوة بنسبة بسيطة ويخلي التمرين الصعب أسهل. القهوة تشتغل مثل الحبوب.',
    },
    dose: { en: '3–6 mg per kg body weight (e.g. 210–420 mg at 70 kg). Lower doses (~2 mg/kg) still help. Max ~400 mg/day for most adults.', ar: '٣–٦ ملجم لكل كجم من وزنك. الحد اليومي حوالي ٤٠٠ ملجم.' },
    when: { en: '30–60 minutes before training. Stop at least 6–8 hours before bed or it cuts your sleep.', ar: '٣٠–٦٠ دقيقة قبل التمرين. وقفه قبل النوم بـ ٦–٨ ساعات.' },
    who: { en: 'Most people. If you drink coffee daily you still get the effect.', ar: 'أغلب الناس.' },
    caution: { en: 'Avoid or limit if pregnant, with heart rhythm problems or anxiety. Pre-workouts often hide 300+ mg.', ar: 'قلله أو تجنبه في الحمل أو مشاكل القلب أو القلق.' },
    source: 'Guest NS et al. ISSN position stand: caffeine and exercise performance. J Int Soc Sports Nutr. 2021. · Drake C et al. Caffeine effects on sleep taken 0, 3, or 6 hours before going to bed. J Clin Sleep Med. 2013.',
  },
  {
    id: 'protein',
    tier: 'works',
    name: { en: 'Protein powder (whey or plant)', ar: 'بروتين باودر (واي أو نباتي)' },
    what: {
      en: 'Not magic: it is food. It helps only because it makes hitting your daily protein easier. Daily protein up to ~1.6 g/kg is what builds muscle.',
      ar: 'مو سحر، هو أكل. يفيد لأنه يسهل توصل لهدف البروتين اليومي (حوالي ١٫٦ جم لكل كجم).',
    },
    dose: { en: '20–40 g per scoop when you are short of your protein target. Most people need 0–2 scoops a day.', ar: '٢٠–٤٠ جم لما تكون ناقص عن هدفك.' },
    when: { en: 'Any time. The "30-minute anabolic window" is mostly a myth; total daily protein matters most.', ar: 'أي وقت. المهم المجموع اليومي.' },
    who: { en: 'Anyone who struggles to reach their protein target from food.', ar: 'أي أحد يصعب عليه يوصل هدف البروتين من الأكل.' },
    caution: { en: 'Choose third-party tested brands (e.g. Informed Sport) registered in the UAE.', ar: 'اختر ماركات مفحوصة ومسجلة في الإمارات.' },
    source: 'Jäger R et al. ISSN position stand: protein and exercise. J Int Soc Sports Nutr. 2017. · Morton RW et al. Br J Sports Med. 2018.',
  },
  {
    id: 'vitd',
    tier: 'works',
    name: { en: 'Vitamin D (if you are low)', ar: 'فيتامين د (إذا عندك نقص)' },
    what: {
      en: 'Very common to be low in the UAE despite the sun (indoors, covered skin, AC). Low levels are linked to weaker muscles, bones and immunity. Fixing a deficiency helps; extra on top of normal levels does not.',
      ar: 'النقص منتشر جداً في الإمارات رغم الشمس. تصحيح النقص يفيد العضلات والعظام والمناعة.',
    },
    dose: { en: '1,000–2,000 IU daily is a typical safe dose. Get a blood test (25-OH vitamin D); your doctor may prescribe more if you are deficient.', ar: '١٠٠٠–٢٠٠٠ وحدة يومياً. سوِّ تحليل دم أول.' },
    when: { en: 'With a meal that has some fat.', ar: 'مع وجبة فيها دهون.' },
    who: { en: 'Anyone with a low blood test, or who rarely gets sun on bare skin.', ar: 'أي أحد تحليله منخفض أو ما يتعرض للشمس.' },
    caution: { en: 'Very high doses for long periods can be harmful. Do not exceed 4,000 IU/day without a doctor.', ar: 'لا تتجاوز ٤٠٠٠ وحدة يومياً بدون طبيب.' },
    source: 'Holick MF et al. Endocrine Society clinical practice guideline on vitamin D deficiency. J Clin Endocrinol Metab. 2011. · Haq A et al. Vitamin D deficiency: a single centre analysis of patients from 136 countries (Abu Dhabi). J Steroid Biochem Mol Biol. 2016.',
  },

  // ───────── Situational ─────────
  {
    id: 'betaalanine',
    tier: 'situational',
    name: { en: 'Beta-alanine', ar: 'بيتا ألانين' },
    what: { en: 'Buffers acid in muscle. Helps efforts lasting about 1–4 minutes (e.g. 400–1500 m, high-rep sets, CrossFit). Little use for heavy lifting or long easy runs.', ar: 'يفيد الجهد اللي يستمر ١–٤ دقائق. فايدته قليلة للأوزان الثقيلة أو الجري الطويل.' },
    dose: { en: '3.2–6.4 g per day, split into 0.8–1.6 g doses, for at least 2–4 weeks.', ar: '٣٫٢–٦٫٤ جم يومياً مقسمة، لمدة ٢–٤ أسابيع على الأقل.' },
    when: { en: 'Daily, with meals. It builds up over weeks, so pre-workout timing is irrelevant.', ar: 'يومياً مع الوجبات.' },
    who: { en: 'People doing repeated hard intervals or high-rep training.', ar: 'اللي يسوون تمارين متقطعة عالية الشدة.' },
    caution: { en: 'Causes a harmless tingling (paresthesia). Smaller split doses reduce it.', ar: 'يسبب تنميل غير ضار.' },
    source: 'Trexler ET et al. ISSN position stand: beta-alanine. J Int Soc Sports Nutr. 2015.',
  },
  {
    id: 'nitrate',
    tier: 'situational',
    name: { en: 'Beetroot juice / nitrate', ar: 'عصير الشمندر / النترات' },
    what: { en: 'Lowers the oxygen cost of exercise. Helps endurance a little (about 1–3%), mostly in recreational athletes rather than elites.', ar: 'يقلل استهلاك الأكسجين ويحسن التحمل شوي.' },
    dose: { en: 'About 6–8 mmol nitrate: roughly one 70 ml concentrated beetroot shot or 500 ml juice.', ar: 'حوالي ٧٠ مل شمندر مركز أو ٥٠٠ مل عصير.' },
    when: { en: '2–3 hours before a run or race.', ar: '٢–٣ ساعات قبل الجري.' },
    who: { en: 'Runners and cyclists before key sessions.', ar: 'العدائين وراكبي الدراجات.' },
    caution: { en: 'Pink urine is normal. Antibacterial mouthwash blocks the effect.', ar: 'تلون البول طبيعي. غسول الفم المعقم يلغي التأثير.' },
    source: 'Jones AM. Dietary nitrate supplementation and exercise performance. Sports Med. 2014.',
  },
  {
    id: 'electrolytes',
    tier: 'situational',
    name: { en: 'Electrolytes (sodium) in the heat', ar: 'الأملاح (الصوديوم) في الحر' },
    what: { en: 'UAE summers mean heavy sweat losses. For long sweaty sessions, replacing sodium and fluid keeps performance up and reduces cramps and dizziness. For a normal 45-minute gym session, water is enough.', ar: 'في صيف الإمارات العرق كثير. للتمارين الطويلة، تعويض الصوديوم والسوائل يحافظ على الأداء.' },
    dose: { en: 'About 300–600 mg sodium per hour of sweaty exercise, with 400–800 ml fluid per hour.', ar: '٣٠٠–٦٠٠ ملجم صوديوم لكل ساعة مع ٤٠٠–٨٠٠ مل سوائل.' },
    when: { en: 'During sessions longer than about 60–90 minutes, or outdoor runs in summer.', ar: 'أثناء التمارين أطول من ساعة، أو الجري برا في الصيف.' },
    who: { en: 'Outdoor runners, long sessions, heavy sweaters.', ar: 'اللي يجرون برا أو يعرقون كثير.' },
    caution: { en: 'Not needed for short sessions. Watch sodium if you have high blood pressure.', ar: 'مو ضروري للتمارين القصيرة.' },
    source: 'Sawka MN et al. ACSM position stand: exercise and fluid replacement. Med Sci Sports Exerc. 2007.',
  },
  {
    id: 'omega3',
    tier: 'situational',
    name: { en: 'Omega-3 (fish oil)', ar: 'أوميغا ٣ (زيت السمك)' },
    what: { en: 'Good for heart and general health. Effects on muscle or performance in healthy people are small and unclear.', ar: 'مفيد لصحة القلب. تأثيره على العضلات صغير وغير واضح.' },
    dose: { en: 'About 1–2 g EPA + DHA per day (check the label, not the total fish-oil amount).', ar: '١–٢ جم EPA + DHA يومياً.' },
    when: { en: 'With meals.', ar: 'مع الوجبات.' },
    who: { en: 'People who eat oily fish (salmon, sardines, mackerel) less than twice a week.', ar: 'اللي ياكلون سمك دهني أقل من مرتين بالأسبوع.' },
    caution: { en: 'Check with a doctor if you take blood thinners.', ar: 'استشر الطبيب إذا تاخذ مميعات الدم.' },
    source: 'Thielecke F, Blannin A. Omega-3 fatty acids for sport performance: are they equally beneficial for athletes and amateurs? Nutrients. 2020.',
  },

  // ───────── Mixed ─────────
  {
    id: 'citrulline',
    tier: 'mixed',
    name: { en: 'Citrulline malate', ar: 'سيترولين مالات' },
    what: { en: 'Popular "pump" ingredient. Meta-analyses find a small benefit for high-rep strength work at best; many studies find nothing.', ar: 'فايدته صغيرة جداً في أحسن الأحوال.' },
    dose: { en: '6–8 g citrulline malate if you want to try it.', ar: '٦–٨ جم إذا تبي تجربه.' },
    when: { en: '60 minutes before training.', ar: 'قبل التمرين بساعة.' },
    who: { en: 'Optional. Not a priority.', ar: 'اختياري.' },
    source: 'Trexler ET et al. Acute effects of citrulline supplementation on high-intensity strength and power performance: a systematic review and meta-analysis. Sports Med. 2019.',
  },
  {
    id: 'ashwagandha',
    tier: 'mixed',
    name: { en: 'Ashwagandha', ar: 'أشواغاندا' },
    what: { en: 'Some small studies show modest gains in strength and lower stress, but they are mostly small and short. Quality varies a lot between products.', ar: 'دراسات صغيرة تبين فايدة بسيطة في القوة والتوتر. الجودة تختلف كثير.' },
    dose: { en: 'Studies used 300–600 mg/day of root extract.', ar: '٣٠٠–٦٠٠ ملجم يومياً.' },
    when: { en: 'Daily, often split morning and evening.', ar: 'يومياً.' },
    who: { en: 'Optional for stressed lifters.', ar: 'اختياري.' },
    caution: { en: 'Avoid if pregnant, or with thyroid conditions. Rare cases of liver injury are reported.', ar: 'تجنبه في الحمل ومشاكل الغدة الدرقية. حالات نادرة لإصابة الكبد.' },
    source: 'Bonilla DA et al. Effects of ashwagandha (Withania somnifera) on physical performance: systematic review and Bayesian meta-analysis. J Funct Morphol Kinesiol. 2021.',
  },
  {
    id: 'collagen',
    tier: 'mixed',
    name: { en: 'Collagen', ar: 'الكولاجين' },
    what: { en: 'Poor protein for building muscle (missing key amino acids), so do not count it toward muscle protein. May help tendons and joints when taken with vitamin C before exercise; evidence is early.', ar: 'بروتين ضعيف لبناء العضل. ممكن يفيد الأوتار والمفاصل والأدلة مبكرة.' },
    dose: { en: '10–15 g with ~50 mg vitamin C.', ar: '١٠–١٥ جم مع فيتامين سي.' },
    when: { en: '30–60 minutes before training or rehab exercises.', ar: 'قبل التمرين بـ ٣٠–٦٠ دقيقة.' },
    who: { en: 'People with tendon or joint niggles.', ar: 'اللي عندهم مشاكل أوتار أو مفاصل.' },
    source: 'Shaw G et al. Vitamin C-enriched gelatin supplementation before intermittent activity augments collagen synthesis. Am J Clin Nutr. 2017.',
  },

  // ───────── Skip ─────────
  {
    id: 'bcaa',
    tier: 'skip',
    name: { en: 'BCAAs / EAAs drinks', ar: 'أحماض BCAA' },
    what: { en: 'If you eat enough protein, BCAAs add nothing. They are an incomplete, expensive version of protein you already eat.', ar: 'إذا تاكل بروتين كافي، ما تضيف شي. نسخة غالية وناقصة من البروتين.' },
    dose: { en: 'Skip. Spend the money on food or whey.', ar: 'وفرها واشتر أكل أو واي.' },
    when: { en: '—', ar: '—' },
    who: { en: 'Nobody who hits their protein target.', ar: 'ما أحد يحتاجها إذا يوصل هدف البروتين.' },
    source: 'Wolfe RR. Branched-chain amino acids and muscle protein synthesis in humans: myth or reality? J Int Soc Sports Nutr. 2017.',
  },
  {
    id: 'fatburner',
    tier: 'skip',
    name: { en: 'Fat burners', ar: 'حارقات الدهون' },
    what: { en: 'Mostly caffeine plus extras. Effects on fat loss are tiny or unproven, and some products have been found to contain banned or dangerous ingredients.', ar: 'غالباً كافيين وإضافات. تأثيرها ضعيف وبعضها فيه مواد ممنوعة.' },
    dose: { en: 'Skip. A calorie deficit does the work.', ar: 'وفرها. العجز في السعرات هو اللي يحرق.' },
    when: { en: '—', ar: '—' },
    who: { en: 'Nobody.', ar: 'ما أحد.' },
    caution: { en: 'Linked to heart and liver problems in some cases.', ar: 'مرتبطة بمشاكل قلب وكبد في بعض الحالات.' },
    source: 'Jeukendrup AE, Randell R. Fat burners: nutrition supplements that increase fat metabolism. Obes Rev. 2011.',
  },
  {
    id: 'testbooster',
    tier: 'skip',
    name: { en: '"Testosterone boosters"', ar: 'معززات التستوستيرون' },
    what: { en: 'Herbal blends (tribulus, fenugreek etc.) do not meaningfully raise testosterone or muscle in healthy men. Most claims are not backed by research.', ar: 'الخلطات العشبية ما ترفع التستوستيرون بشكل مهم.' },
    dose: { en: 'Skip. Sleep, enough calories and training matter far more.', ar: 'وفرها. النوم والأكل والتمرين أهم بكثير.' },
    when: { en: '—', ar: '—' },
    who: { en: 'Nobody. If you suspect low testosterone, see a doctor.', ar: 'ما أحد. إذا تشك في نقص، روح للطبيب.' },
    source: 'Clemesha CG et al. Testosterone boosting supplements composition and claims are not supported by the academic literature. World J Mens Health. 2020.',
  },
  {
    id: 'glutamine',
    tier: 'skip',
    name: { en: 'Glutamine', ar: 'جلوتامين' },
    what: { en: 'No benefit for muscle growth, strength or recovery in healthy people.', ar: 'ما له فايدة للعضل أو الاستشفاء عند الأصحاء.' },
    dose: { en: 'Skip.', ar: 'وفرها.' },
    when: { en: '—', ar: '—' },
    who: { en: 'Nobody (outside medical settings).', ar: 'ما أحد.' },
    source: 'Gleeson M. Dosing and efficacy of glutamine supplementation in human exercise and sport training. J Nutr. 2008.',
  },
  {
    id: 'cla',
    tier: 'skip',
    name: { en: 'CLA', ar: 'CLA' },
    what: { en: 'Fat loss effect is about 0.05 kg per week in studies: too small to notice.', ar: 'تأثيره حوالي ٠٫٠٥ كجم بالأسبوع: ما ينلاحظ.' },
    dose: { en: 'Skip.', ar: 'وفرها.' },
    when: { en: '—', ar: '—' },
    who: { en: 'Nobody.', ar: 'ما أحد.' },
    source: 'Onakpoya IJ et al. The efficacy of long-term conjugated linoleic acid supplementation on body composition in overweight and obese individuals: a systematic review and meta-analysis. Eur J Nutr. 2012.',
  },
  {
    id: 'hmb',
    tier: 'skip',
    name: { en: 'HMB', ar: 'HMB' },
    what: { en: 'No meaningful effect on muscle or strength in young, trained people.', ar: 'ما له تأثير مهم على العضل عند الشباب المتدربين.' },
    dose: { en: 'Skip.', ar: 'وفرها.' },
    when: { en: '—', ar: '—' },
    who: { en: 'Nobody under ~60.', ar: 'ما أحد تحت ٦٠ سنة.' },
    source: 'Jakubowski JS et al. Supplementation with HMB does not improve resistance exercise-induced changes in body composition or strength in young subjects: a systematic review and meta-analysis. Nutrients. 2020.',
  },
];
