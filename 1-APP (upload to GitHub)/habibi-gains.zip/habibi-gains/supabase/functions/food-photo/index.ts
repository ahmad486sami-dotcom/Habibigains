// Supabase Edge Function: the smart camera's brain.
// One photo → Claude decides if it's a plate of food or a restaurant menu.
//   plate → estimated items with calories and macros
//   menu  → the 3 best dishes for what the user has left today
// Deploy:  supabase functions deploy food-photo
// Secret:  supabase secrets set ANTHROPIC_API_KEY=sk-ant-...
// Premium only (checked against profiles.is_premium).

import { createClient } from 'npm:@supabase/supabase-js@2';

const MODEL = Deno.env.get('FOOD_PHOTO_MODEL') ?? 'claude-haiku-5-5';
const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, apikey, x-client-info',
};

function prompt(remainingKcal: number, remainingProtein: number) {
  return `You are the camera of a fitness app used in the UAE. Look at the photo and decide what it is.

If it is a MEAL (food on a plate, in a box, etc.): estimate each item. Recognise Gulf and Middle Eastern dishes
(shawarma, machboos, mandi, harees, karak, luqaimat, manakeesh, etc.) and realistic restaurant portions.

If it is a MENU (printed or on a screen): read the dishes and choose up to 3 that best fit what the user has left today:
${remainingKcal} kcal and ${remainingProtein} g protein. Prefer high protein per calorie and simple swaps
(grilled over fried, sauce on the side). Estimate calories and macros for a normal restaurant portion.

Return ONLY JSON, no prose:
{"kind":"meal","items":[{"name_en":string,"name_ar":string,"portion":string,"kcal":number,"protein_g":number,"carbs_g":number,"fat_g":number}],"confidence":"low"|"medium"|"high"}
or
{"kind":"menu","picks":[{"name_en":string,"name_ar":string,"kcal":number,"protein_g":number,"carbs_g":number,"fat_g":number,"tip_en":string,"tip_ar":string}],"confidence":"low"|"medium"|"high"}
If it is neither, return {"kind":"none"}.`;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const apiKey = Deno.env.get('ANTHROPIC_API_KEY');
    if (!apiKey) return json({ error: 'not_configured' }, 503);

    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } },
    });
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return json({ error: 'unauthorized' }, 401);
    const { data: profile } = await supabase.from('profiles').select('is_premium').eq('id', user.id).single();
    if (!profile?.is_premium) return json({ error: 'premium_required' }, 402);

    const { imageBase64, mediaType = 'image/jpeg', remainingKcal = 700, remainingProtein = 40 } = await req.json();
    if (!imageBase64 || imageBase64.length > 7_000_000) return json({ error: 'bad_image' }, 400);

    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': apiKey, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 1000,
        messages: [{
          role: 'user',
          content: [
            { type: 'image', source: { type: 'base64', media_type: mediaType, data: imageBase64 } },
            { type: 'text', text: prompt(Math.max(0, Math.round(remainingKcal)), Math.max(0, Math.round(remainingProtein))) },
          ],
        }],
      }),
    });
    if (!res.ok) return json({ error: 'ai_failed', status: res.status }, 502);
    const body = await res.json();
    const text: string = body?.content?.[0]?.text ?? '';
    const match = text.match(/\{[\s\S]*\}/);
    const parsed = match ? JSON.parse(match[0]) : { kind: 'none' };
    return json(parsed, 200);
  } catch (e) {
    return json({ error: 'server_error', message: String(e) }, 500);
  }
});

function json(data: unknown, status: number) {
  return new Response(JSON.stringify(data), { status, headers: { ...cors, 'content-type': 'application/json' } });
}
