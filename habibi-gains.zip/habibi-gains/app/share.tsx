// Share studio: progress, a day of eating, or a run, as a 9:16 story image.
import { router, useLocalSearchParams } from 'expo-router';
import * as Sharing from 'expo-sharing';
import React, { useEffect, useRef, useState } from 'react';
import { Alert, Dimensions, ScrollView, View } from 'react-native';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import { captureRef } from 'react-native-view-shot';
import { useI18n } from '@/i18n/i18n';
import { fetchDayLogs, fetchTrend, getRun, Run, sumNutrients, FoodLog } from '@/lib/data';
import { dayLabel, MEAL_LABEL, mealsFor } from '@/lib/day';
import { success, warn } from '@/lib/haptics';
import { formatDuration, formatKm, formatPace } from '@/lib/runTracker';
import { useSession } from '@/lib/session';
import { todayISO } from '@/lib/supabase';
import { TrendPoint } from '@/lib/trend';
import { useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Chips, Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { ShareCard, ShareData } from '@/ui/ShareCard';
import { DayStory, RunStory } from '@/ui/StoryCards';
import { Txt } from '@/ui/Txt';

const CARD_W = Math.min(300, Dimensions.get('window').width - 80);

export default function Share() {
  const { lang } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { profile } = useSession();
  const p = useLocalSearchParams<{ kind?: 'progress' | 'day' | 'run'; day?: string; runId?: string }>();
  const kind = p.kind ?? 'progress';
  const ref = useRef<View>(null);
  const [busy, setBusy] = useState(false);

  // progress
  const [trend, setTrend] = useState<TrendPoint[]>([]);
  const [style, setStyle] = useState<ShareData['style']>('bold');
  const [hideKg, setHideKg] = useState(false);
  // day
  const [logs, setLogs] = useState<FoodLog[]>([]);
  // run
  const [run, setRun] = useState<Run | null>(null);

  useEffect(() => {
    if (kind === 'progress') fetchTrend(365).then(setTrend).catch(() => {});
    if (kind === 'day') fetchDayLogs(p.day ?? todayISO()).then(setLogs).catch(() => {});
    if (kind === 'run' && p.runId) getRun(p.runId).then(setRun).catch(() => {});
  }, [kind, p.day, p.runId]);

  const first = trend[0];
  const last = trend.at(-1);
  const days = first && last ? Math.max(1, Math.round((+new Date(last.date) - +new Date(first.date)) / 86_400_000)) : 0;
  const diff = first && last ? last.trend - first.trend : 0;
  const pct = first && last ? (diff / first.trend) * 100 : 0;
  const progressData: ShareData = {
    headline: hideKg ? `${pct > 0 ? '+' : ''}${pct.toFixed(1)}%` : `${diff > 0 ? '+' : ''}${diff.toFixed(1)} kg`,
    label: `${days}-day transformation`,
    stats: [
      { label: 'Day streak', value: String(profile?.streak_days ?? 0) },
      { label: 'XP', value: (profile?.xp ?? 0).toLocaleString('en-US') },
    ],
    points: trend.slice(-60),
    style,
  };

  const t = sumNutrients(logs);
  const ready = kind === 'progress' ? trend.length >= 2 : kind === 'day' ? logs.length > 0 : !!run;

  const share = async () => {
    if (!ref.current) return;
    setBusy(true);
    try {
      const uri = await captureRef(ref, { format: 'png', quality: 1, width: 1080, height: 1920 });
      success();
      await Sharing.shareAsync(uri, { mimeType: 'image/png', UTI: 'public.png', dialogTitle: L('Share', 'مشاركة') });
    } catch {
      warn();
      Alert.alert(L('Could not create the image', 'ما قدرنا نسوي الصورة'));
    } finally {
      setBusy(false);
    }
  };

  const title = kind === 'run' ? L('Share your run', 'شارك الجري') : kind === 'day' ? L('Share your day', 'شارك يومك') : L('Share progress', 'شارك تقدمك');

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.bg }} contentContainerStyle={{ padding: 20, gap: 18, alignItems: 'center', paddingBottom: 50 }}>
      <Row style={{ justifyContent: 'space-between', alignSelf: 'stretch' }}>
        <Txt v="h2">{title}</Txt>
        <Press onPress={() => router.back()} accessibilityLabel={L('Close', 'إغلاق')} style={{ padding: 6 }}>
          <Icon name="close" />
        </Press>
      </Row>

      <Animated.View key={`${kind}-${style}-${hideKg}`} entering={FadeIn.duration(300)} style={{ borderRadius: 24, borderWidth: 1, borderColor: theme.border }}>
        {kind === 'progress' ? <ShareCard ref={ref} data={progressData} width={CARD_W} /> : null}
        {kind === 'day' ? (
          <DayStory
            ref={ref}
            width={CARD_W}
            d={{
              dateLabel: dayLabel(p.day ?? todayISO(), 'en'),
              kcal: t.kcal,
              target: profile?.calorie_target ?? 2000,
              protein: t.protein_g,
              carbs: t.carbs_g,
              fat: t.fat_g,
              proteinTarget: profile?.protein_target_g ?? 140,
              meals: mealsFor(!!profile?.ramadan_mode).map((m) => ({ label: MEAL_LABEL[m].en, kcal: Math.round(logs.filter((l) => l.meal === m).reduce((s, l) => s + l.kcal, 0)) })),
              streak: profile?.streak_days ?? 0,
              accent: theme.accent,
            }}
          />
        ) : null}
        {kind === 'run' && run ? (
          <RunStory
            ref={ref}
            width={CARD_W}
            d={{
              title: run.title || 'Run',
              dateLabel: new Date(run.started_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
              km: formatKm(run.distance_m),
              time: formatDuration(run.moving_s * 1000),
              pace: formatPace(run.distance_m > 0 ? run.moving_s / (run.distance_m / 1000) : null),
              climb: run.elev_gain_m ? `${Math.round(run.elev_gain_m)} m` : null,
              kcal: run.kcal,
              route: run.route,
              accent: theme.accent,
            }}
          />
        ) : null}
      </Animated.View>

      <Animated.View entering={FadeInDown.delay(150)} style={{ alignSelf: 'stretch', gap: 14 }}>
        {kind === 'progress' ? (
          <>
            <Chips
              value={style}
              onChange={setStyle}
              options={[
                { value: 'bold', label: 'Bold' },
                { value: 'minimal', label: 'Minimal' },
                { value: 'accent', label: L('Colour', 'ملون') },
              ]}
            />
            <Press onPress={() => setHideKg(!hideKg)} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
              <View style={{ width: 24, height: 24, borderRadius: 7, backgroundColor: hideKg ? theme.accent : theme.cardHigh, alignItems: 'center', justifyContent: 'center' }}>
                {hideKg ? <Icon name="check" size={15} color={theme.onAccent} stroke={2.6} /> : null}
              </View>
              <Txt>{L('Show % instead of kg', 'اعرض النسبة بدل الكيلو')}</Txt>
            </Press>
          </>
        ) : null}
        <Button title={L('Share', 'مشاركة')} loading={busy} disabled={!ready} icon={<Icon name="share" color={theme.onAccent} size={20} />} onPress={share} />
        <Txt v="small" faint center>{L('Opens the share sheet: Instagram, WhatsApp, Snapchat, Save Image and more.', 'يفتح المشاركة: إنستغرام، واتساب، سناب، حفظ الصورة وغيرها.')}</Txt>
      </Animated.View>
    </ScrollView>
  );
}
