// Weigh-in with a smooth scroll wheel. Explains why daily numbers jump.
import { router } from 'expo-router';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { FlatList, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useI18n } from '@/i18n/i18n';
import { awardBadge, fetchTrend, logWeight } from '@/lib/data';
import { saveWeightToHealth } from '@/lib/health';
import { select, success } from '@/lib/haptics';
import { useSession } from '@/lib/session';
import { useTheme } from '@/theme/theme';
import { useCelebrate } from '@/ui/Celebrate';
import { Icon } from '@/ui/Icon';
import { Row } from '@/ui/Layout';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

const ITEM = 14; // px per 0.1 kg

export default function WeighIn() {
  const { t, lang } = useI18n();
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const celebrate = useCelebrate();
  const { session, profile } = useSession();
  const [value, setValue] = useState<number>(Number(profile?.start_weight_kg ?? 80));
  const [width, setWidth] = useState(0);
  const [saving, setSaving] = useState(false);
  const list = useRef<FlatList<number>>(null);
  const lastTick = useRef(0);

  const ticks = useMemo(() => Array.from({ length: (200 - 35) * 10 + 1 }, (_, i) => 35 + i / 10), []);

  useEffect(() => {
    fetchTrend(30)
      .then((tr) => {
        const last = tr.at(-1);
        if (last) setValue(last.weight);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (width > 0) {
      const idx = Math.round((value - 35) * 10);
      setTimeout(() => list.current?.scrollToOffset({ offset: idx * ITEM, animated: false }), 50);
    }
    // only on first layout
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [width]);

  const save = async () => {
    if (!session) return;
    setSaving(true);
    try {
      await logWeight(session.user.id, Math.round(value * 10) / 10);
      saveWeightToHealth(value);
      success();
      if (await awardBadge('first-weigh')) celebrate({ title: lang === 'ar' ? 'على الميزان' : 'On the Scale', icon: 'scale' });
      router.back();
    } finally {
      setSaving(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.bg, paddingTop: 16, paddingBottom: insets.bottom + 16 }}>
      <Row style={{ justifyContent: 'space-between', paddingHorizontal: 20 }}>
        <Txt v="h2">{t('logWeight')}</Txt>
        <Press onPress={() => router.back()} accessibilityLabel={t('close')} style={{ padding: 6 }}>
          <Icon name="close" />
        </Press>
      </Row>

      <View style={{ flex: 1, justifyContent: 'center', gap: 30 }}>
        <View style={{ alignItems: 'center' }}>
          <Txt v="hero" style={{ fontSize: 88, lineHeight: 92 }}>{value.toFixed(1)}</Txt>
          <Txt v="h3" muted>{t('kg')}</Txt>
        </View>

        <View onLayout={(e) => setWidth(e.nativeEvent.layout.width)} style={{ height: 90, direction: 'ltr' }}>
          {width > 0 ? (
            <FlatList
              ref={list}
              data={ticks}
              horizontal
              showsHorizontalScrollIndicator={false}
              keyExtractor={(v) => v.toFixed(1)}
              getItemLayout={(_, i) => ({ length: ITEM, offset: ITEM * i, index: i })}
              contentContainerStyle={{ paddingHorizontal: width / 2 - ITEM / 2 }}
              snapToInterval={ITEM}
              decelerationRate="fast"
              scrollEventThrottle={16}
              initialNumToRender={80}
              windowSize={7}
              onScroll={(e) => {
                const idx = Math.round(e.nativeEvent.contentOffset.x / ITEM);
                const v = Math.min(200, Math.max(35, 35 + idx / 10));
                if (idx !== lastTick.current) {
                  lastTick.current = idx;
                  select();
                  setValue(v);
                }
              }}
              renderItem={({ item }) => {
                const whole = Math.abs(item - Math.round(item)) < 0.001;
                const half = !whole && Math.abs(item * 2 - Math.round(item * 2)) < 0.001;
                return (
                  <View style={{ width: ITEM, alignItems: 'center' }}>
                    <View style={{ width: 2, height: whole ? 46 : half ? 32 : 20, backgroundColor: whole ? theme.text : theme.faint, borderRadius: 1 }} />
                    {whole ? <Txt v="small" faint style={{ marginTop: 6, width: 40, textAlign: 'center' }}>{Math.round(item)}</Txt> : null}
                  </View>
                );
              }}
            />
          ) : null}
          <View pointerEvents="none" style={{ position: 'absolute', left: width / 2 - 2, top: -6, width: 4, height: 60, borderRadius: 2, backgroundColor: theme.accent }} />
        </View>

        <Txt v="small" muted center style={{ paddingHorizontal: 32 }}>{t('weighTip')}</Txt>
      </View>

      <View style={{ paddingHorizontal: 20 }}>
        <Button title={t('save')} loading={saving} onPress={save} />
      </View>
    </View>
  );
}
