// Find a food: search the database, or pick from recent, favourites and your own foods / recipes.
import { router, useFocusEffect, useLocalSearchParams } from 'expo-router';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, FlatList, KeyboardAvoidingView, Platform, TextInput, View } from 'react-native';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import { useI18n } from '@/i18n/i18n';
import { addFoodLog, favoriteFoods, Food, FoodLog, foodName, Meal, myFoods, popularFoods, recentFoods, searchFatSecret, searchFoods, FsFood } from '@/lib/data';
import { defaultMeal, MEAL_LABEL, mealsFor, servingText } from '@/lib/day';
import { select, success } from '@/lib/haptics';
import { useSession } from '@/lib/session';
import { todayISO } from '@/lib/supabase';
import { fonts, useTheme } from '@/theme/theme';
import { Icon } from '@/ui/Icon';
import { Chips, Row } from '@/ui/Layout';
import { Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

type Tab = 'search' | 'recent' | 'favorites' | 'mine';

export default function AddFood() {
  const { lang, isRTL } = useI18n();
  const L = (en: string, ar: string) => (lang === 'ar' ? ar : en);
  const { theme } = useTheme();
  const { profile } = useSession();
  const params = useLocalSearchParams<{ meal?: Meal; day?: string; mode?: 'recipe' }>();
  const recipeMode = params.mode === 'recipe';
  const day = params.day ?? todayISO();
  const [meal, setMeal] = useState<Meal>(params.meal ?? defaultMeal(!!profile?.ramadan_mode));

  const [tab, setTab] = useState<Tab>('search');
  const [q, setQ] = useState('');
  const [results, setResults] = useState<Food[]>([]);
  const [searching, setSearching] = useState(false);
  const [recent, setRecent] = useState<FoodLog[]>([]);
  const [favs, setFavs] = useState<Food[]>([]);
  const [mine, setMine] = useState<Food[]>([]);
  const [popular, setPopular] = useState<Food[]>([]);
  const [fs, setFs] = useState<FsFood[]>([]);
  const [added, setAdded] = useState<string | null>(null);
  const seq = useRef(0);

  useFocusEffect(
    useCallback(() => {
      recentFoods().then(setRecent).catch(() => {});
      favoriteFoods().then(setFavs).catch(() => {});
      myFoods().then(setMine).catch(() => {});
      popularFoods().then(setPopular).catch(() => {});
    }, []),
  );

  useEffect(() => {
    const term = q.trim();
    if (term.length < 2) {
      setResults([]);
      setFs([]);
      setSearching(false);
      return;
    }
    setSearching(true);
    const id = ++seq.current;
    const h = setTimeout(() => {
      searchFatSecret(term).then((r) => id === seq.current && setFs(r)).catch(() => {});
      searchFoods(term)
        .then((r) => id === seq.current && setResults(r))
        .catch(() => id === seq.current && setResults([]))
        .finally(() => id === seq.current && setSearching(false));
    }, 250);
    return () => clearTimeout(h);
  }, [q]);

  const openFood = (f: Food) => {
    select();
    router.push({ pathname: '/food/[id]', params: { id: f.id, meal, day, from: 'add', ...(recipeMode ? { mode: 'recipe' } : {}) } });
  };

  // Re-log a recent item exactly as before (one tap, like MyFitnessPal's quick add from history).
  const relog = async (l: FoodLog) => {
    if (recipeMode) {
      if (l.food_id) router.push({ pathname: '/food/[id]', params: { id: l.food_id, mode: 'recipe' } });
      return;
    }
    const { id: _id, logged_on: _d, created_at: _c, meal: _m, ...rest } = l;
    await addFoodLog({ ...rest, meal, source: 'search' }, day);
    success();
    setAdded(l.id);
    setTimeout(() => setAdded((a) => (a === l.id ? null : a)), 1400);
  };

  // Log one FatSecret serving straight to the chosen meal.
  const logFs = async (f: FsFood) => {
    await addFoodLog({
      food_id: null, name: f.name, brand: f.brand, meal, quantity: 1, serving_label: f.per, serving_g: null, source: 'search',
      kcal: f.kcal, protein_g: f.protein, carbs_g: f.carbs, fat_g: f.fat, fiber_g: null, sugar_g: null, sodium_mg: null, sat_fat_g: null, cholesterol_mg: null, potassium_mg: null,
    }, day);
    success();
    setAdded(f.id);
    setTimeout(() => setAdded((a) => (a === f.id ? null : a)), 1400);
  };

  const row = (key: string, title: string, sub: string, kcal: number, onPress: () => void, extra?: React.ReactNode, index = 0) => (
    <Animated.View key={key} entering={FadeInDown.delay(Math.min(index, 8) * 25)}>
      <Press haptic={false} onPress={onPress} scaleTo={0.98} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 15, borderRadius: 18, backgroundColor: theme.card }}>
        <View style={{ flex: 1, gap: 2 }}>
          <Txt v="bodyStrong" numberOfLines={2}>{title}</Txt>
          <Txt v="small" faint numberOfLines={1}>{sub}</Txt>
        </View>
        <Txt v="bodyStrong">{Math.round(kcal)}</Txt>
        {extra}
      </Press>
    </Animated.View>
  );

  const foodSub = (f: Food) => {
    const s = f.servings[0];
    const tag = f.source === 'uae' ? 'UAE' : f.source === 'recipe' ? L('Recipe', 'وصفة') : f.source === 'user' ? L('My food', 'أكلي') : f.brand ?? null;
    if (s) {
      const k = Math.round((f.kcal * s.g) / f.base_g);
      return { sub: [tag, s.label, `${Math.round(f.protein_g * s.g / f.base_g)}g ${L('protein', 'بروتين')}`].filter(Boolean).join(' · '), kcal: k };
    }
    return { sub: [tag, `${f.base_g} g`, `${Math.round(f.protein_g)}g ${L('protein', 'بروتين')}`].filter(Boolean).join(' · '), kcal: f.kcal };
  };

  const foodRow = (f: Food, i: number) => {
    const { sub, kcal } = foodSub(f);
    return row(f.id, foodName(f, lang), sub, kcal, () => openFood(f), undefined, i);
  };

  const heading = (key: string, text: string) => (
    <Txt key={key} v="label" muted style={{ marginTop: 8, marginLeft: 4 }}>{text}</Txt>
  );

  const recentRow = (l: FoodLog, i: number) =>
    row(
      l.id,
      l.name,
      [l.brand, servingText(l.quantity, l.serving_label)].filter(Boolean).join(' · '),
      l.kcal,
      () => (l.food_id ? router.push({ pathname: '/food/[id]', params: { id: l.food_id, meal, day, from: 'add', ...(recipeMode ? { mode: 'recipe' } : {}) } }) : relog(l)),
      recipeMode ? undefined : (
        <Press onPress={() => relog(l)} accessibilityLabel={L('Add again', 'أضف مرة ثانية')} style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: added === l.id ? theme.accent : theme.cardHigh, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name={added === l.id ? 'check' : 'plus'} size={16} color={added === l.id ? theme.onAccent : theme.text} />
        </Press>
      ),
      i,
    );

  const list: React.ReactNode[] = (() => {
    // Before typing: Recently logged (2 taps to re-log) + Popular in the UAE, like MyFitnessPal's search screen.
    if (tab === 'search' && q.trim().length < 2) {
      const out: React.ReactNode[] = [];
      if (recent.length) out.push(heading('h-recent', L('Recently logged', 'سجلته مؤخراً')), ...recent.slice(0, 5).map(recentRow));
      if (popular.length) out.push(heading('h-popular', L('Popular in the UAE', 'الأكثر شيوعاً في الإمارات')), ...popular.map(foodRow));
      return out;
    }
    if (tab === 'search') {
      const out: React.ReactNode[] = results.map(foodRow);
      if (fs.length && !recipeMode) {
        out.push(heading('h-fs', L('More foods', 'أكلات أكثر')));
        fs.forEach((f, i) => out.push(row(f.id, f.name, [f.brand, L(`per ${f.per}`, `لكل ${f.per}`), `${Math.round(f.protein)}g ${L('protein', 'بروتين')}`].filter(Boolean).join(' · '), f.kcal, () => logFs(f), (
          <Press onPress={() => logFs(f)} accessibilityLabel={L('Add', 'أضف')} style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: added === f.id ? theme.accent : theme.cardHigh, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name={added === f.id ? 'check' : 'plus'} size={16} color={added === f.id ? theme.onAccent : theme.text} />
          </Press>
        ), i)));
      }
      return out;
    }
    if (tab === 'favorites') return favs.map(foodRow);
    if (tab === 'mine') return mine.map(foodRow);
    return recent.map((l, i) =>
      row(
        l.id,
        l.name,
        [l.brand, servingText(l.quantity, l.serving_label)].filter(Boolean).join(' · '),
        l.kcal,
        () => (l.food_id ? router.push({ pathname: '/food/[id]', params: { id: l.food_id, meal, day, from: 'add', ...(recipeMode ? { mode: 'recipe' } : {}) } }) : relog(l)),
        recipeMode ? undefined : (
          <Press onPress={() => relog(l)} accessibilityLabel={L('Add again', 'أضف مرة ثانية')} style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: added === l.id ? theme.accent : theme.cardHigh, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name={added === l.id ? 'check' : 'plus'} size={16} color={added === l.id ? theme.onAccent : theme.text} />
          </Press>
        ),
        i,
      ),
    );
  })();

  const empty = (() => {
    if (tab === 'search') {
      if (q.trim().length < 2) return L('Type at least 2 letters. Try "chicken breast", "karak" or "oats".', 'اكتب حرفين على الأقل. جرب "دجاج" أو "كرك".');
      if (searching) return '';
      return L('No match. Try fewer words, or create it as your own food.', 'ما لقينا شي. جرب كلمات أقل أو أضفه كأكلك الخاص.');
    }
    if (tab === 'recent') return L('Foods you log show up here.', 'الأكل اللي تسجله يطلع هنا.');
    if (tab === 'favorites') return L('Tap the star on any food to save it here.', 'اضغط النجمة على أي أكل عشان تحفظه هنا.');
    return L('Your own foods and recipes live here.', 'أكلاتك ووصفاتك الخاصة هنا.');
  })();

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: theme.bg }}>
      <View style={{ paddingTop: 16, paddingHorizontal: 20, gap: 12, flex: 1 }}>
        <Row style={{ justifyContent: 'space-between' }}>
          <Txt v="h2">{recipeMode ? L('Add ingredient', 'أضف مكون') : L('Add food', 'أضف أكل')}</Txt>
          <Press onPress={() => router.back()} accessibilityLabel={L('Close', 'إغلاق')} style={{ padding: 6 }}>
            <Icon name="close" />
          </Press>
        </Row>

        {!recipeMode ? (
          <Chips value={meal} onChange={setMeal} options={mealsFor(!!profile?.ramadan_mode).map((m) => ({ value: m, label: L(MEAL_LABEL[m].en, MEAL_LABEL[m].ar) }))} />
        ) : null}

        <Row gap={10}>
          <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: theme.card, borderRadius: 999, height: 52, paddingHorizontal: 16 }}>
            <Icon name="search" size={19} color={theme.muted} />
            <TextInput
              value={q}
              onChangeText={(v) => {
                setQ(v);
                if (tab !== 'search') setTab('search');
              }}
              placeholder={L('Search foods', 'ابحث عن أكل')}
              placeholderTextColor={theme.faint}
              selectionColor={theme.accent}
              autoFocus
              autoCorrect={false}
              returnKeyType="search"
              style={{ flex: 1, color: theme.text, fontSize: 16, fontFamily: isRTL ? undefined : fonts.bodyMedium, textAlign: isRTL ? 'right' : 'left' }}
            />
            {searching ? <ActivityIndicator color={theme.muted} /> : q ? (
              <Press onPress={() => setQ('')} style={{ padding: 4 }}>
                <Icon name="close" size={16} color={theme.muted} />
              </Press>
            ) : null}
          </View>
          <Press
            onPress={() => router.push({ pathname: '/scan', params: { meal, day, from: 'add', ...(recipeMode ? { mode: 'recipe' } : {}) } })}
            accessibilityLabel={L('Scan barcode', 'مسح الباركود')}
            style={{ width: 52, height: 52, borderRadius: 26, backgroundColor: theme.card, alignItems: 'center', justifyContent: 'center' }}
          >
            <Icon name="scan" />
          </Press>
        </Row>

        {/* Always-visible actions, like MyFitnessPal's tile row */}
        <Row gap={8}>
          {[
            { icon: 'scan' as const, label: L('Scan', 'مسح'), go: () => router.push({ pathname: '/scan', params: { meal, day, from: 'add', ...(recipeMode ? { mode: 'recipe' } : {}) } }) },
            ...(!recipeMode ? [{ icon: 'bolt' as const, label: L('Quick add', 'سريع'), go: () => router.push({ pathname: '/food/quick', params: { meal, day } }) }] : []),
            { icon: 'plus' as const, label: L('New food', 'أكل جديد'), go: () => router.push({ pathname: '/food/create', params: { name: q.trim() } }) },
            ...(!recipeMode ? [{ icon: 'mic' as const, label: L('Voice', 'صوت'), go: () => router.push({ pathname: '/voice-log', params: { meal, day } }) }] : []),
          ].map((a) => (
            <Press key={a.label} onPress={a.go} style={{ flex: 1, alignItems: 'center', gap: 6, paddingVertical: 12, borderRadius: 16, backgroundColor: theme.card }}>
              <Icon name={a.icon} size={20} color={theme.accent} />
              <Txt v="small" style={{ fontSize: 12 }}>{a.label}</Txt>
            </Press>
          ))}
        </Row>
        <Chips
          value={tab}
          onChange={setTab}
          options={[
            { value: 'search', label: L('Search', 'بحث') },
            { value: 'recent', label: L('Recent', 'الأخيرة') },
            { value: 'favorites', label: L('Favourites', 'المفضلة') },
            { value: 'mine', label: L('My foods', 'أكلاتي') },
          ]}
        />

        <FlatList
          data={list}
          keyExtractor={(_, i) => String(i)}
          renderItem={({ item }) => <>{item}</>}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="on-drag"
          contentContainerStyle={{ gap: 8, paddingBottom: 140 }}
          ListEmptyComponent={empty ? <Animated.View entering={FadeIn}><Txt muted style={{ padding: 8 }}>{empty}</Txt></Animated.View> : null}
          ListFooterComponent={
            <View style={{ gap: 8, marginTop: 14 }}>
              {tab === 'search' && results.length ? (
                <Txt v="small" faint style={{ marginTop: 6 }}>
                  {L('Nutrition data: USDA FoodData Central, Habibi Gains UAE dishes, Open Food Facts (ODbL) and FatSecret.', 'بيانات التغذية من وزارة الزراعة الأمريكية وأطباق الإمارات من حبيبي جينز.')}
                </Txt>
              ) : null}
            </View>
          }
        />
      </View>
    </KeyboardAvoidingView>
  );
}

const actionStyle = (theme: { card: string }) => ({
  flexDirection: 'row' as const,
  alignItems: 'center' as const,
  gap: 12,
  padding: 16,
  borderRadius: 18,
  backgroundColor: theme.card,
});
