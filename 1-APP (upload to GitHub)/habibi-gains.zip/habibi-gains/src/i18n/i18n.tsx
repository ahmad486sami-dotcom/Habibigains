import AsyncStorage from '@react-native-async-storage/async-storage';
import { getLocales } from 'expo-localization';
import * as Updates from 'expo-updates';
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { I18nManager } from 'react-native';
import { ar, en, Strings } from './strings';

export type Lang = 'en' | 'ar';
type Ctx = {
  lang: Lang;
  isRTL: boolean;
  t: (key: keyof Strings, vars?: Record<string, string | number>) => string;
  setLang: (l: Lang) => Promise<void>;
};

const I18nCtx = createContext<Ctx | null>(null);
const KEY = 'hg.lang';

function deviceLang(): Lang {
  try {
    return getLocales()[0]?.languageCode === 'ar' ? 'ar' : 'en';
  } catch {
    return 'en';
  }
}

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Lang>(I18nManager.isRTL ? 'ar' : 'en');

  useEffect(() => {
    AsyncStorage.getItem(KEY)
      .then((v) => {
        const l: Lang = v === 'ar' || v === 'en' ? v : deviceLang();
        setLangState(l);
        syncDirection(l);
      })
      .catch(() => {});
  }, []);

  const t = useCallback(
    (key: keyof Strings, vars?: Record<string, string | number>) => {
      let s = (lang === 'ar' ? ar : en)[key] ?? en[key] ?? String(key);
      if (vars) for (const k of Object.keys(vars)) s = s.replace(`{${k}}`, String(vars[k]));
      return s;
    },
    [lang],
  );

  const setLang = useCallback(async (l: Lang) => {
    await AsyncStorage.setItem(KEY, l);
    setLangState(l);
    const changed = syncDirection(l);
    // Layout direction only fully applies after a reload.
    if (changed) {
      try {
        await Updates.reloadAsync();
      } catch {
        // In development, reload manually.
      }
    }
  }, []);

  const value = useMemo(() => ({ lang, isRTL: lang === 'ar', t, setLang }), [lang, t, setLang]);
  return <I18nCtx.Provider value={value}>{children}</I18nCtx.Provider>;
}

function syncDirection(l: Lang) {
  const wantRTL = l === 'ar';
  if (I18nManager.isRTL !== wantRTL) {
    I18nManager.allowRTL(wantRTL);
    I18nManager.forceRTL(wantRTL);
    return true;
  }
  return false;
}

export function useI18n() {
  const ctx = useContext(I18nCtx);
  if (!ctx) throw new Error('useI18n outside I18nProvider');
  return ctx;
}
