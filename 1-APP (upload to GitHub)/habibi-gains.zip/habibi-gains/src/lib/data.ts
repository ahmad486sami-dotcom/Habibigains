// Data access used by the screens. Everything is stored in Supabase and protected by row level security.
import { useCallback, useEffect, useState } from 'react';
import { supabase, todayISO } from './supabase';
import { buildTrend, TrendPoint } from './trend';

// ───────────────────────── Types ─────────────────────────
export type Meal = 'breakfast' | 'lunch' | 'dinner' | 'snack' | 'suhoor' | 'iftar';

export type Nutrients = {
  kcal: number;
  protein_g: number;
  carbs_g: number;
  fat_g: number;
  fiber_g: number | null;
  sugar_g: number | null;
  sodium_mg: number | null;
  sat_fat_g: number | null;
  cholesterol_mg: number | null;
  potassium_mg: number | null;
};
export const NUTRIENT_KEYS = ['kcal', 'protein_g', 'carbs_g', 'fat_g', 'fiber_g', 'sugar_g', 'sodium_mg', 'sat_fat_g', 'cholesterol_mg', 'potassium_mg'] as const;

export type Serving = { label: string; g: number };
export type Ingredient = { food_id: string; name: string; serving_label: string; serving_g: number; quantity: number; grams: number } & Nutrients;

export type Food = Nutrients & {
  id: string;
  name_en: string;
  name_ar: string | null;
  brand: string | null;
  source: 'usda' | 'uae' | 'off' | 'user' | 'recipe';
  base_g: number; // nutrients above are per this many grams
  servings: Serving[];
  barcode: string | null;
  is_local: boolean;
  created_by: string | null;
  ingredients: Ingredient[] | null;
  recipe_servings: number | null;
  is_shared?: boolean;
  cooked_count?: number;
};

export type FoodLog = Nutrients & {
  id: string;
  food_id: string | null;
  name: string;
  brand: string | null;
  meal: Meal;
  quantity: number;
  serving_label: string;
  serving_g: number | null;
  logged_on: string;
  source: string;
  created_at?: string;
};

export type EventRow = {
  id: string;
  host_id: string;
  title: string;
  description: string | null;
  location_name: string;
  emirate: string;
  starts_at: string;
  badge_name: string;
  xp: number;
  checkin_code: string | null;
  women_only: boolean;
  going: number;
  i_am_going: boolean;
};

export type Quest = {
  id: string;
  title_en: string;
  title_ar: string | null;
  description: string | null;
  proof: 'photo' | 'steps' | 'checkin' | 'honor';
  target_steps: number | null;
  xp: number;
  ends_on: string;
};

export type RunPoint = { lat: number; lng: number; t: number; alt?: number | null };
export type Split = { km: number; s: number };
export type Run = {
  id: string;
  title: string | null;
  started_at: string;
  ended_at: string;
  moving_s: number;
  elapsed_s: number;
  distance_m: number;
  kcal: number;
  elev_gain_m: number | null;
  route: [number, number][];
  splits: Split[];
};

// ───────────────────────── Helpers ─────────────────────────
const num = (v: unknown) => (v === null || v === undefined || v === '' ? null : Number(v));
const r1 = (v: number) => Math.round(v * 10) / 10;

function toFood(row: any): Food {
  return {
    ...row,
    base_g: Number(row.base_g) || 100,
    kcal: Number(row.kcal) || 0,
    protein_g: Number(row.protein_g) || 0,
    carbs_g: Number(row.carbs_g) || 0,
    fat_g: Number(row.fat_g) || 0,
    fiber_g: num(row.fiber_g),
    sugar_g: num(row.sugar_g),
    sodium_mg: num(row.sodium_mg),
    sat_fat_g: num(row.sat_fat_g),
    cholesterol_mg: num(row.cholesterol_mg),
    potassium_mg: num(row.potassium_mg),
    servings: Array.isArray(row.servings) ? row.servings : [],
    recipe_servings: num(row.recipe_servings),
  };
}

function toLog(row: any): FoodLog {
  return {
    ...row,
    quantity: Number(row.quantity) || 1,
    serving_g: num(row.serving_g),
    kcal: Number(row.kcal) || 0,
    protein_g: Number(row.protein_g) || 0,
    carbs_g: Number(row.carbs_g) || 0,
    fat_g: Number(row.fat_g) || 0,
    fiber_g: num(row.fiber_g),
    sugar_g: num(row.sugar_g),
    sodium_mg: num(row.sodium_mg),
    sat_fat_g: num(row.sat_fat_g),
    cholesterol_mg: num(row.cholesterol_mg),
    potassium_mg: num(row.potassium_mg),
  };
}

/** All the ways this food can be measured: its own servings, then plain grams. */
export function servingOptions(f: Food): Serving[] {
  const out: Serving[] = [...f.servings.filter((s) => s && s.g > 0)];
  if (f.source !== 'recipe') {
    if (!out.some((s) => s.label === '100 g')) out.push({ label: '100 g', g: 100 });
    out.push({ label: 'g', g: 1 });
  }
  return out.length ? out : [{ label: '1 serving', g: f.base_g }];
}

/** Nutrients for `grams` of a food. */
export function nutrientsFor(f: Food, grams: number): Nutrients {
  const k = grams / (f.base_g || 100);
  const o = {} as Nutrients;
  for (const key of NUTRIENT_KEYS) {
    const v = f[key];
    (o as any)[key] = v === null || v === undefined ? null : key === 'kcal' ? Math.round(Number(v) * k) : r1(Number(v) * k);
  }
  return o;
}

export function sumNutrients(rows: Partial<Nutrients>[]): Nutrients {
  const o = { kcal: 0, protein_g: 0, carbs_g: 0, fat_g: 0, fiber_g: 0, sugar_g: 0, sodium_mg: 0, sat_fat_g: 0, cholesterol_mg: 0, potassium_mg: 0 } as Nutrients;
  for (const r of rows) for (const k of NUTRIENT_KEYS) (o as any)[k] += Number(r[k] ?? 0) || 0;
  for (const k of NUTRIENT_KEYS) (o as any)[k] = k === 'kcal' ? Math.round(o[k] as number) : r1(o[k] as number);
  return o;
}

export function foodName(f: { name_en: string; name_ar: string | null }, lang: string) {
  return lang === 'ar' && f.name_ar ? f.name_ar : f.name_en;
}

/** Generic loader with refresh. */
export function useQuery<T>(fn: () => Promise<T>, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const run = useCallback(async () => {
    setLoading(true);
    try {
      setData(await fn());
      setError(null);
    } catch (e: any) {
      setError(e?.message ?? 'error');
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  useEffect(() => {
    run();
  }, [run]);
  return { data, loading, error, refresh: run };
}

async function uid() {
  const { data } = await supabase.auth.getSession();
  const id = data.session?.user.id;
  if (!id) throw new Error('not_signed_in');
  return id;
}

import { endFastIfRunning } from './fasting';

// ───────────────────────── Food diary ─────────────────────────
export async function fetchDayLogs(day = todayISO()) {
  const { data, error } = await supabase.from('food_logs').select('*').eq('logged_on', day).order('created_at');
  if (error) throw error;
  return (data ?? []).map(toLog);
}

export async function fetchDailyTotals(days = 35) {
  const since = todayISO(new Date(Date.now() - days * 86_400_000));
  const { data, error } = await supabase.from('food_logs').select('logged_on,kcal').gte('logged_on', since).lt('logged_on', todayISO());
  if (error) throw error;
  const map = new Map<string, number>();
  (data ?? []).forEach((r: any) => map.set(r.logged_on, (map.get(r.logged_on) ?? 0) + Number(r.kcal)));
  return [...map.entries()].map(([day, kcal]) => ({ day, kcal }));
}

export type NewLog = Omit<FoodLog, 'id' | 'logged_on' | 'created_at'>;

/** Log `quantity` × `serving` of a food. */
export function logFromFood(f: Food, serving: Serving, quantity: number, meal: Meal, lang: string, source = 'search'): NewLog {
  return {
    food_id: f.id || null,
    name: foodName(f, lang),
    brand: f.brand,
    meal,
    quantity,
    serving_label: serving.label,
    serving_g: serving.g,
    source,
    ...nutrientsFor(f, serving.g * quantity),
  };
}

export async function addFoodLog(entry: NewLog, day = todayISO()) {
  const user_id = await uid();
  const { error } = await supabase.from('food_logs').insert({ ...entry, user_id, logged_on: day });
  if (error) throw error;
  endFastIfRunning().catch(() => {}); // logging food ends a running fast
}

export async function updateFoodLog(id: string, patch: Partial<NewLog>) {
  const { error } = await supabase.from('food_logs').update(patch).eq('id', id);
  if (error) throw error;
}

export async function deleteFoodLog(id: string) {
  const { error } = await supabase.from('food_logs').delete().eq('id', id);
  if (error) throw error;
}

export async function getFoodLog(id: string) {
  const { data, error } = await supabase.from('food_logs').select('*').eq('id', id).single();
  if (error) throw error;
  return toLog(data);
}

/** Copy one meal (or the whole day) from one date to another. */
export async function copyMeal(fromDay: string, toDay: string, meal?: Meal) {
  const user_id = await uid();
  let q = supabase.from('food_logs').select('*').eq('logged_on', fromDay);
  if (meal) q = q.eq('meal', meal);
  const { data, error } = await q;
  if (error) throw error;
  const rows = (data ?? []).map(({ id: _i, created_at: _c, user_id: _u, logged_on: _d, ...rest }: any) => ({ ...rest, user_id, logged_on: toDay, source: 'copy' }));
  if (!rows.length) return 0;
  const { error: e2 } = await supabase.from('food_logs').insert(rows);
  if (e2) throw e2;
  return rows.length;
}

// ───────────────────────── Food database ─────────────────────────
export async function searchFoods(q: string): Promise<Food[]> {
  const term = q.trim();
  if (term.length < 2) return [];
  const { data, error } = await supabase.rpc('search_foods', { q: term, lim: 40 });
  if (error) throw error;
  return ((data ?? []) as any[]).map(toFood);
}

export async function getFood(id: string) {
  const { data, error } = await supabase.from('foods').select('*').eq('id', id).single();
  if (error) throw error;
  return toFood(data);
}

/** Popular in the UAE: local dishes and staples shown before the user types. */
export async function popularFoods(limit = 15): Promise<Food[]> {
  const { data, error } = await supabase.from('foods').select('*').or('is_local.eq.true,source.eq.uae').limit(limit);
  if (error) throw error;
  return ((data ?? []) as any[]).map(toFood);
}

/** Recently logged foods, most recent first, one row per food. */
export async function recentFoods(limit = 30): Promise<FoodLog[]> {
  const { data, error } = await supabase.from('food_logs').select('*').order('created_at', { ascending: false }).limit(200);
  if (error) throw error;
  const seen = new Set<string>();
  const out: FoodLog[] = [];
  for (const row of data ?? []) {
    const key = row.food_id ?? `name:${row.name}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(toLog(row));
    if (out.length >= limit) break;
  }
  return out;
}

export async function favoriteFoods(): Promise<Food[]> {
  const { data, error } = await supabase.from('favorite_foods').select('created_at, foods(*)').order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []).map((r: any) => r.foods).filter(Boolean).map(toFood);
}

export async function isFavorite(foodId: string) {
  const { data } = await supabase.from('favorite_foods').select('food_id').eq('food_id', foodId).maybeSingle();
  return !!data;
}

export async function setFavorite(foodId: string, on: boolean) {
  const user_id = await uid();
  if (on) {
    const { error } = await supabase.from('favorite_foods').upsert({ user_id, food_id: foodId });
    if (error) throw error;
  } else {
    const { error } = await supabase.from('favorite_foods').delete().eq('food_id', foodId).eq('user_id', user_id);
    if (error) throw error;
  }
}

/** Recipes other people chose to share, newest first. */
export async function sharedRecipes(): Promise<Food[]> {
  const { data, error } = await supabase.from('foods').select('*').eq('source', 'recipe').eq('is_shared', true).order('shared_at', { ascending: false }).limit(50);
  if (error) throw error;
  return ((data ?? []) as any[]).map(toFood);
}

export async function setRecipeShared(id: string, on: boolean) {
  const { error } = await supabase.from('foods').update({ is_shared: on, shared_at: on ? new Date().toISOString() : null }).eq('id', id);
  if (error) throw error;
}

export async function markCooked(id: string): Promise<number | null> {
  const { data, error } = await supabase.rpc('mark_cooked', { recipe_id: id });
  if (error) throw error;
  return typeof data === 'number' ? data : null;
}

/** Foods and recipes this user created. */
export async function myFoods(): Promise<Food[]> {
  const user_id = await uid();
  const { data, error } = await supabase
    .from('foods')
    .select('*')
    .eq('created_by', user_id)
    .in('source', ['user', 'recipe'])
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []).map(toFood);
}

export type FoodInput = {
  name_en: string;
  brand?: string | null;
  serving_label: string; // e.g. "1 bar"
  serving_g: number | null; // grams in that serving, if known
  per: Nutrients; // nutrients for ONE serving
  barcode?: string | null;
};

/** Save a custom food. Values are entered per serving, like a nutrition label. */
export async function saveCustomFood(input: FoodInput, id?: string) {
  const created_by = await uid();
  const g = input.serving_g && input.serving_g > 0 ? input.serving_g : 100;
  const row = {
    name_en: input.name_en.trim().slice(0, 160),
    brand: input.brand?.trim() || null,
    source: 'user',
    search_text: `${input.name_en} ${input.brand ?? ''}`.toLowerCase(),
    base_g: g,
    servings: [{ label: input.serving_label.trim() || '1 serving', g }],
    barcode: input.barcode || null,
    created_by,
    verified: false,
    ...input.per,
  };
  const q = id ? supabase.from('foods').update(row).eq('id', id) : supabase.from('foods').insert(row);
  const { data, error } = await q.select('*').single();
  if (error) throw error;
  return toFood(data);
}

/** Save a recipe: nutrients are stored for ONE serving of the finished dish. */
export async function saveRecipe(name: string, servings: number, ingredients: Ingredient[], id?: string) {
  const created_by = await uid();
  const total = sumNutrients(ingredients);
  const totalG = ingredients.reduce((s, i) => s + i.grams, 0);
  const n = Math.max(1, servings);
  const perServingG = Math.max(1, Math.round(totalG / n));
  const per = {} as Nutrients;
  for (const k of NUTRIENT_KEYS) (per as any)[k] = k === 'kcal' ? Math.round(total.kcal / n) : r1((total[k] as number) / n);
  const row = {
    name_en: name.trim().slice(0, 160),
    source: 'recipe',
    search_text: name.toLowerCase(),
    base_g: perServingG,
    servings: [{ label: '1 serving', g: perServingG }],
    ingredients,
    recipe_servings: n,
    created_by,
    verified: false,
    ...per,
  };
  const q = id ? supabase.from('foods').update(row).eq('id', id) : supabase.from('foods').insert(row);
  const { data, error } = await q.select('*').single();
  if (error) throw error;
  return toFood(data);
}

export async function deleteCustomFood(id: string) {
  const { error } = await supabase.from('foods').delete().eq('id', id);
  if (error) throw error;
}

/** Barcode → this user's foods / earlier scans first, then Open Food Facts (free, open data). */
export type BarcodeResult = { food: Food } | { notFound: true } | { offline: true };
export async function lookupBarcode(code: string): Promise<BarcodeResult> {
  const { data: local } = await supabase.from('foods').select('*').eq('barcode', code).limit(1);
  if (local?.length) return { food: toFood(local[0]) };
  let json: any;
  try {
    const res = await fetch(
      `https://world.openfoodfacts.org/api/v2/product/${encodeURIComponent(code)}.json?fields=product_name,product_name_en,product_name_ar,brands,nutriments,serving_size,serving_quantity`,
      { headers: { 'User-Agent': 'HabibiGains/1.0 (habibigains.store)' } },
    );
    json = await res.json();
  } catch {
    return { offline: true };
  }
  const p = json?.product;
  const n = p?.nutriments;
  if (!p || !n || (n['energy-kcal_100g'] == null && n['energy_100g'] == null)) return { notFound: true };
  const kcal100 = n['energy-kcal_100g'] != null ? Number(n['energy-kcal_100g']) : Number(n['energy_100g']) / 4.184;
  const g100 = (k: string) => (n[`${k}_100g`] != null ? r1(Number(n[`${k}_100g`])) : null);
  const servingG = Number(p.serving_quantity) > 0 ? Number(p.serving_quantity) : null;
  const servings: Serving[] = servingG ? [{ label: p.serving_size ? String(p.serving_size).slice(0, 40) : '1 serving', g: servingG }] : [];
  const row = {
    name_en: String(p.product_name_en || p.product_name || 'Scanned product').slice(0, 160),
    name_ar: p.product_name_ar ? String(p.product_name_ar).slice(0, 160) : null,
    brand: p.brands ? String(p.brands).split(',')[0].trim().slice(0, 80) : null,
    source: 'off',
    search_text: `${p.product_name ?? ''} ${p.brands ?? ''}`.toLowerCase(),
    base_g: 100,
    kcal: Math.round(kcal100),
    protein_g: g100('proteins') ?? 0,
    carbs_g: g100('carbohydrates') ?? 0,
    fat_g: g100('fat') ?? 0,
    fiber_g: g100('fiber'),
    sugar_g: g100('sugars'),
    sodium_mg: n['sodium_100g'] != null ? Math.round(Number(n['sodium_100g']) * 1000) : null,
    sat_fat_g: g100('saturated-fat'),
    cholesterol_mg: n['cholesterol_100g'] != null ? Math.round(Number(n['cholesterol_100g']) * 1000) : null,
    potassium_mg: n['potassium_100g'] != null ? Math.round(Number(n['potassium_100g']) * 1000) : null,
    servings,
    barcode: code,
    created_by: await uid(),
    verified: false,
  };
  const { data: inserted } = await supabase.from('foods').insert(row).select('*').single();
  return { food: toFood(inserted ?? { id: '', is_local: false, ingredients: null, recipe_servings: null, ...row }) };
}

// ───────────────────────── Water ─────────────────────────
export async function getWater(day = todayISO()) {
  const { data } = await supabase.from('water_days').select('ml').eq('day', day).maybeSingle();
  return Number(data?.ml ?? 0);
}

export async function setWater(ml: number, day = todayISO()) {
  const user_id = await uid();
  const { error } = await supabase.from('water_days').upsert({ user_id, day, ml: Math.max(0, Math.min(20000, Math.round(ml))) });
  if (error) throw error;
}

// ───────────────────────── Weight ─────────────────────────
export async function fetchTrend(days = 365): Promise<TrendPoint[]> {
  const since = todayISO(new Date(Date.now() - days * 86_400_000));
  const { data, error } = await supabase.from('weigh_ins').select('measured_on,weight_kg').gte('measured_on', since).order('measured_on');
  if (error) throw error;
  return buildTrend((data ?? []) as any);
}

export async function logWeight(userId: string, kg: number, day = todayISO()) {
  const { error } = await supabase
    .from('weigh_ins')
    .upsert({ user_id: userId, weight_kg: kg, measured_on: day, source: 'manual' }, { onConflict: 'user_id,measured_on' });
  if (error) throw error;
}

// ───────────────────────── Runs (GPS) ─────────────────────────
export async function saveRun(run: Omit<Run, 'id'>) {
  const user_id = await uid();
  const { data, error } = await supabase.from('runs').insert({ ...run, user_id }).select('*').single();
  if (error) throw error;
  return data as Run;
}

export async function fetchRuns(limit = 50) {
  const { data, error } = await supabase
    .from('runs')
    .select('id,title,started_at,ended_at,moving_s,elapsed_s,distance_m,kcal,elev_gain_m,splits,route')
    .order('started_at', { ascending: false })
    .limit(limit);
  if (error) throw error;
  return (data ?? []).map((r: any) => ({ ...r, distance_m: Number(r.distance_m), elev_gain_m: num(r.elev_gain_m) })) as Run[];
}

export async function getRun(id: string) {
  const { data, error } = await supabase.from('runs').select('*').eq('id', id).single();
  if (error) throw error;
  return { ...data, distance_m: Number(data.distance_m), elev_gain_m: num(data.elev_gain_m) } as Run;
}

export async function renameRun(id: string, title: string) {
  const { error } = await supabase.from('runs').update({ title: title.trim().slice(0, 80) || null }).eq('id', id);
  if (error) throw error;
}

export async function deleteRun(id: string) {
  const { error } = await supabase.from('runs').delete().eq('id', id);
  if (error) throw error;
}

// ───────────────────────── Community ─────────────────────────
export async function fetchEvents() {
  const { data, error } = await supabase
    .from('events_public')
    .select('*')
    .gte('starts_at', new Date(Date.now() - 4 * 3_600_000).toISOString())
    .order('starts_at')
    .limit(20);
  if (error) throw error;
  return (data ?? []) as EventRow[];
}

export async function rsvp(eventId: string, userId: string, going: boolean) {
  if (going) await supabase.from('event_rsvps').upsert({ event_id: eventId, user_id: userId });
  else await supabase.from('event_rsvps').delete().eq('event_id', eventId).eq('user_id', userId);
}

export async function fetchQuests() {
  const today = todayISO();
  const [{ data: qs }, { data: done }] = await Promise.all([
    supabase.from('quests').select('*').lte('starts_on', today).gte('ends_on', today).order('ends_on'),
    supabase.from('quest_completions').select('quest_id'),
  ]);
  const doneSet = new Set((done ?? []).map((d: any) => d.quest_id));
  return ((qs ?? []) as Quest[]).map((q) => ({ ...q, done: doneSet.has(q.id) }));
}

export async function fetchBadges() {
  const [{ data: all }, { data: mine }] = await Promise.all([
    supabase.from('badges').select('*').not('id', 'like', 'event-%'),
    supabase.from('user_badges').select('badge_id, earned_at, badges(name_en, name_ar)'),
  ]);
  const mineSet = new Set((mine ?? []).map((m: any) => m.badge_id));
  const eventBadges = (mine ?? [])
    .filter((m: any) => String(m.badge_id).startsWith('event-'))
    .map((m: any) => ({ id: m.badge_id, name_en: m.badges?.name_en ?? 'Run Club', name_ar: m.badges?.name_ar ?? null, icon: 'run', earned: true }));
  return [...((all ?? []) as any[]).map((b) => ({ ...b, earned: mineSet.has(b.id) })), ...eventBadges] as {
    id: string;
    name_en: string;
    name_ar: string | null;
    icon: string;
    earned: boolean;
  }[];
}

export async function awardBadge(id: string) {
  const { data } = await supabase.rpc('award_badge', { p_badge: id });
  return data === true;
}

export async function fetchPhotos() {
  const { data } = await supabase.from('progress_photos').select('*').order('taken_on');
  return (data ?? []) as { id: string; storage_path: string; pose: string; taken_on: string }[];
}

export async function completeQuest(questId: string, proofPath: string | null) {
  const { data, error } = await supabase.rpc('complete_quest', { p_quest: questId, p_proof: proofPath });
  if (error) throw error;
  return data as { ok: boolean; xp?: number; error?: string };
}

export async function checkIn(code: string) {
  const { data, error } = await supabase.rpc('check_in', { p_code: code });
  if (error) throw error;
  return data as { ok: boolean; event?: string; badge?: string; xp?: number; error?: string; already?: boolean };
}

export async function addProgressPhoto(userId: string, uri: string, upload: (uri: string) => Promise<string>) {
  const path = await upload(uri);
  const { error } = await supabase.from('progress_photos').insert({ user_id: userId, storage_path: path });
  if (error) throw error;
}
