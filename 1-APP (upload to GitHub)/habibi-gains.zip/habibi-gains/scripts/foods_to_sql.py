import json, sys
d = json.load(open('foods.json'))
cols = ['name_en','name_ar','source','usda_id','food_group','search_text','base_g','kcal','protein_g','carbs_g','fat_g','fiber_g','sugar_g','sodium_mg','sat_fat_g','cholesterol_mg','potassium_mg','servings','is_local','verified']
def lit(v):
    if v is None: return 'null'
    if isinstance(v, bool): return 'true' if v else 'false'
    if isinstance(v, (int, float)): return repr(v)
    if isinstance(v, (list, dict)): v = json.dumps(v, ensure_ascii=False)
    return "'" + str(v).replace("'", "''") + "'"
def rows(chunk):
    return ',\n'.join('(' + ','.join(lit(o.get(c, True if c == 'verified' else (False if c == 'is_local' else None))) for c in cols) + ')' for o in chunk)
n = int(sys.argv[1]) if len(sys.argv) > 1 else 10**9
for i in range(0, len(d), n):
    part = d[i:i+n]
    sql = f"insert into public.foods ({','.join(cols)}) values\n{rows(part)}\non conflict do nothing;\n"
    open(f'chunk_{i//n:02d}.sql' if n < 10**9 else 'all.sql', 'w').write(sql)
