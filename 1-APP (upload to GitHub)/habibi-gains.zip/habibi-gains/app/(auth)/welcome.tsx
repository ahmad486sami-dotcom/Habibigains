// Animated 3-page intro. Pages slide, the logo breathes, dots stretch.
import { router } from 'expo-router';
import React, { useEffect, useRef, useState } from 'react';
import { Dimensions, FlatList, View } from 'react-native';
import Animated, {
  FadeIn,
  FadeInDown,
  interpolate,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useI18n } from '@/i18n/i18n';
import { buildTrend } from '@/lib/trend';
import { useTheme } from '@/theme/theme';
import { Logo, Ring, TrendChart } from '@/ui/Graphics';
import { Icon } from '@/ui/Icon';
import { Button, Press } from '@/ui/Press';
import { Txt } from '@/ui/Txt';

const { width: W } = Dimensions.get('window');

const sample = buildTrend(
  Array.from({ length: 30 }, (_, i) => ({
    measured_on: new Date(Date.UTC(2026, 0, 1 + i)).toISOString().slice(0, 10),
    weight_kg: 88 - i * 0.12 + Math.sin(i * 1.9) * 0.7,
  })),
);

function Art({ page }: { page: number }) {
  const { theme } = useTheme();
  const breathe = useSharedValue(1);
  useEffect(() => {
    breathe.value = withRepeat(withSequence(withTiming(1.06, { duration: 1400 }), withTiming(1, { duration: 1400 })), -1);
  }, [breathe]);
  const style = useAnimatedStyle(() => ({ transform: [{ scale: breathe.value }] }));

  if (page === 0)
    return (
      <Animated.View style={[{ alignItems: 'center', gap: 28 }, style]}>
        <Logo width={W * 0.5} />
        <View style={{ flexDirection: 'row', gap: 10 }}>
          {['Shawarma 480', 'Karak 120', 'Machboos 650'].map((s, i) => (
            <Animated.View key={s} entering={FadeInDown.delay(300 + i * 120)} style={{ backgroundColor: theme.card, borderRadius: 999, paddingHorizontal: 12, paddingVertical: 8 }}>
              <Txt v="small">{s}</Txt>
            </Animated.View>
          ))}
        </View>
      </Animated.View>
    );
  if (page === 1)
    return (
      <View style={{ backgroundColor: theme.card, borderRadius: 28, padding: 20, width: W - 64 }}>
        <Txt v="label" muted>Trend</Txt>
        <Txt v="number">−3.6 kg</Txt>
        <TrendChart points={sample} width={W - 104} height={130} />
      </View>
    );
  return (
    <Animated.View style={[{ alignItems: 'center', gap: 20 }, style]}>
      <Ring size={190} progress={0.82} stroke={18}>
        <Icon name="run" size={56} color={theme.accent} />
      </Ring>
      <Txt v="label" muted>Corniche · Friday 6:00</Txt>
    </Animated.View>
  );
}

export default function Welcome() {
  const { t } = useI18n();
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const [page, setPage] = useState(0);
  const list = useRef<FlatList>(null);
  const x = useSharedValue(0);

  const pages = [
    { title: t('welcome1Title'), body: t('welcome1Body') },
    { title: t('welcome2Title'), body: t('welcome2Body') },
    { title: t('welcome3Title'), body: t('welcome3Body') },
  ];

  const next = () => {
    if (page < 2) list.current?.scrollToIndex({ index: page + 1 });
    else router.push('/(auth)/sign-in');
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.bg, paddingTop: insets.top, paddingBottom: insets.bottom + 16 }}>
      <FlatList
        ref={list}
        data={pages}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        keyExtractor={(_, i) => String(i)}
        onScroll={(e) => (x.value = e.nativeEvent.contentOffset.x)}
        scrollEventThrottle={16}
        onMomentumScrollEnd={(e) => setPage(Math.round(e.nativeEvent.contentOffset.x / W))}
        renderItem={({ item, index }) => (
          <View style={{ width: W, paddingHorizontal: 28, justifyContent: 'space-between', paddingTop: 40 }}>
            <View style={{ height: 320, alignItems: 'center', justifyContent: 'center' }}>{page === index ? <Art page={index} /> : null}</View>
            <Animated.View key={page === index ? 'on' : 'off'} entering={FadeIn.duration(500)} style={{ gap: 14, paddingBottom: 24 }}>
              <Txt v="hero">{item.title}</Txt>
              <Txt muted style={{ fontSize: 17, lineHeight: 25 }}>{item.body}</Txt>
            </Animated.View>
          </View>
        )}
      />
      <View style={{ paddingHorizontal: 24, gap: 18 }}>
        <View style={{ flexDirection: 'row', gap: 6, alignSelf: 'center' }}>
          {pages.map((_, i) => (
            <Dot key={i} i={i} x={x} />
          ))}
        </View>
        <Button title={page < 2 ? t('next') : t('getStarted')} onPress={next} />
        <Press onPress={() => router.push('/(auth)/sign-in')} style={{ alignSelf: 'center', padding: 8 }}>
          <Txt muted>{t('iHaveAccount')}</Txt>
        </Press>
      </View>
    </View>
  );
}

function Dot({ i, x }: { i: number; x: { value: number } }) {
  const { theme } = useTheme();
  const s = useAnimatedStyle(() => {
    const d = interpolate(x.value / W, [i - 1, i, i + 1], [0, 1, 0], 'clamp');
    return { width: 8 + d * 18, opacity: 0.3 + d * 0.7 };
  });
  return <Animated.View style={[{ height: 8, borderRadius: 4, backgroundColor: theme.text }, s]} />;
}
