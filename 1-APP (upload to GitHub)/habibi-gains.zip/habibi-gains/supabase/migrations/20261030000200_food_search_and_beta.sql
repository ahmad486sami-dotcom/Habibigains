-- Applied to the live project as: food_popularity, food_popularity_2.
-- Popular everyday foods rank first in search.
alter table public.foods add column if not exists popular smallint not null default 0;
-- (popularity scores are set by name; see the live project for the full list)
update public.foods set popular = greatest(popular, 5) where source = 'uae';
